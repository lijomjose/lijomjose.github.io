#include <assert.h>
#define main demo_main
#include "27_duplicate_parentheses.c"
#undef main

int main(void){
 const char *duplicate[]={"(a)","((a+b))","a+((b*c))","((a))"};
 const char *clean[]={"a+b","(a+b)","a+(b*c)","(a+b)*(c-d)"};
 const char *bad[]={"a+)","((a)","()","a b"};
 for(int i=0;i<4;i++){assert(duplicateParentheses(duplicate[i])==DUPLICATE_FOUND);assert(duplicateParentheses(clean[i])==NO_DUPLICATE);assert(duplicateParentheses(bad[i])==INVALID_EXPRESSION);}
 return 0;
}
