/* Structures arrays of structures and returned pointers
 * A structure groups related fields. An array of structures stores several complete records. A nested structure groups a smaller part of a record. These examples also show a function returning a pointer to an existing caller-owned object.
 */

/* Define a record with an array and a nested structure
 * Each Student owns its name array and marks array. Its Date is embedded, not separately allocated. typedef names a type; enum gives named integer choices.
 */

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef enum { CS5, CS6 } Section;
typedef struct {
    int day;
    int month;
    int year;
} Date;
typedef struct {
    char name[40];
    int roll;
    float marks[2];
    Section section;
    Date joined;
} Student;

/* Read a record through a structure pointer
 * This small input format uses a single-word name followed by roll and two marks. The width 39 reserves one character for the null terminator. Read into a temporary so failed validation does not partially overwrite the caller's record.
 */

bool readStudent(Student *student)
{
    Student temporary = {0};
    int readCount = scanf("%39s %d %f %f", temporary.name,
                         &temporary.roll, &temporary.marks[0],
                         &temporary.marks[1]);
    if (readCount != 4) {
        return false;
    }
    if (temporary.roll < 1 || isfinite(temporary.marks[0]) == 0
        || isfinite(temporary.marks[1]) == 0) {
        return false;
    }
    for (int i = 0; i < 2; i++) {
        if (temporary.marks[i] < 0 || temporary.marks[i] > 100) {
            return false;
        }
    }
    temporary.section = CS6;
    temporary.joined = (Date){1, 8, 2026};
    *student = temporary;
    return true;
}

/* Return the student with the largest total
 * The returned pointer refers into the original array. It stays valid only while that array exists. A tie keeps the earlier record.
 */

Student *highestStudent(Student students[], int count)
{
    if (count < 1) {
        return NULL;
    }
    Student *best = &students[0];
    float bestTotal = best->marks[0] + best->marks[1];
    for (int i = 1; i < count; i++) {
        float total = students[i].marks[0] + students[i].marks[1];
        if (total > bestTotal) {
            best = &students[i];
            bestTotal = total;
        }
    }
    return best;
}

/* Display through a pointer
 * Use -> for fields reached through a structure pointer. A nested Date field then uses the ordinary dot operator.
 */

void printStudent(const Student *student)
{
    printf("%s roll %d marks %.1f %.1f joined %d/%d/%d\n",
           student->name, student->roll, student->marks[0],
           student->marks[1], student->joined.day,
           student->joined.month, student->joined.year);
}

/* Return a route to the larger caller owned integer
 * The function returns one supplied address. It never returns the address of a local temporary.
 */

int *largerAddress(int *first, int *second)
{
    if (*first >= *second) {
        return first;
    }
    return second;
}

/* Main logic
 * Enter two records, for example Caitlyn 1 80 90 and Rose 2 95 88. Then display the highest total and demonstrate a returned pointer.
 */

int main(void)
{
    Student students[2];
    puts("Enter name roll mark1 mark2 for two students:");
    for (int i = 0; i < 2; i++) {
        bool ok = readStudent(&students[i]);
        if (ok == false) {
            puts("Invalid student record");
            return 1;
        }
    }
    Student *best = highestStudent(students, 2);
    printStudent(best);
    int a = 10;
    int c = 20;
    int *larger = largerAddress(&a, &c);
    printf("Larger: %d\n", *larger);
    return 0;
}
