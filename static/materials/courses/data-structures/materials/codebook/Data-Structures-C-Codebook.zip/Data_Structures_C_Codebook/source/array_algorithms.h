/* Same result different bills
 * All searches return a zero-based index or -1. All sorts rearrange the supplied array in place. Sorting and searching are included from Lab 1, even though the supplied theory syllabus does not list a separate sorting unit.
 */

/* One swap one responsibility
 * Exchange two integers through their addresses. Three assignments implement one logical swap; counting assignments and counting swaps are different measurements.
 */

/* Header guard: include these declarations only once in this C file. */
#ifndef COURSE_ARRAY_ALGORITHMS_H
/* Remember that this header has already been included. */
#define COURSE_ARRAY_ALGORITHMS_H
/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
void swap(int *first, int *second)
{
    int temporary = *first;
    *first = *second;
    *second = temporary;
}

/* Linear search needs no sorted order
 * Inspect each position and stop at the first match. The invariant is that every earlier position has already been checked and was not the key.
 */

int linearSearch(const int values[], int count, int key)
{
    for (int i = 0; i < count; i++) {
        if (values[i] == key) {
            return i;
        }
    }
    return -1;
}

/* Binary search must earn its shortcut
 * Precondition: ascending sorted input. Keep an inclusive candidate interval [low, high]. The comparison at middle eliminates a half only because the remaining values are ordered. This implementation may return any matching occurrence.
 */

int binarySearch(const int values[], int count, int key)
{
    int low = 0;
    int high = count - 1;
    while (low <= high) {
        int middle = low + (high - low) / 2;
        if (values[middle] == key) {
            return middle;
        }
        if (key < values[middle]) {
            high = middle - 1;
        } else {
            low = middle + 1;
        }
    }
    return -1;
}

/* Bubble sort fixes one suffix position per pass
 * Compare neighbors and swap only when the left value is larger. The largest remaining value travels to the end of the unsorted prefix. A pass with no swaps proves the entire remaining prefix is ordered, so we stop.
 */

void bubbleSort(int values[], int count)
{
    for (int end = count - 1; end > 0; end--) {
        bool changed = false;
        for (int i = 0; i < end; i++) {
            if (values[i] > values[i + 1]) {
                swap(&values[i], &values[i + 1]);
                changed = true;
            }
        }
        if (changed == false) {
            break;
        }
    }
}

/* Selection sort remembers the winner before moving it
 * Find the minimum of the unsorted suffix, then perform at most one swap for that pass. Do not swap whenever a smaller candidate appears: that would be a different implementation with a different swap bill.
 */

void selectionSort(int values[], int count)
{
    for (int position = 0; position < count - 1; position++) {
        int minimum = position;
        for (int i = position + 1; i < count; i++) {
            if (values[i] < values[minimum]) {
                minimum = i;
            }
        }
        if (minimum != position) {
            swap(&values[position], &values[minimum]);
        }
    }
}

/* Insertion sort makes room rather than swapping repeatedly
 * Before each iteration, positions 0 through position-1 are sorted. Save the key, shift only strictly larger predecessors one position right, and fill the gap. The left >= 0 check must occur before reading values[left].
 */

void insertionSort(int values[], int count)
{
    for (int position = 1; position < count; position++) {
        int key = values[position];
        int left = position - 1;
        while (left >= 0 && values[left] > key) {
            values[left + 1] = values[left];
            left--;
        }
        values[left + 1] = key;
    }
}

/* Printing is shared plumbing
 * Keep output separate from algorithms. None of the sort functions should need to know whether a student wants a table, a terminal line, or no output.
 */

void printArray(const int values[], int count)
{
    for (int i = 0; i < count; i++) {
        printf("%d ", values[i]);
    }
    putchar('\n');
}
#endif /* End of this header guard. */
