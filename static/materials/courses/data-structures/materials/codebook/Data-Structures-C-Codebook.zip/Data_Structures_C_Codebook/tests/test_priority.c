#include <assert.h>
#define main demo_main
#include "07_priority_queue.c"
#undef main

int main(void) {
 PriorityQueue q={0}; Patient out={0};
 assert(serve(&q,&out)==false);
 Patient a={"A",2}, b={"B",1}, c={"C",1},d={"D",3};
 assert(admit(&q,a));assert(admit(&q,b));assert(admit(&q,c));assert(admit(&q,d));
 const char *expected[]={"B","C","A","D"};
 for(int i=0;i<4;i++) { assert(serve(&q,&out));assert(strcmp(out.name,expected[i])==0); }
 return 0;
}
