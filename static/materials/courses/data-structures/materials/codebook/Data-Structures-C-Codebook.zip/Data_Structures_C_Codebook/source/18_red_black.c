/* Track the color removed from the old position
 * Rules: the root is black, all NIL leaves are black, red nodes have black children, and every route from a node to a NIL leaf has the same black count. A shared black NIL sentinel replaces NULL child links. Duplicate keys are ignored.
 */

/* Create one shared black NIL node
 * The sentinel points to itself so color checks on missing children are safe. Real nodes use NIL for missing children. NIL.parent is temporarily used during deletion repair; it is not a permanent parent for every leaf.
 */

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef enum { RED, BLACK } Color;
typedef struct RB {
    int value;
    Color color;
    struct RB *left;
    struct RB *right;
    struct RB *parent;
} RB;
RB sentinel;
RB *NIL = &sentinel;
void initRB(void)
{
    NIL->value = 0;
    NIL->color = BLACK;
    NIL->left = NIL;
    NIL->right = NIL;
    NIL->parent = NIL;
}

/* Create a red leaf
 * Making a new leaf red does not add a black node to existing root-to-leaf paths. A red parent may still need repair.
 */

RB *newRB(int value)
{
    RB *node = allocate(sizeof *node);
    node->value = value;
    node->color = RED;
    node->left = NIL;
    node->right = NIL;
    node->parent = NIL;
    return node;
}

/* Rotate left and reconnect the parent
 * Unlike the recursive AVL code, these nodes store parent routes. Repair the moved middle child's parent, reconnect the old parent or root, then put the old root under the pivot. Rotations do not recolor by themselves.
 */

void rbRotateLeft(RB **root, RB *node)
{
    RB *pivot = node->right;
    node->right = pivot->left;
    if (pivot->left != NIL) {
        pivot->left->parent = node;
    }
    pivot->parent = node->parent;
    if (node->parent == NIL) {
        *root = pivot;
    } else if (node == node->parent->left) {
        node->parent->left = pivot;
    } else {
        node->parent->right = pivot;
    }
    pivot->left = node;
    node->parent = pivot;
}

/* Rotate right with the symmetric links
 * The same reconnection steps apply in the opposite direction.
 */

void rbRotateRight(RB **root, RB *node)
{
    RB *pivot = node->left;
    node->left = pivot->right;
    if (pivot->right != NIL) {
        pivot->right->parent = node;
    }
    pivot->parent = node->parent;
    if (node->parent == NIL) {
        *root = pivot;
    } else if (node == node->parent->right) {
        node->parent->right = pivot;
    } else {
        node->parent->left = pivot;
    }
    pivot->right = node;
    node->parent = pivot;
}

/* Repair a red parent after insertion
 * A red uncle allows recoloring and moving the check to the grandparent. A black uncle needs a rotation: first straighten an inward bend, then recolor and rotate the grandparent. Mirror the logic when the parent is a right child. Finish with a black root.
 */

void fixInsert(RB **root, RB *node)
{
    while (node->parent->color == RED) {
        RB *parent = node->parent;
        RB *grandparent = parent->parent;
        if (parent == grandparent->left) {
            RB *uncle = grandparent->right;
            if (uncle->color == RED) {
                parent->color = BLACK;
                uncle->color = BLACK;
                grandparent->color = RED;
                node = grandparent;
            } else {
                if (node == parent->right) {
                    node = parent;
                    rbRotateLeft(root, node);
                }
                node->parent->color = BLACK;
                node->parent->parent->color = RED;
                rbRotateRight(root, node->parent->parent);
            }
        } else {
            RB *uncle = grandparent->left;
            if (uncle->color == RED) {
                parent->color = BLACK;
                uncle->color = BLACK;
                grandparent->color = RED;
                node = grandparent;
            } else {
                if (node == parent->left) {
                    node = parent;
                    rbRotateRight(root, node);
                }
                node->parent->color = BLACK;
                node->parent->parent->color = RED;
                rbRotateLeft(root, node->parent->parent);
            }
        }
    }
    (*root)->color = BLACK;
}

/* Insert a red BST leaf then repair
 * Search before allocating, so duplicate insertion creates no unused node. Attach the new leaf, set its parent, and call the balancing function.
 */

void rbInsert(RB **root, int value)
{
    RB *parent = NIL;
    RB *current = *root;
    while (current != NIL) {
        parent = current;
        if (value == current->value) {
            return;
        }
        if (value < current->value) {
            current = current->left;
        } else {
            current = current->right;
        }
    }
    RB *node = newRB(value);
    node->parent = parent;
    if (parent == NIL) {
        *root = node;
    } else if (value < parent->value) {
        parent->left = node;
    } else {
        parent->right = node;
    }
    fixInsert(root, node);
}

/* Search follows the BST rule
 * Return NIL rather than NULL when absent. Keep the representation consistent throughout this file.
 */

RB *rbSearch(RB *root, int value)
{
    while (root != NIL) {
        if (value == root->value) {
            return root;
        }
        if (value < root->value) {
            root = root->left;
        } else {
            root = root->right;
        }
    }
    return NIL;
}

/* Find the minimum of a nonempty subtree
 * The successor for a two-child deletion is the minimum of the right subtree. It has no real left child.
 */

RB *rbMinimum(RB *node)
{
    while (node->left != NIL) {
        node = node->left;
    }
    return node;
}

/* Transplant replaces a subtree route
 * Connect replacement to old's parent, including when old is the root. Set replacement.parent even when replacement is NIL: deletion repair needs that route. This helper does not copy colors or attach the replacement's other children.
 */

void transplant(RB **root, RB *old, RB *replacement)
{
    if (old->parent == NIL) {
        *root = replacement;
    } else if (old == old->parent->left) {
        old->parent->left = replacement;
    } else {
        old->parent->right = replacement;
    }
    replacement->parent = old->parent;
}

/* Repair a black deficit
 * Think of x as carrying one missing black count at its position. Case 1: red sibling, rotate to get a black sibling. Case 2: black sibling with two black children, recolor sibling and move the deficit up. Case 3: near child red and far child black, rotate sibling. Case 4: far child red, recolor and rotate parent to finish. The second branch mirrors left and right.
 */

void fixDelete(RB **root, RB *x)
{
    while (x != *root && x->color == BLACK) {
        if (x == x->parent->left) {
            RB *sibling = x->parent->right;
            if (sibling->color == RED) {
                sibling->color = BLACK;
                x->parent->color = RED;
                rbRotateLeft(root, x->parent);
                sibling = x->parent->right;
            }
            if (sibling->left->color == BLACK
                && sibling->right->color == BLACK) {
                sibling->color = RED;
                x = x->parent;
            } else {
                if (sibling->right->color == BLACK) {
                    sibling->left->color = BLACK;
                    sibling->color = RED;
                    rbRotateRight(root, sibling);
                    sibling = x->parent->right;
                }
                sibling->color = x->parent->color;
                x->parent->color = BLACK;
                sibling->right->color = BLACK;
                rbRotateLeft(root, x->parent);
                x = *root;
            }
        } else {
            RB *sibling = x->parent->left;
            if (sibling->color == RED) {
                sibling->color = BLACK;
                x->parent->color = RED;
                rbRotateRight(root, x->parent);
                sibling = x->parent->left;
            }
            if (sibling->right->color == BLACK
                && sibling->left->color == BLACK) {
                sibling->color = RED;
                x = x->parent;
            } else {
                if (sibling->left->color == BLACK) {
                    sibling->right->color = BLACK;
                    sibling->color = RED;
                    rbRotateLeft(root, sibling);
                    sibling = x->parent->left;
                }
                sibling->color = x->parent->color;
                x->parent->color = BLACK;
                sibling->left->color = BLACK;
                rbRotateRight(root, x->parent);
                x = *root;
            }
        }
    }
    x->color = BLACK;
}

/* Delete while remembering the old color
 * z is the requested node. y is the node removed from its old position; x replaces y there. With two children, physically move the successor y into z's position and give y the old color of z. Save y's original color before that move. Only a black original color can require black-count repair.
 */

bool rbDelete(RB **root, int value)
{
    RB *z = rbSearch(*root, value);
    if (z == NIL) {
        return false;
    }
    RB *y = z;
    Color originalColor = y->color;
    RB *x;
    if (z->left == NIL) {
        x = z->right;
        transplant(root, z, z->right);
    } else if (z->right == NIL) {
        x = z->left;
        transplant(root, z, z->left);
    } else {
        y = rbMinimum(z->right);
        originalColor = y->color;
        x = y->right;
        if (y->parent == z) {
            x->parent = y;
        } else {
            transplant(root, y, y->right);
            y->right = z->right;
            y->right->parent = y;
        }
        transplant(root, z, y);
        y->left = z->left;
        y->left->parent = y;
        y->color = z->color;
    }
    free(z);
    if (originalColor == BLACK) {
        fixDelete(root, x);
    }
    return true;
}

/* Print keys with their colors
 * Color tags make the state visible, but full validation also needs black-height and parent-link checks.
 */

void printRB(const RB *root)
{
    if (root == NIL) {
        return;
    }
    printRB(root->left);
    char color = 'B';
    if (root->color == RED) {
        color = 'R';
    }
    printf("%d%c ", root->value, color);
    printRB(root->right);
}

/* Free real nodes only
 * NIL is shared static storage. It must never be freed.
 */

void destroyRB(RB *root)
{
    if (root == NIL) {
        return;
    }
    destroyRB(root->left);
    destroyRB(root->right);
    free(root);
}

/* Main logic
 * Initialize NIL before building a tree. Insert a small standard sequence, then delete a red leaf, a black node, and a two-child target. The randomized checks supplied with the source exercise many more paths.
 */

int main(void)
{
    initRB();
    RB *root = NIL;
    int keys[] = {11, 2, 14, 1, 7, 15, 5, 8, 4};
    for (int i = 0; i < 9; i++) {
        rbInsert(&root, keys[i]);
    }
    printRB(root);
    putchar('\n');
    int removals[] = {15, 1, 7};
    for (int i = 0; i < 3; i++) {
        bool deleted = rbDelete(&root, removals[i]);
        printf("Deleted %d: %d\n", removals[i], deleted);
        printRB(root);
        putchar('\n');
    }
    destroyRB(root);
    return 0;
}
