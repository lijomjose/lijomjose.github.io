#include <assert.h>
#define main demo_main
#include "28_multiple_stacks.c"
#undef main

int main(void){
 SharedStacks s;initShared(&s);int model[STACKS][CAPACITY],counts[STACKS]={0};int total=0;
 srand(91);
 for(int step=0;step<20000;step++){
  int k=rand()%STACKS,v=rand();
  if(rand()%2){bool ok=dynamicPush(&s,k,v);assert(ok==(total<CAPACITY));if(ok){model[k][counts[k]++]=v;total++;}}
  else{int out=123;bool ok=dynamicPop(&s,k,&out);assert(ok==(counts[k]>0));if(ok){assert(out==model[k][--counts[k]]);total--;}else assert(out==123);}
  bool seen[CAPACITY]={false};int used=0;
  for(int k2=0;k2<STACKS;k2++){int p=s.top[k2],n=0;while(p!=-1){assert(p>=0&&p<CAPACITY&&!seen[p]);seen[p]=true;used++;n++;p=s.next[p];}assert(n==counts[k2]);}
  int p=s.freeHead;while(p!=-1){assert(p>=0&&p<CAPACITY&&!seen[p]);seen[p]=true;used++;p=s.next[p];}assert(used==CAPACITY);
 }
 FixedStacks f;initFixed(&f);
 for(int k=0;k<STACKS;k++){int width=f.limit[k]-f.start[k];for(int i=0;i<width;i++)assert(fixedPush(&f,k,i));assert(!fixedPush(&f,k,0));for(int i=width-1;i>=0;i--){int out;assert(fixedPop(&f,k,&out));assert(out==i);}}
 return 0;
}
