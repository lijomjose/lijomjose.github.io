#include <assert.h>
#define main demo_main
#include "03_search_sort.c"
#undef main

int cmp(const void *a, const void *b)
{
    int x=*(const int *)a;
    int y=*(const int *)b;
    return (x>y)-(x<y);
}
int main(void)
{
    srand(17);
    for (int n=0;n<=64;n++) {
        for (int trial=0;trial<30;trial++) {
            int a[64],b[64],c[64],expected[64];
            for(int i=0;i<n;i++) {
                a[i]=rand()%21-10;
                b[i]=a[i]; c[i]=a[i]; expected[i]=a[i];
            }
            qsort(expected,(size_t)n,sizeof(int),cmp);
            bubbleSort(a,n); selectionSort(b,n); insertionSort(c,n);
            assert(memcmp(a,expected,(size_t)n*sizeof(int))==0);
            assert(memcmp(b,expected,(size_t)n*sizeof(int))==0);
            assert(memcmp(c,expected,(size_t)n*sizeof(int))==0);
            for(int key=-12;key<=12;key++) {
                int l=linearSearch(expected,n,key);
                int k=binarySearch(expected,n,key);
                assert((l==-1)==(k==-1));
                if(k!=-1) assert(expected[k]==key);
            }
        }
    }
    return 0;
}
