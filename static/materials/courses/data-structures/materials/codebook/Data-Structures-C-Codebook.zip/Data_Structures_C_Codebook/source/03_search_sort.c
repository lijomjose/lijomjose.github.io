/* Searching and sorting main
 * Reuse array_algorithms.h. The complete main below shows the operation sequence.
 */

/* Main logic
 * Give each sort an independent copy of the same input. Calling three sorts successively on one array would give the second and third algorithms an already sorted input. Search only after the binary-search precondition has been established.
 */

/* Reuse the search and sort functions already covered. */
#include "array_algorithms.h"
int main(void)
{
    int bubble[] = {4, 3, 2, 1};
    int selection[] = {4, 3, 2, 1};
    int insertion[] = {4, 3, 2, 1};
    bubbleSort(bubble, 4);
    selectionSort(selection, 4);
    insertionSort(insertion, 4);
    printArray(bubble, 4);
    printArray(selection, 4);
    printArray(insertion, 4);
    int index = linearSearch(bubble, 4, 3);
    printf("Linear index: %d\n", index);
    index = binarySearch(bubble, 4, 3);
    printf("Binary index: %d\n", index);
    return 0;
}
