/* Recursive creation and traversal of a chain
 * The tutorial asks for recursive list creation. We use a fixed input array so the recursion is visible without an input menu. Replace the int stored value with a participant record when needed; the link operations stay the same.
 */

/* Build one node plus the rest of the chain
 * The base case creates an empty suffix. Every other call creates a node and lets the next call build its next chain. A node's next link is assigned only after that call returns.
 */

/* Reuse the singly linked list types and operations already covered. */
#include "slist.h"
Node *createChainRecursive(const int values[], int count)
{
    if (count == 0) {
        return NULL;
    }
    Node *node = newNode(values[0]);
    node->next = createChainRecursive(values + 1, count - 1);
    return node;
}

/* Recursive traversal does not sort a list
 * Visit the current node, then the remaining chain. If IDs must appear ascending, the chain must already be ordered or be sorted first.
 */

void printChainRecursive(const Node *node)
{
    if (node == NULL) {
        return;
    }
    printf("%d ", node->value);
    printChainRecursive(node->next);
}

/* Main logic
 * The input values are already ascending. After creation, find tail once so the result satisfies the List container rule, then reuse clearList.
 */

int main(void)
{
    int values[] = {10, 20, 30};
    List list = {NULL, NULL};
    list.head = createChainRecursive(values, 3);
    list.tail = list.head;
    if (list.tail != NULL) {
        while (list.tail->next != NULL) {
            list.tail = list.tail->next;
        }
    }
    printChainRecursive(list.head);
    putchar('\n');
    clearList(&list);
    return 0;
}
