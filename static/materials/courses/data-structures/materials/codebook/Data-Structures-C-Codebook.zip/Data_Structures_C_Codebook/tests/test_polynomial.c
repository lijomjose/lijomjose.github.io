#include <assert.h>
#define main demo_main
#include "11_polynomials.c"
#undef main

long long evaluatePoly(const PolyTerm *h,int x) {
 long long total=0;
 for(const PolyTerm *p=h->next;p!=h;p=p->next){long long power=1;for(int i=0;i<p->exponent;i++)power*=x;total+=p->coefficient*power;}
 return total;
}
void checkPoly(PolyTerm *h) {
 int previous=INT_MAX;
 for(PolyTerm *p=h->next;p!=h;p=p->next){assert(p->coefficient!=0);assert(p->exponent<previous);previous=p->exponent;assert(p->next->previous==p);assert(p->previous->next==p);}
}
int main(void) {
 srand(22);
 for(int trial=0;trial<200;trial++) {
  PolyTerm *a=newPolynomial(),*b=newPolynomial();
  for(int i=0;i<12;i++){addTerm(a,rand()%7-3,rand()%5);addTerm(b,rand()%7-3,rand()%5);}
  PolyTerm *sum=addPolynomials(a,b),*product=multiplyPolynomials(a,b);
  checkPoly(a);checkPoly(b);checkPoly(sum);checkPoly(product);
  for(int x=-2;x<=2;x++){long long av=evaluatePoly(a,x),bv=evaluatePoly(b,x);assert(evaluatePoly(sum,x)==av+bv);assert(evaluatePoly(product,x)==av*bv);}
  destroyPolynomial(a);destroyPolynomial(b);destroyPolynomial(sum);destroyPolynomial(product);
 }
 return 0;
}
