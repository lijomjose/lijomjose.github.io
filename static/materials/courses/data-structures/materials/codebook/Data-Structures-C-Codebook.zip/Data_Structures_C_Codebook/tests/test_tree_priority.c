
#include <assert.h>
#define main demo_main
#include "39_tree_priority.c"
#undef main
int main(void)
{
    TreePriorityQueue queue;
    initTreePriority(&queue);
    Patient model[CAPACITY];
    int count=0;
    static char names[20000][20];
    srand(96);
    for(int step=0;step<20000;step++) {
        if(rand()%2) {
            snprintf(names[step],sizeof names[step],"Arrival-%d",step);
            Patient patient={names[step],rand()%16};
            bool ok=treePriorityInsert(&queue,patient);
            assert(ok==(count<CAPACITY));
            if(ok) model[count++]=patient;
        } else {
            bool highest=rand()%2;
            Patient out={"unchanged",-9};
            bool ok=treePriorityPeek(&queue,highest,&out);
            assert(ok==(count>0));
            int best=0;
            for(int i=1;i<count;i++) {
                bool better=model[i].priority<model[best].priority;
                if(highest) better=model[i].priority>model[best].priority;
                if(better) best=i;
            }
            if(ok) assert(strcmp(out.name,model[best].name)==0);
            ok=treePriorityRemove(&queue,highest,&out);
            assert(ok==(count>0));
            if(ok) {
                assert(strcmp(out.name,model[best].name)==0);
                assert(out.priority==model[best].priority);
                for(int i=best;i<count-1;i++) model[i]=model[i+1];
                count--;
            } else assert(out.priority==-9);
        }
        int buckets=0;
        for(int i=0;i<CAPACITY;i++) buckets+=queue.waiting[i].count;
        assert(buckets==count);
        assert(queue.freeSlots.top+1==CAPACITY-count);
    }
    clearTreePriority(&queue);
    assert(queue.priorities==NULL);
    assert(queue.freeSlots.top==CAPACITY-1);
    return 0;
}
