/* Count concatenate split and remove the rear
 * These are the extra SLL operations listed in the official PPT. Reuse slist.h. Ownership moves during concatenation and splitting: do not leave two containers owning the same chain.
 */

/* Count by walking once
 * Count nodes, not links that happen to be non-NULL. The final real node counts too.
 */

/* Reuse the singly linked list types and operations already covered. */
#include "slist.h"
int listCount(const List *list)
{
    int count = 0;
    for (const Node *p = list->head; p != NULL; p = p->next) {
        count++;
    }
    return count;
}

/* Rear deletion still needs a predecessor
 * Handle empty and singleton lists first. Then find the node whose next route reaches tail. This is O(n), even though tail is stored.
 */

bool removeRear(List *list, int *value)
{
    if (list->head == NULL) {
        return false;
    }
    if (list->head == list->tail) {
        return removeFront(list, value);
    }
    Node *previous = list->head;
    while (previous->next != list->tail) {
        previous = previous->next;
    }
    Node *old = list->tail;
    *value = old->value;
    previous->next = NULL;
    list->tail = previous;
    free(old);
    return true;
}

/* Concatenate with the stored tail
 * Before calling: distinct, disjoint lists. The second list becomes empty. Linking takes O(1); a head-only implementation would first walk to the first list's last node.
 */

void concatenateLists(List *first, List *second)
{
    if (second->head == NULL) {
        return;
    }
    if (first->tail == NULL) {
        first->head = second->head;
    } else {
        first->tail->next = second->head;
    }
    first->tail = second->tail;
    second->head = NULL;
    second->tail = NULL;
}

/* Append an existing detached node
 * This helper transfers a node instead of allocating a copy. The caller gives up ownership of that detached node.
 */

void appendExisting(List *list, Node *node)
{
    node->next = NULL;
    if (list->tail == NULL) {
        list->head = node;
    } else {
        list->tail->next = node;
    }
    list->tail = node;
}

/* Split alternating indices without copying nodes
 * Before calling: destination lists are empty and all three containers are distinct. Index 0 goes to evenIndices, index 1 to oddIndices. Save next before appendExisting detaches the current node.
 */

void splitAlternating(List *source, List *evenIndices, List *oddIndices)
{
    int index = 0;
    Node *current = source->head;
    while (current != NULL) {
        Node *next = current->next;
        if (index % 2 == 0) {
            appendExisting(evenIndices, current);
        } else {
            appendExisting(oddIndices, current);
        }
        current = next;
        index++;
    }
    source->head = NULL;
    source->tail = NULL;
}

/* Main logic
 * Split 0 through 5 into 0,2,4 and 1,3,5. Concatenate those results, remove the last value, and clean up the single remaining owner.
 */

int main(void)
{
    List source = {NULL, NULL};
    List even = {NULL, NULL};
    List odd = {NULL, NULL};
    for (int i = 0; i < 6; i++) {
        append(&source, i);
    }
    splitAlternating(&source, &even, &odd);
    printList(&even);
    printList(&odd);
    concatenateLists(&even, &odd);
    int value;
    bool ok = removeRear(&even, &value);
    if (ok) {
        printf("Rear removed: %d Count: %d\n", value, listCount(&even));
    }
    clearList(&even);
    return 0;
}
