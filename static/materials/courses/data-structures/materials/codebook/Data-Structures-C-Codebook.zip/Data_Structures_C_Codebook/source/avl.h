/* A BST that notices when one side grows too tall
 * Height here counts nodes: NULL has height 0 and a leaf has height 1. Balance factor is left height minus right height. Every node must have balance -1, 0, or 1. This convention differs from tree.h by one, but balance factors are unchanged.
 */

/* Store cached heights
 * Without cached heights, repeatedly traversing subtrees to calculate balance could make updates much slower. A constructor gives a new leaf height 1.
 */

/* Header guard: include these declarations only once in this C file. */
#ifndef COURSE_AVL_H
/* Remember that this header has already been included. */
#define COURSE_AVL_H
/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct AVL {
    int value;
    int height;
    struct AVL *left;
    struct AVL *right;
} AVL;
AVL *newAVL(int value)
{
    AVL *node = allocate(sizeof *node);
    node->value = value;
    node->height = 1;
    node->left = NULL;
    node->right = NULL;
    return node;
}

/* Read a cached height
 * The NULL convention keeps later arithmetic simple.
 */

int avlHeight(const AVL *node)
{
    if (node == NULL) {
        return 0;
    }
    return node->height;
}

/* Refresh after a child route changes
 * Read both heights, keep the larger, then add one for this node.
 */

void updateHeight(AVL *node)
{
    int largest = avlHeight(node->left);
    int right = avlHeight(node->right);
    if (right > largest) {
        largest = right;
    }
    node->height = largest + 1;
}

/* Measure the imbalance
 * Positive means taller on the left. Negative means taller on the right.
 */

int balanceFactor(const AVL *node)
{
    if (node == NULL) {
        return 0;
    }
    return avlHeight(node->left) - avlHeight(node->right);
}

/* Rotate right without losing the middle subtree
 * Let pivot be root.left. The pivot's old right subtree moves to root.left, then root becomes pivot.right. Update the lower node's height before the new root's height.
 */

AVL *rotateRight(AVL *root)
{
    AVL *pivot = root->left;
    AVL *middle = pivot->right;
    pivot->right = root;
    root->left = middle;
    updateHeight(root);
    updateHeight(pivot);
    return pivot;
}

/* Rotate left with the symmetric links
 * A rotation changes shape while preserving inorder order. The middle subtree stays between the same two key values.
 */

AVL *rotateLeft(AVL *root)
{
    AVL *pivot = root->right;
    AVL *middle = pivot->left;
    pivot->left = root;
    root->right = middle;
    updateHeight(root);
    updateHeight(pivot);
    return pivot;
}

/* Use child balance to choose the repair
 * After refreshing height, repair left-heavy or right-heavy nodes. An inward-heavy child needs a preliminary rotation. Child balance zero belongs to the single-rotation case; this matters after deletion.
 */

AVL *rebalance(AVL *root)
{
    if (root == NULL) {
        return NULL;
    }
    updateHeight(root);
    int balance = balanceFactor(root);
    if (balance > 1) {
        if (balanceFactor(root->left) < 0) {
            root->left = rotateLeft(root->left);
        }
        return rotateRight(root);
    }
    if (balance < -1) {
        if (balanceFactor(root->right) > 0) {
            root->right = rotateRight(root->right);
        }
        return rotateLeft(root);
    }
    return root;
}

/* Insert as a BST then repair on the way back
 * Store each returned child root. A rotation may change that root. Duplicates are ignored.
 */

AVL *avlInsert(AVL *root, int value)
{
    if (root == NULL) {
        return newAVL(value);
    }
    if (value < root->value) {
        root->left = avlInsert(root->left, value);
    } else if (value > root->value) {
        root->right = avlInsert(root->right, value);
    } else {
        return root;
    }
    return rebalance(root);
}

/* Locate the successor
 * The minimum of a nonempty right subtree has no left child. This is the same BST fact used before balancing was introduced.
 */

AVL *avlMinimum(AVL *root)
{
    while (root->left != NULL) {
        root = root->left;
    }
    return root;
}

/* Delete as a BST then repair every affected ancestor
 * Zero/one-child deletion frees the target and returns its child. Two-child deletion copies the successor value and deletes the successor. On return, rebalance every surviving ancestor, since deletion can reduce height repeatedly toward the root.
 */

AVL *avlDelete(AVL *root, int value)
{
    if (root == NULL) {
        return NULL;
    }
    if (value < root->value) {
        root->left = avlDelete(root->left, value);
    } else if (value > root->value) {
        root->right = avlDelete(root->right, value);
    } else {
        if (root->left == NULL || root->right == NULL) {
            AVL *child = root->left;
            if (child == NULL) {
                child = root->right;
            }
            free(root);
            return child;
        }
        AVL *successor = avlMinimum(root->right);
        root->value = successor->value;
        root->right = avlDelete(root->right, successor->value);
    }
    return rebalance(root);
}

/* Print values and current balance factors
 * Inorder output checks key order. The printed balance factors help a student see where a rotation was needed, but are not a complete correctness test by themselves.
 */

void printAVL(const AVL *root)
{
    if (root == NULL) {
        return;
    }
    printAVL(root->left);
    printf("%d(b=%d) ", root->value, balanceFactor(root));
    printAVL(root->right);
}

/* Destroy the AVL tree
 * Cleanup uses the same postorder rule as the ordinary tree; only the node type changed.
 */

void destroyAVL(AVL *root)
{
    if (root == NULL) {
        return;
    }
    destroyAVL(root->left);
    destroyAVL(root->right);
    free(root);
}
#endif /* End of this header guard. */
