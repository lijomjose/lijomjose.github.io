# The Dragon Scroll of Data Structures

C code, small traces, and the questions that matter.

Prepared for Data Structures | CES 2101

School of Computer Science and Engineering

Manipal Institute of Technology, Bengaluru

Manipal Academy of Higher Education (MAHE)

Prepared by Dr. Lijo M. Jose

## A Note to My Students

Dear students,

Legend says the Dragon Scroll contains the secret to mastering Data Structures. This one contains C code and a few uncomfortable questions. Budget constraints.

Why is top at the head? Why did we move that pointer first? Why is this loop still going when the rest of us have mentally gone home?

The answers are here too. "Figure it out yourself" worked for a few questions during the semester. The end of the semester calls for a little more mercy.

Use this like a cheat sheet. I still wish you had gone through my detailed lecture notes, but alas, here we are. Revise, trace, and experiment.

Memorizing a program only helps until the question paper develops a personality.

So look beyond the lines of code. What problem were they trying to solve? Why this approach? And how would you have thought of it?

The compiler will complain about your syntax. Your logic, unfortunately, may get away with anything.

Regards,

Lijo

A highly optimistic DS teacher, trying to train an army the day before the war.

## Common C Headers and Memory Allocation

These lines support the programs. Standard headers such as stdio.h provide library functions; the comments below name the ones we use.

course_common.h is our own shared header. It supplies standard headers, CAPACITY and allocate. Keep it beside the C file, or put its needed declarations above your functions. The filename itself is not a C requirement.

#ifndef, #define and the closing #endif form a header guard: skip a header that has already been included. A separate #define CAPACITY 128 gives a size limit a name.

static gives each C file its own helper; inline permits, but does not guarantee, inlining. In one C file, ordinary function definitions are enough.

allocate calls malloc and checks for failure. Later programs reuse that check. Likewise, int_queue.h reuses the earlier queue functions; it does not introduce a new queue algorithm.

```c

/* Header guard: include these declarations only once in this C file. */
#ifndef COURSE_COMMON_H
/* Remember that this header has already been included. */
#define COURSE_COMMON_H
#include <stdio.h> /* printf, putchar and input/output functions */
#include <stdlib.h> /* malloc, calloc, realloc, free and exit */
#include <stdbool.h> /* bool, true and false */
#include <string.h> /* string functions and memory helpers such as memset */
#include <math.h> /* math functions used by expression evaluation */
#include <ctype.h> /* character checks used by expression conversion */
#include <limits.h> /* integer limits used by range checks */
/* A named size limit; change it here rather than in every array. */
#define CAPACITY 128

/* This teaching policy stops the demo if storage cannot be obtained. */
/* static keeps this helper local to each C file that includes it.
 * inline allows inlining; it does not require it. A single-file program
 * can use an ordinary function instead. */
static inline void *allocate(size_t bytes)
{
    void *memory = malloc(bytes);
    if (memory == NULL) {
        fprintf(stderr, "Allocation failed\n");
        exit(EXIT_FAILURE);
    }
    return memory;
}
#endif /* End of this header guard. */


```


## 1 Pointers, Memory and Recursion

Pointers, arrays, allocation, user-defined types, and recursion.


### Pointers, Dynamic Memory, typedef and enum

File: `01_memory.c`

Use int * to change an integer through its address. Use int ** to change a caller-owned pointer. C copies argument values in both cases.


#### Change the object

damage receives a copied address. Following that address with * reaches the original health. Assigning health = NULL would only change the local route.

```c

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
void damage(int *health, int amount)
{
    *health = *health - amount;
}

```


#### Change the route

createInventory receives the address of the caller's pointer. It allocates count integers with calloc so the initial integer values are zero. The caller must supply count from 1 to 1000. We check that range before calculating a size.

```c

bool createInventory(int **inventory, int count)
{
    if (count < 1 || count > 1000) {
        return false;
    }
    int *memory = calloc((size_t)count, sizeof *memory);
    if (memory == NULL) {
        return false;
    }
    *inventory = memory;
    return true;
}

```


#### Grow without losing the old route

realloc may move the block. Store its result in a temporary pointer. If it fails, the original allocation remains owned by the caller. Newly added positions are not initialized by realloc.

```c

bool resizeInventory(int **inventory, int count)
{
    if (count < 1 || count > 1000) {
        return false;
    }
    int *replacement = realloc(*inventory,
                              (size_t)count * sizeof **inventory);
    if (replacement == NULL) {
        return false;
    }
    *inventory = replacement;
    return true;
}

```


#### Main logic

First change the health object. Then create three slots, fill them through pointer arithmetic, resize to five, initialize the added slots, and release the allocation exactly once.

The array of pointers stores two routes, not two copied integers. typedef gives a type another name; enum gives named integer choices.

```c

typedef enum { KNIGHT, MAGE } Role;
typedef struct {
    const char *name;
    Role role;
    int health;
} Hero;

int main(void)
{
    Hero hero = {"Caitlyn", KNIGHT, 100};
    damage(&hero.health, 20);
    printf("Health: %d\n", hero.health);
    int *inventory = NULL;
    bool created = createInventory(&inventory, 3);
    if (created == false) {
        return EXIT_FAILURE;
    }
    for (int i = 0; i < 3; i++) {
        *(inventory + i) = (i + 1) * 10;
    }
    bool resized = resizeInventory(&inventory, 5);
    if (resized == false) {
        free(inventory);
        return EXIT_FAILURE;
    }
    inventory[3] = 40;
    inventory[4] = 50;
    int *routes[2] = {&inventory[0], &inventory[4]};
    printf("First: %d Last: %d\n", *routes[0], *routes[1]);
    free(inventory);
    inventory = NULL;
    return 0;
}

```


> **Notice: Pause and predict**

> After realloc succeeds, can we keep using an old pointer to inventory[0]? No. The old allocation may have moved, so derive aliases again from the returned pointer. Setting inventory to NULL after free does not repair any other dangling aliases.


> **Notice: Memory picture**

> Before damage: hero.health = 100. The parameter health stores its address. After *health = *health - 20, the same object contains 80. Before createInventory, inventory = NULL. The parameter inventory inside that function points to the caller's pointer; *inventory = memory changes that caller-owned route.


> **Notice: The array question**

> For int a[3], sizeof a measures three integers. In a function parameter int a[], the declaration is adjusted to int *a, so sizeof a measures a pointer. Pass the element count separately.

> A genuine int grid[2][3] decays to int (*)[3], not int **; one outer step crosses a whole three-integer row.


### Recursion, GCD, Array Sum and Tower of Hanoi

File: `02_recursion.c`

Each call must reach a smaller case and eventually stop. These examples show one recursive call, a linear chain of calls, and two recursive branches.


#### Euclidean GCD

For nonnegative a and b, gcd(a,b) = gcd(b,a%b). When b is zero, a is the answer. Each call has its own a and b.

```c

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
int gcd(int a, int b)
{
    if (b == 0) {
        return a;
    }
    int remainder = a % b;
    return gcd(b, remainder);
}

```


#### An array as one item plus the rest

The empty suffix contributes zero. Otherwise, add the current element to the sum of the shorter suffix. Before calling: count is nonnegative and the mathematical sum fits int.

```c

int recursiveSum(const int values[], int count)
{
    if (count == 0) {
        return 0;
    }
    int rest = recursiveSum(values + 1, count - 1);
    return values[0] + rest;
}

```


#### Tower of Hanoi

Move n-1 disks to the spare peg, move the largest disk to the destination, and move the waiting n-1 disks onto it. A count of zero means there is nothing to move.

```c

void hanoi(int count, char from, char spare, char to)
{
    if (count == 0) {
        return;
    }
    hanoi(count - 1, from, to, spare);
    printf("Disk %d: %c to %c\n", count, from, to);
    hanoi(count - 1, spare, from, to);
}

```


#### Main logic

Fixed small inputs keep attention on the calls. Predict the Hanoi order before running the file. The two recursive calls are sequential, so maximum active depth is linear even though total moves are exponential.

```c

int main(void)
{
    int values[] = {4, 7, 2};
    printf("GCD: %d\n", gcd(48, 18));
    printf("Sum: %d\n", recursiveSum(values, 3));
    hanoi(3, 'A', 'B', 'C');
    return 0;
}

```


> **Notice: Count the promises**

> recursiveSum on three items waits for counts 2, 1, and 0, then returns 0, 2, 9, 13. Time is Theta(n), extra call space Theta(n). Hanoi satisfies T(n)=2T(n-1)+Theta(1), so it makes 2^n-1 moves and uses Theta(n) call space. Euclid uses O(log(max(a,b))) calls for positive inputs.


### Array ADT, Factorial and Recursive Binary Search

File: `19_arrays_recursion.c`

Logical count and allocated capacity are different. Small arithmetic examples assume the result fits its stated type.


#### Create a bounded array

Start empty. Its values become meaningful only as we insert them. This one-dimensional ADT uses int values and a fixed maximum capacity.

```c

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct {
    int values[CAPACITY];
    int count;
} Array;
void initArray(Array *array)
{
    array->count = 0;
}

```


#### Retrieve an existing element

Return a status separately from the stored integer. An invalid index leaves the output unchanged.

```c

bool arrayGet(const Array *array, int index, int *value)
{
    if (index < 0 || index >= array->count) {
        return false;
    }
    *value = array->values[index];
    return true;
}

```


#### Replace an existing element

Store changes a value, not the logical length. Valid occupied indices end at count-1.

```c

bool arrayStore(Array *array, int index, int value)
{
    if (index < 0 || index >= array->count) {
        return false;
    }
    array->values[index] = value;
    return true;
}

```


#### Array Insertion

Insertion also allows index=count. Shift right from the end so unread values survive.

```c

bool arrayInsert(Array *array, int index, int value)
{
    if (index < 0 || index > array->count
        || array->count == CAPACITY) {
        return false;
    }
    for (int i = array->count; i > index; i--) {
        array->values[i] = array->values[i - 1];
    }
    array->values[index] = value;
    array->count++;
    return true;
}

```


#### Array Deletion

Copy the removed value before shifting. Logical length decreases; physical capacity stays the same.

```c

bool arrayDelete(Array *array, int index, int *value)
{
    if (index < 0 || index >= array->count) {
        return false;
    }
    *value = array->values[index];
    for (int i = index; i < array->count - 1; i++) {
        array->values[i] = array->values[i + 1];
    }
    array->count--;
    return true;
}

```


#### Recursive Factorial

For input 0 through 20, the result fits unsigned long long on a C implementation with at least 64 bits for that type. The recursive helper assumes that range has already been checked.

```c

unsigned long long factorial(int n)
{
    if (n == 0) {
        return 1;
    }
    unsigned long long smaller = factorial(n - 1);
    return (unsigned long long)n * smaller;
}

```


#### Recursive Binary Search

Assume ascending input. Empty interval means low>high. Unlike iterative binary search, these calls use O(log n) extra call space in the worst case.

```c

int recursiveBinarySearch(const int values[], int low, int high, int key)
{
    if (low > high) {
        return -1;
    }
    int middle = low + (high - low) / 2;
    if (values[middle] == key) {
        return middle;
    }
    if (key < values[middle]) {
        return recursiveBinarySearch(values, low, middle - 1, key);
    }
    return recursiveBinarySearch(values, middle + 1, high, key);
}

```


#### Pass a real two dimensional array

The column width is part of the parameter type. Read only rows 0 through rows-1; the caller supplies a valid row count. The sum must fit int.

```c

int sumMatrix(const int matrix[][3], int rows)
{
    int sum = 0;
    for (int row = 0; row < rows; row++) {
        for (int column = 0; column < 3; column++) {
            sum = sum + matrix[row][column];
        }
    }
    return sum;
}

```


#### Main logic

Create, insert, replace, retrieve, and delete before showing the two recursive examples. The matrix has two genuine three-integer rows.

```c

int main(void)
{
    Array array;
    initArray(&array);
    bool ok = arrayInsert(&array, 0, 10);
    if (ok == false) {
        return 1;
    }
    ok = arrayInsert(&array, 1, 30);
    if (ok == false) {
        return 1;
    }
    ok = arrayInsert(&array, 1, 20);
    if (ok == false) {
        return 1;
    }
    ok = arrayStore(&array, 1, 25);
    if (ok == false) {
        return 1;
    }
    int value;
    ok = arrayGet(&array, 1, &value);
    if (ok) {
        printf("Retrieved: %d\n", value);
    }
    ok = arrayDelete(&array, 1, &value);
    if (ok) {
        printf("Deleted: %d\n", value);
    }
    int sorted[] = {10, 20, 30, 40};
    int index = recursiveBinarySearch(sorted, 0, 3, 30);
    printf("Recursive search: %d\n", index);
    printf("0! = %llu, 5! = %llu\n", factorial(0), factorial(5));
    const int matrix[2][3] = {{1, 2, 3}, {4, 5, 6}};
    printf("Matrix sum: %d\n", sumMatrix(matrix, 2));
    return 0;
}

```


> **Q: Why are retrieval and insertion different costs?**

> Answer: Indexing computes one address: retrieval and replacement are O(1). Insertion or deletion may shift O(n) values. Factorial is Theta(n) time and call space. Binary search halves its interval, giving O(log n) worst-case time.


### Dynamic Two Dimensional Arrays and Ragged Arrays

File: `dynamic_rows.h`

A row-pointer table is an array of pointers, with one separately allocated integer array per row. A rectangle uses equal row lengths. A ragged table allows different lengths. Neither layout is a genuine contiguous int matrix[R][C].


#### Allocate rows with explicit lengths

Limit dimensions to small classroom sizes before multiplying byte counts. Zero-length rows are represented by NULL. allocate stops the demo on failure. Initialize every element before reading it.

```c

/* Header guard: include these declarations only once in this C file. */
#ifndef COURSE_DYNAMIC_ROWS_H
/* Remember that this header has already been included. */
#define COURSE_DYNAMIC_ROWS_H
/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
int **createRows(int rows, const int lengths[])
{
    if (rows < 1 || rows > 100) {
        return NULL;
    }
    for (int row = 0; row < rows; row++) {
        if (lengths[row] < 0 || lengths[row] > 1000) {
            return NULL;
        }
    }
    int **table = allocate((size_t)rows * sizeof *table);
    for (int row = 0; row < rows; row++) {
        table[row] = NULL;
        if (lengths[row] > 0) {
            table[row] = allocate((size_t)lengths[row] * sizeof **table);
            for (int column = 0; column < lengths[row]; column++) {
                table[row][column] = 0;
            }
        }
    }
    return table;
}

```


#### Display each row using its own length

The number of columns is not recoverable from int **. We pass row lengths alongside the table.

```c

void printRows(int *const table[], int rows, const int lengths[])
{
    for (int row = 0; row < rows; row++) {
        for (int column = 0; column < lengths[row]; column++) {
            printf("%d ", table[row][column]);
        }
        putchar('\n');
    }
}

```


#### Free the rows before the row pointer table

free(table) alone would release only the pointer array. Every separately allocated row must be released too. free(NULL) is allowed for a zero-length row.

```c

void destroyRows(int **table, int rows)
{
    for (int row = 0; row < rows; row++) {
        free(table[row]);
    }
    free(table);
}
#endif /* End of this header guard. */

```


> **Q: Why not pass int double pointer to every matrix function?**

> Answer: int ** first reaches a row-pointer object, then reaches an integer. int (*)[3] steps directly across three-integer row objects. Same-looking table[row][column] syntax does not make the layouts interchangeable. Creating, initializing, and printing these tables costs O(rows + total elements).


### Dynamic Array Example

File: `20_dynamic_tables.c`


#### Main logic

Use unequal lengths for a ragged table and equal lengths for a rectangle. Then show a pointer to an actual row array; its step size is one entire row.

```c

/* Reuse the dynamic row allocation and cleanup helpers. */
#include "dynamic_rows.h"
int main(void)
{
    int lengths[] = {2, 0, 4};
    int **ragged = createRows(3, lengths);
    if (ragged == NULL) {
        return 1;
    }
    ragged[0][1] = 7;
    ragged[2][3] = 9;
    printRows(ragged, 3, lengths);
    destroyRows(ragged, 3);
    int widths[] = {3, 3};
    int **rectangle = createRows(2, widths);
    if (rectangle == NULL) {
        return 1;
    }
    rectangle[1][2] = 42;
    printRows(rectangle, 2, widths);
    destroyRows(rectangle, 2);
    int fixed[2][3] = {{1, 2, 3}, {4, 5, 6}};
    int (*rowPointer)[3] = fixed;
    printf("Row pointer reaches: %d\n", *(*(rowPointer + 1) + 2));
    return 0;
}

```


### Structures, Arrays of Structures and Structure Pointers

File: `21_records.c`

A structure groups related fields. An array of structures stores several complete records. A nested structure groups a smaller part of a record. These examples also show a function returning a pointer to an existing caller-owned object.


#### Define a record with an array and a nested structure

Each Student owns its name array and marks array. Its Date is embedded, not separately allocated. typedef names a type; enum gives named integer choices.

```c

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef enum { CS5, CS6 } Section;
typedef struct {
    int day;
    int month;
    int year;
} Date;
typedef struct {
    char name[40];
    int roll;
    float marks[2];
    Section section;
    Date joined;
} Student;

```


#### Read a record through a structure pointer

This small input format uses a single-word name followed by roll and two marks. The width 39 reserves one character for the null terminator. Read into a temporary so failed validation does not partially overwrite the caller's record.

```c

bool readStudent(Student *student)
{
    Student temporary = {0};
    int readCount = scanf("%39s %d %f %f", temporary.name,
                         &temporary.roll, &temporary.marks[0],
                         &temporary.marks[1]);
    if (readCount != 4) {
        return false;
    }
    if (temporary.roll < 1 || isfinite(temporary.marks[0]) == 0
        || isfinite(temporary.marks[1]) == 0) {
        return false;
    }
    for (int i = 0; i < 2; i++) {
        if (temporary.marks[i] < 0 || temporary.marks[i] > 100) {
            return false;
        }
    }
    temporary.section = CS6;
    temporary.joined = (Date){1, 8, 2026};
    *student = temporary;
    return true;
}

```


#### Return the student with the largest total

The returned pointer refers into the original array. It stays valid only while that array exists. A tie keeps the earlier record.

```c

Student *highestStudent(Student students[], int count)
{
    if (count < 1) {
        return NULL;
    }
    Student *best = &students[0];
    float bestTotal = best->marks[0] + best->marks[1];
    for (int i = 1; i < count; i++) {
        float total = students[i].marks[0] + students[i].marks[1];
        if (total > bestTotal) {
            best = &students[i];
            bestTotal = total;
        }
    }
    return best;
}

```


#### Display through a pointer

Use -> for fields reached through a structure pointer. A nested Date field then uses the ordinary dot operator.

```c

void printStudent(const Student *student)
{
    printf("%s roll %d marks %.1f %.1f joined %d/%d/%d\n",
           student->name, student->roll, student->marks[0],
           student->marks[1], student->joined.day,
           student->joined.month, student->joined.year);
}

```


#### Return a route to the larger caller owned integer

The function returns one supplied address. It never returns the address of a local temporary.

```c

int *largerAddress(int *first, int *second)
{
    if (*first >= *second) {
        return first;
    }
    return second;
}

```


#### Main logic

Enter two records, for example Caitlyn 1 80 90 and Rose 2 95 88. Then display the highest total and demonstrate a returned pointer.

```c

int main(void)
{
    Student students[2];
    puts("Enter name roll mark1 mark2 for two students:");
    for (int i = 0; i < 2; i++) {
        bool ok = readStudent(&students[i]);
        if (ok == false) {
            puts("Invalid student record");
            return 1;
        }
    }
    Student *best = highestStudent(students, 2);
    printStudent(best);
    int a = 10;
    int c = 20;
    int *larger = largerAddress(&a, &c);
    printf("Larger: %d\n", *larger);
    return 0;
}

```


> **Q: Can we assign and compare whole structures?**

> Answer: Assignment such as *student=temporary copies the complete structure, including its embedded arrays. C does not define == for whole structures. Compare meaningful fields individually; comparing a structure's raw bytes can be misleading because padding bytes need not match.


### Recursive Sorting and Searching of Student Records

File: `36_recursive_records.c`

The linking and sorting ideas stay the same when the stored value becomes a structure. Use small records so their totals fit int. No structure comparison with == is used.


#### Group fields and calculate derived totals

Each record owns three marks. The name points to a fixed string in this demo. Recalculate total and average after changing marks.

```c

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct {
    int roll;
    const char *name;
    int marks[3];
    int total;
    double average;
} Record;
void updateRecord(Record *record)
{
    record->total = 0;
    for (int i = 0; i < 3; i++) {
        record->total = record->total + record->marks[i];
    }
    record->average = record->total / 3.0;
}

```


#### Swap complete records through pointers

Moving only the roll number would attach the wrong name and marks to it. Move the complete structure.

```c

void swapRecords(Record *first, Record *second)
{
    Record temporary = *first;
    *first = *second;
    *second = temporary;
}

```


#### Recursive bubble sort finishes one suffix position

Perform one ordinary bubble pass, then recurse on count-1. If no swap happens, the entire array is sorted. This replaces the outer loop with recursion; it does not reduce the worst-case comparison count.

```c

void recursiveRecordBubble(Record records[], int count)
{
    if (count < 2) {
        return;
    }
    bool changed = false;
    for (int i = 0; i < count - 1; i++) {
        if ((records + i)->roll > (records + i + 1)->roll) {
            swapRecords(records + i, records + i + 1);
            changed = true;
        }
    }
    if (changed) {
        recursiveRecordBubble(records, count - 1);
    }
}

```


#### Recursive binary search uses sorted roll numbers

Do this before sorting by average. Once a different field determines order, binary search by roll no longer has its required ordering.

```c

int recursiveRecordSearch(const Record records[], int low, int high, int roll)
{
    if (low > high) {
        return -1;
    }
    int middle = low + (high - low) / 2;
    if (records[middle].roll == roll) {
        return middle;
    }
    if (roll < records[middle].roll) {
        return recursiveRecordSearch(records, low, middle - 1, roll);
    }
    return recursiveRecordSearch(records, middle + 1, high, roll);
}

```


#### Recursive insertion sort orders averages from high to low

First sort the shorter prefix, then insert the final saved record into that sorted prefix. Shift lower averages right. Equal averages do not cross.

```c

void recursiveRecordInsertion(Record records[], int count)
{
    if (count < 2) {
        return;
    }
    recursiveRecordInsertion(records, count - 1);
    Record key = records[count - 1];
    int left = count - 2;
    while (left >= 0 && records[left].average < key.average) {
        records[left + 1] = records[left];
        left--;
    }
    records[left + 1] = key;
}

```


#### Recursively count records passing every subject

A student passes only if all three marks are at least 40. Add one or zero to the answer from the shorter suffix.

```c

int countPassed(const Record records[], int count)
{
    if (count == 0) {
        return 0;
    }
    bool passed = true;
    for (int i = 0; i < 3; i++) {
        if (records[0].marks[i] < 40) {
            passed = false;
        }
    }
    int rest = countPassed(records + 1, count - 1);
    if (passed) {
        return rest + 1;
    }
    return rest;
}

```


#### Main logic

Update totals, sort by roll, search by roll, then sort by average. The search result is used before the second sort changes positions.

```c

int main(void)
{
    Record records[] = {{3,"C",{70,80,90},0,0},
                        {1,"A",{30,90,90},0,0},
                        {2,"B",{95,85,90},0,0}};
    for (int i = 0; i < 3; i++) {
        updateRecord(&records[i]);
    }
    recursiveRecordBubble(records, 3);
    int index = recursiveRecordSearch(records, 0, 2, 2);
    printf("Roll 2 index: %d Passed all subjects: %d\n",
           index, countPassed(records, 3));
    recursiveRecordInsertion(records, 3);
    for (int i = 0; i < 3; i++) {
        printf("%s roll %d average %.2f\n",
               records[i].name, records[i].roll, records[i].average);
    }
    return 0;
}

```


> **Q: Does recursion improve the sort order of growth?**

> Answer: No. Both recursive sorts remain O(n^2) in the worst case. They also use O(n) call space, unlike their O(1)-extra-space iterative versions. Recursive bubble can stop after one unchanged pass; recursive insertion still makes its chain of calls even on already ordered input.


### Pointer and Matrix Operations

File: `38_pointer_matrix_apps.c`

These compact examples cover the remaining pointer-array tutorial patterns: count, reverse, student totals, subject averages, attendance, and selected row/column operations. The existing swap and dynamic-row helpers are reused.


#### Count even and odd values through a pointer

The integer remainder test works for negative even values too. The two output counts start at zero.

```c

/* Reuse the search and sort functions already covered. */
#include "array_algorithms.h"
/* Reuse the dynamic row allocation and cleanup helpers. */
#include "dynamic_rows.h"
void countParity(const int values[], int count, int *even, int *odd)
{
    *even = 0;
    *odd = 0;
    const int *cursor = values;
    for (int i = 0; i < count; i++) {
        if (*cursor % 2 == 0) {
            (*even)++;
        } else {
            (*odd)++;
        }
        cursor++;
    }
}

```


#### Reverse an array in place using two routes

Handle short arrays before forming the last-element route. Swap the ends, then move both routes inward. The swap function was already explained with sorting.

```c

void reverseArray(int values[], int count)
{
    if (count < 2) {
        return;
    }
    int *left = values;
    int *right = values + count - 1;
    while (left < right) {
        swap(left, right);
        left++;
        right--;
    }
}

```


#### Compute student totals and subject averages

There are three columns. rows is positive and valid. Initialize both result arrays, then let each cell contribute once to its student total and its subject sum. Small mark totals fit int.

```c

void summarizeMarks(const int marks[][3], int rows,
                    int totals[], double averages[])
{
    for (int subject = 0; subject < 3; subject++) {
        averages[subject] = 0;
    }
    for (int student = 0; student < rows; student++) {
        totals[student] = 0;
        for (int subject = 0; subject < 3; subject++) {
            int value = *(*(marks + student) + subject);
            totals[student] = totals[student] + value;
            averages[subject] = averages[subject] + value;
        }
    }
    for (int subject = 0; subject < 3; subject++) {
        averages[subject] = averages[subject] / rows;
    }
}

```


#### Take the larger value at each matrix position

Equal dimensions and valid row counts are required. The comparison happens cell by cell, not between complete rows.

```c

void matrixMaximum(const int first[][3], const int second[][3],
                    int result[][3], int rows)
{
    for (int row = 0; row < rows; row++) {
        for (int column = 0; column < 3; column++) {
            int maximum = first[row][column];
            if (second[row][column] > maximum) {
                maximum = second[row][column];
            }
            result[row][column] = maximum;
        }
    }
}

```


#### Print a selected dynamic row

The lengths array says how many values that row contains. Return false for an invalid row number.

```c

bool printSelectedRow(int *const table[], int rows,
                       const int lengths[], int row)
{
    if (row < 0 || row >= rows) {
        return false;
    }
    for (int column = 0; column < lengths[row]; column++) {
        printf("%d ", table[row][column]);
    }
    putchar('\n');
    return true;
}

```


#### Print a selected column only if it exists in every row

Validate the complete column before printing anything. In a ragged table, a column may exist in one row and be missing in another.

```c

bool printSelectedColumn(int *const table[], int rows,
                          const int lengths[], int column)
{
    if (column < 0) {
        return false;
    }
    for (int row = 0; row < rows; row++) {
        if (column >= lengths[row]) {
            return false;
        }
    }
    for (int row = 0; row < rows; row++) {
        printf("%d ", table[row][column]);
    }
    putchar('\n');
    return true;
}

```


#### Replace a selected row

Only the requested row changes. Its length does not change.

```c

bool replaceSelectedRow(int **table, int rows, const int lengths[],
                         int row, int value)
{
    if (row < 0 || row >= rows) {
        return false;
    }
    for (int column = 0; column < lengths[row]; column++) {
        table[row][column] = value;
    }
    return true;
}

```


#### Attendance uses calloc to start everyone absent

Roll numbers in this particular example are 1 through count, while array indices still start at 0. The caller must free the returned status array.

```c

int *createAttendance(int count)
{
    if (count < 1 || count > 1000) {
        return NULL;
    }
    return calloc((size_t)count, sizeof(int));
}

```


#### Translate a roll number into its array index

Check the roll before subtracting one. Repeatedly marking the same roll is harmless.

```c

bool markPresent(int status[], int count, int roll)
{
    if (roll < 1 || roll > count) {
        return false;
    }
    status[roll - 1] = 1;
    return true;
}

```


#### Main logic

Use small inputs to exercise each operation. The matrix code and the dynamic row-table code use different parameter types because their layouts differ.

```c

int main(void)
{
    int values[] = {1, 2, 3, 4};
    int even;
    int odd;
    countParity(values, 4, &even, &odd);
    printf("Even %d Odd %d\n", even, odd);
    reverseArray(values, 4);
    printArray(values, 4);
    const int marks[2][3] = {{80, 70, 90}, {60, 90, 80}};
    int totals[2];
    double averages[3];
    summarizeMarks(marks, 2, totals, averages);
    printf("Totals: %d %d Subject 0 average: %.1f\n",
           totals[0], totals[1], averages[0]);
    const int other[2][3] = {{85, 60, 70}, {90, 50, 95}};
    int maximum[2][3];
    matrixMaximum(marks, other, maximum, 2);
    printf("Maximum at [1][2]: %d\n", maximum[1][2]);
    int lengths[] = {3, 3};
    int **table = createRows(2, lengths);
    if (table == NULL) {
        return 1;
    }
    replaceSelectedRow(table, 2, lengths, 1, 7);
    printSelectedRow(table, 2, lengths, 1);
    printSelectedColumn(table, 2, lengths, 2);
    destroyRows(table, 2);
    int *attendance = createAttendance(4);
    if (attendance == NULL) {
        return 1;
    }
    markPresent(attendance, 4, 2);
    for (int i = 0; i < 4; i++) {
        printf("Roll %d present %d\n", i + 1, attendance[i]);
    }
    free(attendance);
    return 0;
}

```


> **Q: Why is a row operation cheaper than scanning the whole table?**

> Answer: Printing or replacing row r touches only lengths[r] cells. A column operation touches one cell per row, after checking that each row has that column. A full marks summary must inspect every supplied mark. Representation and requested output determine how much work is necessary.


## 2 Searching and Sorting

Linear search, binary search, bubble sort, selection sort, and insertion sort.


### Searching and Sorting Algorithms

File: `array_algorithms.h`

All searches return a zero-based index or -1. All sorts rearrange the supplied array in place. Sorting and searching are included from Lab 1, even though the supplied theory syllabus does not list a separate sorting unit.


#### One swap one responsibility

Exchange two integers through their addresses. Three assignments implement one logical swap; counting assignments and counting swaps are different measurements.

```c

/* Header guard: include these declarations only once in this C file. */
#ifndef COURSE_ARRAY_ALGORITHMS_H
/* Remember that this header has already been included. */
#define COURSE_ARRAY_ALGORITHMS_H
/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
void swap(int *first, int *second)
{
    int temporary = *first;
    *first = *second;
    *second = temporary;
}

```


#### Linear Search

Inspect each position and stop at the first match. The rule we keep is that every earlier position has already been checked and was not the key.

```c

int linearSearch(const int values[], int count, int key)
{
    for (int i = 0; i < count; i++) {
        if (values[i] == key) {
            return i;
        }
    }
    return -1;
}

```


#### Binary Search

Before calling: ascending sorted input. Keep an inclusive candidate interval [low, high]. The comparison at middle eliminates a half only because the remaining values are ordered. This implementation may return any matching occurrence.

```c

int binarySearch(const int values[], int count, int key)
{
    int low = 0;
    int high = count - 1;
    while (low <= high) {
        int middle = low + (high - low) / 2;
        if (values[middle] == key) {
            return middle;
        }
        if (key < values[middle]) {
            high = middle - 1;
        } else {
            low = middle + 1;
        }
    }
    return -1;
}

```


#### Bubble Sort

Compare neighbors and swap only when the left value is larger. The largest remaining value travels to the end of the unsorted prefix. A pass with no swaps proves the entire remaining prefix is ordered, so we stop.

```c

void bubbleSort(int values[], int count)
{
    for (int end = count - 1; end > 0; end--) {
        bool changed = false;
        for (int i = 0; i < end; i++) {
            if (values[i] > values[i + 1]) {
                swap(&values[i], &values[i + 1]);
                changed = true;
            }
        }
        if (changed == false) {
            break;
        }
    }
}

```


> **Notice: Bubble sort why quadratic**

> On reverse input, comparisons are (n-1)+(n-2)+...+1 = n(n-1)/2. Adjacent swaps also reach that number. On [4,3,2,1]: pass 1 gives [3,2,1,4] with 3 swaps; pass 2 gives [2,1,3,4] with 2; pass 3 gives [1,2,3,4] with 1. Total: 6 comparisons and 6 swaps.

> On sorted input this optimized version makes n-1 comparisons and zero swaps: best time Theta(n), worst Theta(n^2).


#### Selection Sort

Find the minimum of the unsorted suffix, then perform at most one swap for that pass. Do not swap whenever a smaller candidate appears: that would be a different implementation with a different swap bill.

```c

void selectionSort(int values[], int count)
{
    for (int position = 0; position < count - 1; position++) {
        int minimum = position;
        for (int i = position + 1; i < count; i++) {
            if (values[i] < values[minimum]) {
                minimum = i;
            }
        }
        if (minimum != position) {
            swap(&values[position], &values[minimum]);
        }
    }
}

```


> **Notice: Selection sort fewer swaps same search bill**

> For [4,3,2,1], pass 1 swaps 4 and 1: [1,3,2,4]. Pass 2 swaps 3 and 2: [1,2,3,4]. Pass 3 does not swap. Total: 6 comparisons, 2 swaps. In general there are at most n-1 swaps overall, at most one per pass.

> Comparisons remain n(n-1)/2 even when input is sorted, so best and worst time are Theta(n^2).


#### Insertion Sort

Before each iteration, positions 0 through position-1 are sorted. Save the key, shift only strictly larger predecessors one position right, and fill the gap. The left >= 0 check must occur before reading values[left].

```c

void insertionSort(int values[], int count)
{
    for (int position = 1; position < count; position++) {
        int key = values[position];
        int left = position - 1;
        while (left >= 0 && values[left] > key) {
            values[left + 1] = values[left];
            left--;
        }
        values[left + 1] = key;
    }
}

```


> **Notice: Insertion sort notice the loop body**

> If key is at least its predecessor, the while condition is checked but the loop body never runs. We still perform one outer iteration and write key back. On sorted input: n-1 key comparisons, zero shifts, Theta(n) time. On reverse input: n(n-1)/2 shifts, Theta(n^2) time.

> This implementation performs zero swaps on every input; shifts are the meaningful movement count.


> **Notice: Insertion trace**

> Input [4,3,2,1]. Insert 3: shift 4, then [3,4,2,1]. Insert 2: shift 4 and 3, then [2,3,4,1]. Insert 1: shift 4,3,2, then [1,2,3,4]. Six shifts, three placements of key. Saving key first matters: the original array position may be overwritten during shifting.


#### Printing is shared plumbing

Keep output separate from algorithms. None of the sort functions should need to know whether a student wants a table, a terminal line, or no output.

```c

void printArray(const int values[], int count)
{
    for (int i = 0; i < count; i++) {
        printf("%d ", values[i]);
    }
    putchar('\n');
}
#endif /* End of this header guard. */

```


> **Q: Would you keep duplicate records in order?**

> Answer: Bubble and insertion are stable here because equal keys do not cross. Selection need not be: [2A,2B,1] becomes [1,2B,2A] after the first swap. All three use O(1) extra space. Linear search is best Theta(1), worst Theta(n); binary search is best Theta(1), worst Theta(log n).

> Sorting a fresh array merely to make one binary search is not automatically a saving.


### Searching and Sorting Example

File: `03_search_sort.c`

Search returns a zero-based index or -1. Each sort changes the given array. Count comparisons, swaps, and shifts separately.


#### Main logic

Give each sort an independent copy of the same input. Calling three sorts successively on one array would give the second and third algorithms an already sorted input. Search only after the binary-search precondition has been established.

```c

/* Reuse the search and sort functions already covered. */
#include "array_algorithms.h"
int main(void)
{
    int bubble[] = {4, 3, 2, 1};
    int selection[] = {4, 3, 2, 1};
    int insertion[] = {4, 3, 2, 1};
    bubbleSort(bubble, 4);
    selectionSort(selection, 4);
    insertionSort(insertion, 4);
    printArray(bubble, 4);
    printArray(selection, 4);
    printArray(insertion, 4);
    int index = linearSearch(bubble, 4, 3);
    printf("Linear index: %d\n", index);
    index = binarySearch(bubble, 4, 3);
    printf("Binary index: %d\n", index);
    return 0;
}

```


## 3 Strings and Sparse Matrices

Bounded string operations, two-dimensional arrays, sparse representation, and transpose.


### String Length, Comparison, Concatenation and Substrings

File: `04_strings.c`

These bounded string operations avoid library string-processing functions inside their algorithms. Before calling: inputs are valid null-terminated strings; source and destination do not overlap. A capacity includes room for the final null character.


#### Find the finish line

Count characters until the null character. This count excludes the terminator itself. The caller must supply a properly terminated string.

```c

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
size_t textLength(const char text[])
{
    size_t length = 0;
    while (text[length] != '\0') {
        length++;
    }
    return length;
}

```


#### Compare meanings not pointer addresses

Advance through equal characters. At the first difference, compare unsigned character values. Return a negative, zero, or positive result. Comparing the pointers themselves would compare routes rather than the text.

```c

int compareText(const char first[], const char second[])
{
    size_t i = 0;
    while (first[i] != '\0' && first[i] == second[i]) {
        i++;
    }
    return (unsigned char)first[i] - (unsigned char)second[i];
}

```


#### Insertion opens a gap from the right

Validate position and capacity before changing anything. Move the terminator too. Copy backward so an unread character is not overwritten. The position may equal the current length, which makes this operation concatenation.

```c

bool insertText(char text[], size_t capacity,
                size_t position, const char addition[])
{
    size_t length = textLength(text);
    size_t extra = textLength(addition);
    if (position > length || length >= capacity) {
        return false;
    }
    if (extra > capacity - length - 1) {
        return false;
    }
    size_t i = length + 1;
    while (i > position) {
        i--;
        text[i + extra] = text[i];
    }
    for (i = 0; i < extra; i++) {
        text[position + i] = addition[i];
    }
    return true;
}

```


#### Deletion closes the gap from the left

Require the entire requested range to exist. Shift its suffix, including the terminator, left over the removed characters. This time forward copying is safe.

```c

bool deleteText(char text[], size_t position, size_t count)
{
    size_t length = textLength(text);
    if (position > length || count > length - position) {
        return false;
    }
    size_t i = position;
    while (i <= length - count) {
        text[i] = text[i + count];
        i++;
    }
    return true;
}

```


#### Main logic

Build a title through insertion, append at the current length, and delete a substring. Operation results are stored before they are checked. This keeps mutation and branching visibly separate.

```c

int main(void)
{
    char title[80] = "Sensei";
    bool ok = insertText(title, sizeof title, 0, "Rogue ");
    if (ok == false) {
        return 1;
    }
    size_t end = textLength(title);
    ok = insertText(title, sizeof title, end, " returns");
    if (ok == false) {
        return 1;
    }
    puts(title);
    ok = deleteText(title, 0, 6);
    if (ok == false) {
        return 1;
    }
    puts(title);
    printf("Comparison: %d\n", compareText(title, "Sensei returns"));
    return 0;
}

```


> **Q: Why this direction?**

> Answer: Insert X at index 1 in ABC. Copy the null character to index 4, C to 3, B to 2, then X to 1: AXBC. Copying forward would overwrite B before moving it.

> Length and comparison take O(n); insertion and deletion take O(n+m) and O(n) respectively, including the length scans. If only a constant-sized substring is inserted, insertion is O(n).


### Sparse Matrix Representation and Transpose

File: `05_sparse.c`

A triplet stores row, column, and value for one nonzero entry. Dimensions belong to the Sparse object rather than a fake first data term. This demo supports up to CAPACITY nonzero entries and dimensions up to CAPACITY. Entries are in row-major order, unique, and nonzero.


#### Define the representation

count is the number of meaningful triplets. Capacity is physical storage. The distinction is the same one used by an array-backed stack.

```c

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct {
    int row;
    int column;
    int value;
} Term;
typedef struct {
    int rows;
    int columns;
    int count;
    Term terms[CAPACITY];
} Sparse;

```


#### Convert a rectangular matrix

A C parameter with [][3] points to rows of three integers. Scan row first, then column, and store only nonzero cells. This produces the ordering required by later merging algorithms.

```c

Sparse compressMatrix(int rows, const int matrix[][3])
{
    Sparse result = {0};
    if (rows < 0 || rows > CAPACITY / 3) {
        fprintf(stderr, "Matrix too large\n");
        exit(EXIT_FAILURE);
    }
    result.rows = rows;
    result.columns = 3;
    for (int row = 0; row < rows; row++) {
        for (int column = 0; column < 3; column++) {
            if (matrix[row][column] != 0) {
                Term entry = {row, column, matrix[row][column]};
                result.terms[result.count] = entry;
                result.count++;
            }
        }
    }
    return result;
}

```


#### Simple Sparse Matrix Transpose

For each old column, scan all entries and copy its members with row and column exchanged. The result is row-major ordered. Before calling: a valid Sparse object with dimensions and count within capacity.

```c

Sparse simpleTranspose(const Sparse *input)
{
    Sparse output = {0};
    output.rows = input->columns;
    output.columns = input->rows;
    for (int column = 0; column < input->columns; column++) {
        for (int i = 0; i < input->count; i++) {
            Term entry = input->terms[i];
            if (entry.column == column) {
                Term moved = {entry.column, entry.row, entry.value};
                output.terms[output.count] = moved;
                output.count++;
            }
        }
    }
    return output;
}

```


#### Fast Sparse Matrix Transpose

Count entries in each old column. Prefix sums tell us where each new row begins. nextPosition then moves inside that reserved segment as entries arrive. No search through the output is needed.

```c

Sparse fastTranspose(const Sparse *input)
{
    Sparse output = {0};
    int columnCount[CAPACITY] = {0};
    int nextPosition[CAPACITY] = {0};
    output.rows = input->columns;
    output.columns = input->rows;
    output.count = input->count;
    for (int i = 0; i < input->count; i++) {
        int column = input->terms[i].column;
        columnCount[column]++;
    }
    for (int column = 1; column < input->columns; column++) {
        nextPosition[column] = nextPosition[column - 1]
                             + columnCount[column - 1];
    }
    for (int i = 0; i < input->count; i++) {
        Term entry = input->terms[i];
        int position = nextPosition[entry.column];
        Term moved = {entry.column, entry.row, entry.value};
        output.terms[position] = moved;
        nextPosition[entry.column]++;
    }
    return output;
}

```


#### Display only meaningful entries

Printing dimensions makes it clear that a zero matrix still has a shape even though count is zero.

```c

void printSparse(const Sparse *matrix)
{
    printf("%d rows %d columns %d terms\n",
           matrix->rows, matrix->columns, matrix->count);
    for (int i = 0; i < matrix->count; i++) {
        Term entry = matrix->terms[i];
        printf("(%d,%d) = %d\n", entry.row, entry.column, entry.value);
    }
}

```


#### Main logic

Construct the same transpose through two algorithms. Later tests compare every output term rather than trusting a plausible-looking printout.

```c

int main(void)
{
    const int matrix[3][3] = {{0, 7, 0}, {0, 0, 9}, {5, 0, 4}};
    Sparse original = compressMatrix(3, matrix);
    Sparse slow = simpleTranspose(&original);
    Sparse fast = fastTranspose(&original);
    printSparse(&original);
    printSparse(&slow);
    printSparse(&fast);
    return 0;
}

```


> **Notice: Fast transpose trace**

> Original entries: (0,1,7), (1,2,9), (2,0,5), (2,2,4). Old-column counts: [1,1,2]. Segment starts: [0,1,2]. The four input entries go to output positions 1,2,0,3. Result: (0,2,5), (1,0,7), (2,1,9), (2,2,4).


> **Q: Why counting helps?**

> Answer: With c columns and t nonzeros, simple transpose costs Theta(c*t+c), fast transpose Theta(c+t). The +c covers even the empty-input loops. This fixed-capacity implementation uses constant-sized workspace; a version sized to c uses Theta(c) additional workspace. Compression costs Theta(rows*columns).

> Sparse storage saves space only when nonzeros are sufficiently rare to offset the row/column stored information.


### Linked Representation of Sparse Matrices

File: `22_sparse_linked.c`

Each node stores one nonzero entry. Dimensions and the tail route belong to the container. This uses memory proportional to the nonzeros, plus one link per stored entry.


#### Define a sparse entry node

A NULL head means no nonzero entries, not a matrix with no shape.

```c

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct SparseNode {
    int row;
    int column;
    int value;
    struct SparseNode *next;
} SparseNode;
typedef struct {
    int rows;
    int columns;
    SparseNode *head;
    SparseNode *tail;
} LinkedSparse;

```


#### Append one nonzero entry

Before calling: coordinates are valid and arrive in row-major order without duplicates. Skip zero. The stored tail makes each append O(1).

```c

void appendEntry(LinkedSparse *matrix, int row, int column, int value)
{
    if (value == 0) {
        return;
    }
    SparseNode *node = allocate(sizeof *node);
    node->row = row;
    node->column = column;
    node->value = value;
    node->next = NULL;
    if (matrix->tail == NULL) {
        matrix->head = node;
    } else {
        matrix->tail->next = node;
    }
    matrix->tail = node;
}

```


#### Release all entries

Save next before freeing. Reset both endpoints.

```c

void clearEntries(LinkedSparse *matrix)
{
    SparseNode *current = matrix->head;
    while (current != NULL) {
        SparseNode *next = current->next;
        free(current);
        current = next;
    }
    matrix->head = NULL;
    matrix->tail = NULL;
}

```


#### Main logic

Scan a dense matrix and reuse appendEntry. Then walk only the stored nonzeros.

```c

int main(void)
{
    const int dense[2][3] = {{0, 7, 0}, {4, 0, 9}};
    LinkedSparse matrix = {2, 3, NULL, NULL};
    for (int row = 0; row < matrix.rows; row++) {
        for (int column = 0; column < matrix.columns; column++) {
            appendEntry(&matrix, row, column, dense[row][column]);
        }
    }
    for (SparseNode *p = matrix.head; p != NULL; p = p->next) {
        printf("(%d,%d) = %d\n", p->row, p->column, p->value);
    }
    clearEntries(&matrix);
    return 0;
}

```


> **Q: Is linked sparse storage automatically faster?**

> Answer: No. Sequential traversal is O(t), but searching a coordinate can also take O(t). Array triplets are contiguous and often cheaper to scan. Links make some updates easier, but cost extra space and do not provide random access.


## 4 Linked Lists and Polynomials

Singly, doubly, and circular linked lists; linked stacks and queues; polynomials.


### Singly Linked List Operations

File: `slist.h`

This shared library keeps both head and tail. The list owns every node it links. A caller must initialize a List with {NULL,NULL}. Indices are zero based. The tail route makes appending cheap; it does not tell us the predecessor of the tail.


#### Define nodes and the list object

A self-referential structure contains a pointer to its own type, not another complete embedded node. The empty rule is head==NULL and tail==NULL.

```c

/* Header guard: include these declarations only once in this C file. */
#ifndef SLIST_H
/* Remember that this header has already been included. */
#define SLIST_H
/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct Node {
    int value;
    struct Node *next;
} Node;
typedef struct {
    Node *head;
    Node *tail;
} List;

```


#### Create one detached node

allocate centralizes the demo's allocation-failure policy. The new node is initialized completely before we publish a route to it from the list.

```c

static inline Node *newNode(int value)
{
    Node *node = allocate(sizeof *node);
    node->value = value;
    node->next = NULL;
    return node;
}

```


#### Insert at the head

Point the new node to the old first node, then make it the head. If the list was empty, the new node must also become tail. This is the operation later used for stack push.

```c

static inline void prepend(List *list, int value)
{
    Node *node = newNode(value);
    node->next = list->head;
    if (list->head == NULL) {
        list->tail = node;
    }
    list->head = node;
}

```


#### Insert at the tail

If a tail exists, let it point to the new node. Otherwise this is the first node. Finally record the new tail. No traversal is needed because we keep tail.

```c

static inline void append(List *list, int value)
{
    Node *node = newNode(value);
    if (list->tail == NULL) {
        list->head = node;
    } else {
        list->tail->next = node;
    }
    list->tail = node;
}

```


#### Delete at the head

Save the old head, copy its value, advance head, and then free the old node. When the last node leaves, clear tail too. Reading old->next after free would use an object whose lifetime has ended.

```c

static inline bool removeFront(List *list, int *value)
{
    if (list->head == NULL) {
        return false;
    }
    Node *old = list->head;
    *value = old->value;
    list->head = old->next;
    if (list->head == NULL) {
        list->tail = NULL;
    }
    free(old);
    return true;
}

```


#### Find a node at an index

Stop either at the requested position or at NULL. A negative position is invalid. This helper is shared by positional insertion and deletion.

```c

static inline Node *nodeAt(const List *list, int position)
{
    if (position < 0) {
        return NULL;
    }
    Node *current = list->head;
    for (int i = 0; i < position && current != NULL; i++) {
        current = current->next;
    }
    return current;
}

```


#### Insert after finding the predecessor

Index zero reuses prepend. Otherwise find index position-1. Connecting node->next before previous->next keeps the old suffix reachable. Inserting after the tail also updates tail.

```c

static inline bool insertAt(List *list, int position, int value)
{
    if (position < 0) {
        return false;
    }
    if (position == 0) {
        prepend(list, value);
        return true;
    }
    Node *previous = nodeAt(list, position - 1);
    if (previous == NULL) {
        return false;
    }
    Node *node = newNode(value);
    node->next = previous->next;
    previous->next = node;
    if (previous == list->tail) {
        list->tail = node;
    }
    return true;
}

```


#### Delete after finding the predecessor

Index zero reuses removeFront. For another position, bypass the target and update tail if necessary. The predecessor search costs time even though changing the links costs only a few assignments.

```c

static inline bool removeAt(List *list, int position, int *value)
{
    if (position < 0) {
        return false;
    }
    if (position == 0) {
        return removeFront(list, value);
    }
    Node *previous = nodeAt(list, position - 1);
    if (previous == NULL || previous->next == NULL) {
        return false;
    }
    Node *old = previous->next;
    *value = old->value;
    previous->next = old->next;
    if (old == list->tail) {
        list->tail = previous;
    }
    free(old);
    return true;
}

```


#### Search follows routes rather than computing addresses

An array can jump to index i. A singly linked list reaches the ith node by walking through earlier links. Search returns a borrowed pointer; the list still owns the node.

```c

static inline Node *findNode(const List *list, int value)
{
    Node *current = list->head;
    while (current != NULL) {
        if (current->value == value) {
            return current;
        }
        current = current->next;
    }
    return NULL;
}

```


#### Singly Linked List Reversal

Before changing current->next, save the original next node. previous is the reversed prefix; current begins the untouched suffix. The old head becomes the new tail.

```c

static inline void reverseList(List *list)
{
    Node *previous = NULL;
    Node *current = list->head;
    list->tail = list->head;
    while (current != NULL) {
        Node *next = current->next;
        current->next = previous;
        previous = current;
        current = next;
    }
    list->head = previous;
}

```


#### Visit each value

The cursor borrows links. Moving it does not move head and does not remove nodes.

```c

static inline void printList(const List *list)
{
    const Node *current = list->head;
    while (current != NULL) {
        printf("%d ", current->value);
        current = current->next;
    }
    putchar('\n');
}

```


#### Release every owned node

Cleanup reuses the already explained front deletion. A separate temporary receives discarded values. The list ends in a valid empty state.

```c

static inline void clearList(List *list)
{
    while (list->head != NULL) {
        int discarded;
        removeFront(list, &discarded);
    }
}
#endif /* End of this header guard. */

```


> **Q: Which end should be top?**

> Answer: Try head as top. Push uses prepend and pop uses removeFront: both O(1). Try tail as top in this singly linked list. Push can use append in O(1), but pop needs the node before tail, so it costs O(n).

> A tail pointer points to the last node, not the node before it. A doubly linked list changes that tradeoff because tail->prev exists.


> **Q: Which ends should a queue use?**

> Answer: Insert at rear using append, delete at front using removeFront: both O(1). Insert at head and delete at tail still gives FIFO, but deleting tail costs O(n) here. We choose rear insertion and front deletion because they give FIFO with two cheap operations.

> The choice follows the links we actually have.


> **Notice: Reverse trace**

> Start with 10 followed by 20 followed by 30. Step 1 saves 20, makes 10.next NULL, then previous=10,current=20. Step 2 saves 30, makes 20.next point to 10. Step 3 saves NULL, makes 30.next point to 20. Set head=30; tail is the old head 10.

> Time Theta(n), extra space O(1).


### Linked Stacks and Linked Queues

File: `08_linked_apps.c`

Reuse slist.h. A stack inserts and deletes at head. A queue inserts at tail and deletes at head. Both choices give O(1) operations.


#### Stack push uses the head

No separate top pointer is needed because list.head already has that role.

```c

/* Reuse the singly linked list types and operations already covered. */
#include "slist.h"
void linkedPush(List *stack, int value)
{
    prepend(stack, value);
}

```


#### Stack pop uses the same head

The bool result distinguishes empty from a stored value such as -1.

```c

bool linkedPop(List *stack, int *value)
{
    return removeFront(stack, value);
}

```


#### Queue insertion uses the tail

The oldest node stays at head. Newly arriving nodes go behind every waiting node.

```c

void linkedEnqueue(List *queue, int value)
{
    append(queue, value);
}

```


#### Queue deletion uses the head

Exactly the same removal operation serves a different access policy because insertion happens at the other end.

```c

bool linkedDequeue(List *queue, int *value)
{
    return removeFront(queue, value);
}

```


#### Merge sorted lists without creating replacement nodes

Before calling: two disjoint ascending lists and an empty destination. A local dummy node gives us a stable place to attach the first result node. Move the smaller head into the result until one input is empty, then attach the rest.

The original list objects are reset so ownership is not duplicated.

```c

void mergeLists(List *first, List *second, List *result)
{
    Node dummy = {0, NULL};
    Node *last = &dummy;
    Node *a = first->head;
    Node *b = second->head;
    while (a != NULL && b != NULL) {
        if (a->value <= b->value) {
            last->next = a;
            a = a->next;
        } else {
            last->next = b;
            b = b->next;
        }
        last = last->next;
    }
    if (a != NULL) {
        last->next = a;
    } else {
        last->next = b;
    }
    while (last->next != NULL) {
        last = last->next;
    }
    result->head = dummy.next;
    if (result->head == NULL) {
        result->tail = NULL;
    } else {
        result->tail = last;
    }
    first->head = NULL;
    first->tail = NULL;
    second->head = NULL;
    second->tail = NULL;
}

```


#### Peek at the head of a linked stack or queue

Both selected representations remove at head. One observer can read that value without changing links.

```c

bool peekListFront(const List *list, int *value)
{
    if (list->head == NULL) {
        return false;
    }
    *value = list->head->value;
    return true;
}

```


#### Main logic

First use positional operations and reversal. Then put the same values into a stack and queue and compare the first value removed. Finally merge two sorted lists, print, and clear all owners.

```c

int main(void)
{
    List list = {NULL, NULL};
    append(&list, 10);
    append(&list, 30);
    bool ok = insertAt(&list, 1, 20);
    if (ok == false) {
        return 1;
    }
    reverseList(&list);
    printList(&list);
    int value;
    ok = removeAt(&list, 1, &value);
    if (ok) {
        printf("Removed: %d\n", value);
    }
    Node *found = findNode(&list, 10);
    printf("Found 10: %d\n", found != NULL);
    clearList(&list);
    List stack = {NULL, NULL};
    List queue = {NULL, NULL};
    for (int i = 1; i <= 3; i++) {
        linkedPush(&stack, i);
        linkedEnqueue(&queue, i);
    }
    ok = linkedPop(&stack, &value);
    if (ok) {
        printf("Stack gives: %d\n", value);
    }
    ok = linkedDequeue(&queue, &value);
    if (ok) {
        printf("Queue gives: %d\n", value);
    }
    clearList(&stack);
    clearList(&queue);
    List first = {NULL, NULL};
    List second = {NULL, NULL};
    List result = {NULL, NULL};
    append(&first, 1);
    append(&first, 4);
    append(&second, 2);
    append(&second, 3);
    mergeLists(&first, &second, &result);
    printList(&result);
    clearList(&result);
    return 0;
}

```


> **Notice: The dummy is not a student record**

> dummy.value is never part of the result. dummy.next is the first real node. The returned result does not contain &dummy, so its automatic lifetime is harmless. A permanent header node uses the same idea but lives as long as the container.

> Merge costs O(m+n) time and O(1) extra space.


### Circular Doubly Linked List Operations

File: `09_doubly_circular.c`

A doubly linked node has a previous route as well as a next route. A circular list replaces the NULL ending with a route back to the start. We use a circular doubly linked list with a permanent header, so an empty list has header.next==header and header.prev==header.


#### Create the header

The header carries no user value. It gives the first and last real nodes a valid neighbor even at the boundaries. Return a separately allocated header so its lifetime outlasts this function.

```c

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct DNode {
    int value;
    struct DNode *previous;
    struct DNode *next;
} DNode;
DNode *createHeader(void)
{
    DNode *header = allocate(sizeof *header);
    header->value = 0;
    header->previous = header;
    header->next = header;
    return header;
}

```


#### Insert between known neighbors

Before calling: left and right are adjacent nodes in the same list. Fill both routes of the new node, then make both neighbors acknowledge it. One direction alone is not a valid doubly linked insertion.

```c

void insertBetween(DNode *left, DNode *right, int value)
{
    DNode *node = allocate(sizeof *node);
    node->value = value;
    node->previous = left;
    node->next = right;
    left->next = node;
    right->previous = node;
}

```


#### Remove a known real node

Before calling: node belongs to this list and is not the header. Its two neighbors can bypass it in O(1), including when it is the only real node. Searching for the node is a separate cost.

```c

void removeKnown(DNode *node)
{
    DNode *left = node->previous;
    DNode *right = node->next;
    left->next = right;
    right->previous = left;
    free(node);
}

```


#### Traverse until the header returns

Do not test current!=NULL in a circular list: there is no NULL ending. Stop before processing the header again.

```c

void printCircular(const DNode *header)
{
    const DNode *current = header->next;
    while (current != header) {
        printf("%d ", current->value);
        current = current->next;
    }
    putchar('\n');
}

```


#### Walk backward through previous

The last real node is header.previous. The same stopping rule works in reverse.

```c

void printBackward(const DNode *header)
{
    const DNode *current = header->previous;
    while (current != header) {
        printf("%d ", current->value);
        current = current->previous;
    }
    putchar('\n');
}

```


#### Concatenate by transferring ownership

Before calling: distinct valid headers. Attach the second list's real nodes after the first list's tail, then reconnect to the first header. Reset the second header to an empty ring. We do not copy nodes.

```c

void concatenate(DNode *first, DNode *second)
{
    if (second->next == second) {
        return;
    }
    DNode *aLast = first->previous;
    DNode *bFirst = second->next;
    DNode *bLast = second->previous;
    aLast->next = bFirst;
    bFirst->previous = aLast;
    bLast->next = first;
    first->previous = bLast;
    second->next = second;
    second->previous = second;
}

```


#### Destroy nodes before destroying the header

Repeatedly remove the first real node. Only after the ring is empty do we free its header.

```c

void destroyCircular(DNode *header)
{
    while (header->next != header) {
        removeKnown(header->next);
    }
    free(header);
}

```


#### Insert at a position in the header ring

Find the position, then reuse insertBetween. Position equal to length means append before the header. Larger or negative positions fail.

```c

bool circularDInsertAt(DNode *header, int position, int value)
{
    if (position < 0) {
        return false;
    }
    DNode *current = header->next;
    int index = 0;
    while (index < position && current != header) {
        current = current->next;
        index++;
    }
    if (index != position) {
        return false;
    }
    insertBetween(current->previous, current, value);
    return true;
}

```


#### Delete at a position in the header ring

The header is an ending marker, never a deletable user node. Once the real target is found, reuse removeKnown.

```c

bool circularDRemoveAt(DNode *header, int position, int *value)
{
    if (position < 0) {
        return false;
    }
    DNode *current = header->next;
    for (int i = 0; i < position && current != header; i++) {
        current = current->next;
    }
    if (current == header) {
        return false;
    }
    *value = current->value;
    removeKnown(current);
    return true;
}

```


#### Main logic

Insert at front by choosing header and header.next. Insert at rear by choosing header.previous and header. The same helper handles both ends and the empty case.

```c

int main(void)
{
    DNode *first = createHeader();
    DNode *second = createHeader();
    insertBetween(first, first->next, 20);
    insertBetween(first, first->next, 10);
    insertBetween(first->previous, first, 30);
    printCircular(first);
    printBackward(first);
    removeKnown(first->previous);
    insertBetween(second->previous, second, 40);
    concatenate(first, second);
    printCircular(first);
    destroyCircular(first);
    destroyCircular(second);
    return 0;
}

```


> **Q: What did the extra pointer buy?**

> Answer: Deleting a known tail is now O(1), because previous is available. Finding a value is still O(n). Adding previous does not make arbitrary search faster.

> For a linear DLL, first.previous and last.next would be NULL and boundary updates would need explicit checks; this header ring removes those special cases at the cost of one sentinel node.


### Circular Singly Linked List Operations

File: `circle.h`

Here first and last identify a circular singly linked list. Empty means both are NULL. Otherwise last.next must equal first. We keep this separate from the doubly linked ring so the two representations do not get mixed up.


#### Define the circle

Reuse the Node type and newNode helper. The node still has only one route. Keeping both endpoints does not create a route to the predecessor of last.

```c

/* Header guard: include these declarations only once in this C file. */
#ifndef COURSE_CIRCLE_H
/* Remember that this header has already been included. */
#define COURSE_CIRCLE_H
/* Reuse the singly linked list types and operations already covered. */
#include "slist.h"
typedef struct {
    Node *first;
    Node *last;
} Circle;

```


#### Insert at either end with one shared helper

In an empty circle the new node points to itself. Otherwise connect it after last and before first. For front insertion, first changes; for rear insertion, last changes.

```c

void circleInsert(Circle *circle, int value, bool atFront)
{
    Node *node = newNode(value);
    if (circle->first == NULL) {
        circle->first = node;
        circle->last = node;
        node->next = node;
        return;
    }
    node->next = circle->first;
    circle->last->next = node;
    if (atFront) {
        circle->first = node;
    } else {
        circle->last = node;
    }
}

```


#### Delete the first and repair the closing link

The singleton case empties both routes. Otherwise advance first and point last back to it before freeing the old node.

```c

bool circleRemoveFront(Circle *circle, int *value)
{
    if (circle->first == NULL) {
        return false;
    }
    Node *old = circle->first;
    *value = old->value;
    if (circle->first == circle->last) {
        circle->first = NULL;
        circle->last = NULL;
    } else {
        circle->first = old->next;
        circle->last->next = circle->first;
    }
    free(old);
    return true;
}

```


#### Delete the last after finding its predecessor

Reuse front removal for a singleton. Otherwise walk until previous.next is last. This is the O(n) cost that a last pointer alone cannot remove.

```c

bool circleRemoveRear(Circle *circle, int *value)
{
    if (circle->first == NULL) {
        return false;
    }
    if (circle->first == circle->last) {
        return circleRemoveFront(circle, value);
    }
    Node *previous = circle->first;
    while (previous->next != circle->last) {
        previous = previous->next;
    }
    Node *old = circle->last;
    *value = old->value;
    previous->next = circle->first;
    circle->last = previous;
    free(old);
    return true;
}

```


#### Visit the first node once before checking for its return

The empty case must be handled before a do-while traversal. A nonempty circle visits at least one real node.

```c

void printCircle(const Circle *circle)
{
    if (circle->first == NULL) {
        puts("Empty circle");
        return;
    }
    const Node *current = circle->first;
    do {
        printf("%d ", current->value);
        current = current->next;
    } while (current != circle->first);
    putchar('\n');
}
#endif /* End of this header guard. */

```


> **Q: Why not stop at last.next?**

> Answer: last.next is first, a real node, not an ending marker. For a singleton first.next is first too. The empty check plus do-while makes both cases work. Front insertion, rear insertion, and front deletion are O(1); rear deletion is O(n).


### Circular Singly Linked List Example

File: `10_circular_singly.c`


#### Main logic

Build a three-node ring, remove the rear once, then drain from the front. Never pass a circular list to clearList: that helper expects a NULL-terminated chain.

```c

/* Reuse the circular singly linked list types and operations. */
#include "circle.h"
int main(void)
{
    Circle circle = {NULL, NULL};
    circleInsert(&circle, 20, false);
    circleInsert(&circle, 10, true);
    circleInsert(&circle, 30, false);
    printCircle(&circle);
    int value;
    bool ok = circleRemoveRear(&circle, &value);
    if (ok) {
        printf("Rear: %d\n", value);
    }
    while (circle.first != NULL) {
        circleRemoveFront(&circle, &value);
    }
    printCircle(&circle);
    return 0;
}

```


### Polynomial Operations with a Circular Doubly Linked List

File: `polynomial.h`

A term stores coefficient and exponent. We use a circular doubly linked list with a header. Real terms are kept in descending exponent order; equal powers are combined and zero coefficients are removed. Arithmetic examples are small: coefficients and exponent sums must fit int, and exponents are nonnegative.


#### Create an empty polynomial

The header is not a constant term. Its coefficient and exponent are ignored. Its links represent an empty ring.

```c

/* Header guard: include these declarations only once in this C file. */
#ifndef COURSE_POLYNOMIAL_H
/* Remember that this header has already been included. */
#define COURSE_POLYNOMIAL_H
/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct PolyTerm {
    int coefficient;
    int exponent;
    struct PolyTerm *previous;
    struct PolyTerm *next;
} PolyTerm;
PolyTerm *newPolynomial(void)
{
    PolyTerm *header = allocate(sizeof *header);
    header->coefficient = 0;
    header->exponent = 0;
    header->next = header;
    header->previous = header;
    return header;
}

```


#### Link one new term before a known position

This is the same four-link idea from the DLL chapter, now with a term stored value. The new term is initialized before its neighbors are changed.

```c

void linkTermBefore(PolyTerm *position, int coefficient, int exponent)
{
    PolyTerm *node = allocate(sizeof *node);
    node->coefficient = coefficient;
    node->exponent = exponent;
    node->previous = position->previous;
    node->next = position;
    position->previous->next = node;
    position->previous = node;
}

```


#### Remove a canceled term

Before calling: a real linked term. Repair both directions, then free it. The header must never be passed here.

```c

void unlinkTerm(PolyTerm *term)
{
    term->previous->next = term->next;
    term->next->previous = term->previous;
    free(term);
}

```


#### Insert a term or combine an existing power

Skip zero coefficients. Find the first power no larger than the incoming exponent. Either combine equal powers or insert before that position. Cancellation removes the term entirely.

```c

void addTerm(PolyTerm *header, int coefficient, int exponent)
{
    if (coefficient == 0) {
        return;
    }
    PolyTerm *current = header->next;
    while (current != header && current->exponent > exponent) {
        current = current->next;
    }
    if (current != header && current->exponent == exponent) {
        current->coefficient = current->coefficient + coefficient;
        if (current->coefficient == 0) {
            unlinkTerm(current);
        }
    } else {
        linkTermBefore(current, coefficient, exponent);
    }
}

```


#### Addition is a merge of two ordered streams

Walk two descending term streams. endA and endB mark their ends: NULL for linear lists, or their header for rings. Copy the higher power, or combine equal powers. Append directly to the result header. This one merge serves both DLL representations.

```c

PolyTerm *mergePolynomialStreams(const PolyTerm *a, const PolyTerm *endA,
                                 const PolyTerm *b, const PolyTerm *endB)
{
    PolyTerm *result = newPolynomial();
    while (a != endA || b != endB) {
        int coefficient;
        int exponent;
        if (b == endB || (a != endA && a->exponent > b->exponent)) {
            coefficient = a->coefficient;
            exponent = a->exponent;
            a = a->next;
        } else if (a == endA || b->exponent > a->exponent) {
            coefficient = b->coefficient;
            exponent = b->exponent;
            b = b->next;
        } else {
            coefficient = a->coefficient + b->coefficient;
            exponent = a->exponent;
            a = a->next;
            b = b->next;
        }
        if (coefficient != 0) {
            linkTermBefore(result, coefficient, exponent);
        }
    }
    return result;
}

```


#### Add two header rings using the shared merge

Skip each header and pass it as the ending marker. The result is a new header ring. Inputs remain unchanged.

```c

PolyTerm *addPolynomials(const PolyTerm *first, const PolyTerm *second)
{
    return mergePolynomialStreams(first->next, first,
                                  second->next, second);
}

```


#### Multiplication makes every pair meet

Multiply each pair of terms, then reuse addTerm to combine powers. Explicit end markers let this loop work with linear streams or header rings. This simple method pays for a result-list search for every pair.

```c

PolyTerm *multiplyPolynomialStreams(const PolyTerm *first, const PolyTerm *endA,
                                    const PolyTerm *second, const PolyTerm *endB)
{
    PolyTerm *result = newPolynomial();
    for (const PolyTerm *a = first; a != endA; a = a->next) {
        for (const PolyTerm *b = second; b != endB; b = b->next) {
            int coefficient = a->coefficient * b->coefficient;
            int exponent = a->exponent + b->exponent;
            addTerm(result, coefficient, exponent);
        }
    }
    return result;
}

```


#### Multiply two header rings with the shared stream routine

Skip the headers and pass them as ending markers. The returned polynomial owns a fresh header ring.

```c

PolyTerm *multiplyPolynomials(const PolyTerm *first, const PolyTerm *second)
{
    return multiplyPolynomialStreams(first->next, first,
                                      second->next, second);
}

```


#### Display without hiding negative terms

Print each coefficient with a sign and an explicit power. An empty ring represents the zero polynomial.

```c

void printPolynomial(const PolyTerm *header)
{
    if (header->next == header) {
        puts("0");
        return;
    }
    for (const PolyTerm *p = header->next; p != header; p = p->next) {
        printf("%+d*x^%d ", p->coefficient, p->exponent);
    }
    putchar('\n');
}

```


#### Destroy the owned ring

Remove every real term using the shared unlink operation, then release the header.

```c

void destroyPolynomial(PolyTerm *header)
{
    while (header->next != header) {
        unlinkTerm(header->next);
    }
    free(header);
}
#endif /* End of this header guard. */

```


> **Q: Why the header helps?**

> Answer: When the first real term cancels, unlinkTerm updates header.next automatically through the previous link. When the last real term cancels, both links return to the header. No special first-term variable is needed.

> The same header idea works with a singly linked polynomial, but deleting there needs a predecessor route.


> **Q: Does forming mn products make this multiplication O(mn)?**

> Answer: Addition takes Theta(m+n) time and O(m+n) output nodes. Multiplication forms mn products, but this implementation also searches the result list for each one. With at most k live result terms, time is O(mn*(k+1)), and k can reach mn.

> Saying simply O(mn) would describe product formation, not this complete implementation. Sum is 4x+2; product is -9x^4+12x^3-6x^2+8x.


### Polynomial Addition and Multiplication Example

File: `11_polynomials.c`


#### Main logic

Build 3x^2+2 and -3x^2+4x. Addition should cancel the squared terms. Multiplication should combine its repeated x^2 power through addTerm.

```c

/* Reuse the polynomial types and operations already covered. */
#include "polynomial.h"
int main(void)
{
    PolyTerm *first = newPolynomial();
    PolyTerm *second = newPolynomial();
    addTerm(first, 3, 2);
    addTerm(first, 2, 0);
    addTerm(second, -3, 2);
    addTerm(second, 4, 1);
    PolyTerm *sum = addPolynomials(first, second);
    PolyTerm *product = multiplyPolynomials(first, second);
    printPolynomial(sum);
    printPolynomial(product);
    destroyPolynomial(first);
    destroyPolynomial(second);
    destroyPolynomial(sum);
    destroyPolynomial(product);
    return 0;
}

```


### Singly Linked List Count, Concatenation and Splitting

File: `23_more_sll.c`

Reuse slist.h. Ownership moves during concatenation and splitting: do not leave two containers owning the same chain.


#### Count by walking once

Count nodes, not links that happen to be non-NULL. The final real node counts too.

```c

/* Reuse the singly linked list types and operations already covered. */
#include "slist.h"
int listCount(const List *list)
{
    int count = 0;
    for (const Node *p = list->head; p != NULL; p = p->next) {
        count++;
    }
    return count;
}

```


#### Rear deletion still needs a predecessor

Handle empty and singleton lists first. Then find the node whose next route reaches tail. This is O(n), even though tail is stored.

```c

bool removeRear(List *list, int *value)
{
    if (list->head == NULL) {
        return false;
    }
    if (list->head == list->tail) {
        return removeFront(list, value);
    }
    Node *previous = list->head;
    while (previous->next != list->tail) {
        previous = previous->next;
    }
    Node *old = list->tail;
    *value = old->value;
    previous->next = NULL;
    list->tail = previous;
    free(old);
    return true;
}

```


#### Concatenate with the stored tail

Before calling: distinct, disjoint lists. The second list becomes empty. Linking takes O(1); a head-only implementation would first walk to the first list's last node.

```c

void concatenateLists(List *first, List *second)
{
    if (second->head == NULL) {
        return;
    }
    if (first->tail == NULL) {
        first->head = second->head;
    } else {
        first->tail->next = second->head;
    }
    first->tail = second->tail;
    second->head = NULL;
    second->tail = NULL;
}

```


#### Append an existing detached node

This helper transfers a node instead of allocating a copy. The caller gives up ownership of that detached node.

```c

void appendExisting(List *list, Node *node)
{
    node->next = NULL;
    if (list->tail == NULL) {
        list->head = node;
    } else {
        list->tail->next = node;
    }
    list->tail = node;
}

```


#### Split alternating indices without copying nodes

Before calling: destination lists are empty and all three containers are distinct. Index 0 goes to evenIndices, index 1 to oddIndices. Save next before appendExisting detaches the current node.

```c

void splitAlternating(List *source, List *evenIndices, List *oddIndices)
{
    int index = 0;
    Node *current = source->head;
    while (current != NULL) {
        Node *next = current->next;
        if (index % 2 == 0) {
            appendExisting(evenIndices, current);
        } else {
            appendExisting(oddIndices, current);
        }
        current = next;
        index++;
    }
    source->head = NULL;
    source->tail = NULL;
}

```


#### Main logic

Split 0 through 5 into 0,2,4 and 1,3,5. Concatenate those results, remove the last value, and clean up the single remaining owner.

```c

int main(void)
{
    List source = {NULL, NULL};
    List even = {NULL, NULL};
    List odd = {NULL, NULL};
    for (int i = 0; i < 6; i++) {
        append(&source, i);
    }
    splitAlternating(&source, &even, &odd);
    printList(&even);
    printList(&odd);
    concatenateLists(&even, &odd);
    int value;
    bool ok = removeRear(&even, &value);
    if (ok) {
        printf("Rear removed: %d Count: %d\n", value, listCount(&even));
    }
    clearList(&even);
    return 0;
}

```


> **Q: Why clear the old owners?**

> Answer: After concatenation, first owns the second chain too. Leaving second.head unchanged would make both containers appear to own those nodes. Clearing both later could free the same nodes twice. Splitting and merging have the same ownership issue.


### Linear Doubly Linked List Operations

File: `24_linear_dll.c`

We keep head and tail. One insert-before helper handles both ends and the middle; one remove-known helper handles every deletion.


#### Define a linear DLL

Both endpoints are NULL when empty. A real first node has previous=NULL; a real last node has next=NULL.

```c

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct DLink {
    int value;
    struct DLink *previous;
    struct DLink *next;
} DLink;
typedef struct {
    DLink *head;
    DLink *tail;
} DList;

```


#### Find a position

A negative or missing position returns NULL. Search costs O(n); already knowing a node is different from having to find it.

```c

DLink *dNodeAt(const DList *list, int index)
{
    if (index < 0) {
        return NULL;
    }
    DLink *current = list->head;
    for (int i = 0; i < index && current != NULL; i++) {
        current = current->next;
    }
    return current;
}

```


#### Insert before a known node or at the rear

position=NULL means append. Otherwise position must belong to this list. Link both directions, updating head or tail when a neighbor is absent.

```c

void dInsertBefore(DList *list, DLink *position, int value)
{
    DLink *left = list->tail;
    if (position != NULL) {
        left = position->previous;
    }
    DLink *node = allocate(sizeof *node);
    node->value = value;
    node->previous = left;
    node->next = position;
    if (left == NULL) {
        list->head = node;
    } else {
        left->next = node;
    }
    if (position == NULL) {
        list->tail = node;
    } else {
        position->previous = node;
    }
}

```


#### Insert at an index using the same helper

Index zero means front. At another index, find its predecessor. Inserting just after the current last node is allowed.

```c

bool dInsertAt(DList *list, int index, int value)
{
    if (index < 0) {
        return false;
    }
    if (index == 0) {
        dInsertBefore(list, list->head, value);
        return true;
    }
    DLink *previous = dNodeAt(list, index - 1);
    if (previous == NULL) {
        return false;
    }
    dInsertBefore(list, previous->next, value);
    return true;
}

```


#### Remove one known real node

Before calling: node belongs to this list. Repair each neighbor or endpoint before freeing the node. The singleton case naturally clears both endpoints.

```c

void dRemoveKnown(DList *list, DLink *node, int *value)
{
    *value = node->value;
    if (node->previous == NULL) {
        list->head = node->next;
    } else {
        node->previous->next = node->next;
    }
    if (node->next == NULL) {
        list->tail = node->previous;
    } else {
        node->next->previous = node->previous;
    }
    free(node);
}

```


#### Delete at an index after locating the node

The search pays O(n). The actual unlink pays O(1). Front or rear deletion can call dRemoveKnown directly when that endpoint is non-NULL.

```c

bool dRemoveAt(DList *list, int index, int *value)
{
    DLink *node = dNodeAt(list, index);
    if (node == NULL) {
        return false;
    }
    dRemoveKnown(list, node, value);
    return true;
}

```


#### Search a value

Follow next until a match or NULL. Return a borrowed route.

```c

DLink *dFind(const DList *list, int value)
{
    DLink *current = list->head;
    while (current != NULL) {
        if (current->value == value) {
            return current;
        }
        current = current->next;
    }
    return NULL;
}

```


#### Display forward or backward

Choose the starting endpoint once, then follow the corresponding link. No reversal of the actual list is needed.

```c

void dDisplay(const DList *list, bool backward)
{
    const DLink *current = list->head;
    if (backward) {
        current = list->tail;
    }
    while (current != NULL) {
        printf("%d ", current->value);
        if (backward) {
            current = current->previous;
        } else {
            current = current->next;
        }
    }
    putchar('\n');
}

```


#### Count real nodes

A linear DLL still needs a walk to count unless its container stores and maintains a count field.

```c

int dCount(const DList *list)
{
    int count = 0;
    for (const DLink *p = list->head; p != NULL; p = p->next) {
        count++;
    }
    return count;
}

```


#### Concatenate and transfer ownership

Before calling: distinct disjoint lists. Join first.tail to second.head in both directions, then empty the second container.

```c

void dConcatenate(DList *first, DList *second)
{
    if (second->head == NULL) {
        return;
    }
    if (first->tail == NULL) {
        first->head = second->head;
    } else {
        first->tail->next = second->head;
        second->head->previous = first->tail;
    }
    first->tail = second->tail;
    second->head = NULL;
    second->tail = NULL;
}

```


#### Cleanup reuses known node deletion

Delete the current head until empty. Both endpoints finish NULL.

```c

void dClear(DList *list)
{
    while (list->head != NULL) {
        int discarded;
        dRemoveKnown(list, list->head, &discarded);
    }
}

```


#### Main logic

Exercise front, rear, and middle insertion, both display directions, search, positional deletion, rear deletion, counting, and concatenation.

```c

int main(void)
{
    DList first = {NULL, NULL};
    DList second = {NULL, NULL};
    dInsertBefore(&first, NULL, 20);
    dInsertBefore(&first, first.head, 10);
    bool ok = dInsertAt(&first, 1, 15);
    if (ok == false) {
        return 1;
    }
    dDisplay(&first, false);
    dDisplay(&first, true);
    DLink *found = dFind(&first, 15);
    printf("Found: %d\n", found != NULL);
    int value;
    ok = dRemoveAt(&first, 1, &value);
    if (ok == false) {
        return 1;
    }
    dRemoveKnown(&first, first.tail, &value);
    dInsertBefore(&second, NULL, 30);
    dConcatenate(&first, &second);
    printf("Count: %d\n", dCount(&first));
    dDisplay(&first, false);
    dClear(&first);
    dClear(&second);
    return 0;
}

```


> **Q: Does a DLL make every deletion O(1)?**

> Answer: Only unlinking a known node is O(1). Finding index 50 still needs a walk. With a tail route, deleting the rear is O(1) because tail.previous gives the predecessor immediately.


### Circular Lists with First Only and Last Only Pointers

File: `25_circle_variants.c`

Reuse the tested Circle operations by creating a temporary view. A last-only view derives first in O(1). A first-only view must find last by walking. The view borrows nodes; it does not create another owner.


#### Build a view from the first route

Finding last costs O(n). Once found, the existing circle functions can do the actual link update.

```c

/* Reuse the circular singly linked list types and operations. */
#include "circle.h"
Circle viewFromFirst(Node *first)
{
    Circle view = {first, NULL};
    if (first == NULL) {
        return view;
    }
    view.last = first;
    while (view.last->next != first) {
        view.last = view.last->next;
    }
    return view;
}

```


#### Build a view from the last route

In a nonempty ring, last.next is first. No scan is needed.

```c

Circle viewFromLast(Node *last)
{
    Circle view = {NULL, last};
    if (last != NULL) {
        view.first = last->next;
    }
    return view;
}

```


#### Insert using only a first route

Choose front or rear with the flag. After the shared operation changes the view, copy its first route back to the caller.

```c

void insertFirstOnly(Node **first, int value, bool atFront)
{
    Circle view = viewFromFirst(*first);
    circleInsert(&view, value, atFront);
    *first = view.first;
}

```


#### Delete using only a first route

The view pays the predecessor/last discovery cost. The actual empty and singleton cases stay in the previously explained operations.

```c

bool removeFirstOnly(Node **first, bool atFront, int *value)
{
    Circle view = viewFromFirst(*first);
    bool ok;
    if (atFront) {
        ok = circleRemoveFront(&view, value);
    } else {
        ok = circleRemoveRear(&view, value);
    }
    *first = view.first;
    return ok;
}

```


#### Insert using only a last route

Front insertion keeps the old last; rear insertion changes it. The shared circle function handles that distinction.

```c

void insertLastOnly(Node **last, int value, bool atFront)
{
    Circle view = viewFromLast(*last);
    circleInsert(&view, value, atFront);
    *last = view.last;
}

```


#### Delete using only a last route

Front deletion is O(1). Rear deletion still walks for the predecessor. Emptying a singleton clears the caller's last route.

```c

bool removeLastOnly(Node **last, bool atFront, int *value)
{
    Circle view = viewFromLast(*last);
    bool ok;
    if (atFront) {
        ok = circleRemoveFront(&view, value);
    } else {
        ok = circleRemoveRear(&view, value);
    }
    *last = view.last;
    return ok;
}

```


#### Main logic

Run both endpoint variants. The temporary views are for display only. Drain through the matching owner route, not through a stale view.

```c

int main(void)
{
    Node *first = NULL;
    insertFirstOnly(&first, 20, false);
    insertFirstOnly(&first, 10, true);
    Circle view = viewFromFirst(first);
    printCircle(&view);
    int value;
    bool ok = removeFirstOnly(&first, false, &value);
    if (ok == false) {
        return 1;
    }
    while (first != NULL) {
        removeFirstOnly(&first, true, &value);
    }
    Node *last = NULL;
    insertLastOnly(&last, 20, false);
    insertLastOnly(&last, 10, true);
    view = viewFromLast(last);
    printCircle(&view);
    ok = removeLastOnly(&last, false, &value);
    if (ok == false) {
        return 1;
    }
    while (last != NULL) {
        removeLastOnly(&last, true, &value);
    }
    return 0;
}

```


> **Q: Which single route is more useful for a circle?**

> Answer: last gives both last and first=last.next immediately. first does not give last immediately. With these ordinary link-changing implementations, last-only supports front/rear insertion and front deletion in O(1); first-only needs O(n) for those boundary repairs. Rear deletion is O(n) in either singly linked variant.


### Singly Linked and Linear Doubly Linked Polynomials

File: `26_more_polynomials.c`

Use one merge idea for each node representation. SLL terms have only next. The circular SLL wrapper changes the ending marker and closes a new header ring. The DLL version reuses polynomial.h rather than repeating its algebra.


#### Define singly linked terms and append once

Append only nonzero terms. The output tail makes each attachment O(1). Input streams must already have distinct descending nonnegative exponents.

```c

/* Reuse the polynomial types and operations already covered. */
#include "polynomial.h"
typedef struct STerm {
    int coefficient;
    int exponent;
    struct STerm *next;
} STerm;
typedef struct {
    STerm *head;
    STerm *tail;
} SPolynomial;
void sAttach(SPolynomial *polynomial, int coefficient, int exponent)
{
    if (coefficient == 0) {
        return;
    }
    STerm *node = allocate(sizeof *node);
    node->coefficient = coefficient;
    node->exponent = exponent;
    node->next = NULL;
    if (polynomial->tail == NULL) {
        polynomial->head = node;
    } else {
        polynomial->tail->next = node;
    }
    polynomial->tail = node;
}

```


#### Merge singly linked term streams

The end markers may be NULL or header nodes. Each input cursor advances once per consumed term. sAttach keeps link details out of the comparison logic.

```c

SPolynomial sMerge(const STerm *a, const STerm *endA,
                   const STerm *c, const STerm *endC)
{
    SPolynomial result = {NULL, NULL};
    while (a != endA || c != endC) {
        int coefficient;
        int exponent;
        if (c == endC || (a != endA && a->exponent > c->exponent)) {
            coefficient = a->coefficient;
            exponent = a->exponent;
            a = a->next;
        } else if (a == endA || c->exponent > a->exponent) {
            coefficient = c->coefficient;
            exponent = c->exponent;
            c = c->next;
        } else {
            coefficient = a->coefficient + c->coefficient;
            exponent = a->exponent;
            a = a->next;
            c = c->next;
        }
        sAttach(&result, coefficient, exponent);
    }
    return result;
}

```


#### Add linear singly linked polynomials

NULL marks both ends. Returning the head and tail preserves a convenient complete list object.

```c

SPolynomial sAdd(const SPolynomial *first, const SPolynomial *second)
{
    return sMerge(first->head, NULL, second->head, NULL);
}

```


#### Turn an owned linear SLL polynomial into a header ring

Create a header even for zero. Connect the final real term to it and clear the old owner. The header is recognized by its address, not by borrowing an exponent value.

```c

STerm *sMakeCircular(SPolynomial *linear)
{
    STerm *header = allocate(sizeof *header);
    header->coefficient = 0;
    header->exponent = 0;
    header->next = header;
    if (linear->head != NULL) {
        header->next = linear->head;
        linear->tail->next = header;
    }
    linear->head = NULL;
    linear->tail = NULL;
    return header;
}

```


#### Circular SLL addition changes only the boundary handling

Skip the headers, use them as end markers in the same merge, then close the result ring. No repeated term-comparison algorithm is needed.

```c

STerm *sAddCircular(const STerm *first, const STerm *second)
{
    SPolynomial sum = sMerge(first->next, first, second->next, second);
    return sMakeCircular(&sum);
}

```


#### Clear a singly linked term stream

Use NULL as end for a linear chain or the header as end for a circle. This function does not free an ending header; the caller frees that separately.

```c

void sClear(STerm *current, const STerm *end)
{
    while (current != end) {
        STerm *next = current->next;
        free(current);
        current = next;
    }
}

```


#### Remove a DLL polynomial header to get a linear DLL

Transfer all real terms out of an owned ring. Break the two boundary links, then free only the header. An empty polynomial becomes NULL.

```c

PolyTerm *detachPolynomialHeader(PolyTerm *header)
{
    PolyTerm *first = NULL;
    if (header->next != header) {
        first = header->next;
        first->previous = NULL;
        header->previous->next = NULL;
    }
    free(header);
    return first;
}

```


#### Add linear DLL polynomials through the same merge

NULL marks both input ends. mergePolynomialStreams already maintains previous and next in its output. Detaching that result header gives the requested linear DLL.

```c

PolyTerm *addLinearDoubly(const PolyTerm *first, const PolyTerm *second)
{
    PolyTerm *ring = mergePolynomialStreams(first, NULL, second, NULL);
    return detachPolynomialHeader(ring);
}

```


#### Release a linear DLL polynomial

Save next before freeing. The previous links need no repair because the entire list is being destroyed.

```c

void clearLinearDoubly(PolyTerm *first)
{
    while (first != NULL) {
        PolyTerm *next = first->next;
        free(first);
        first = next;
    }
}

```


#### Insert or combine one SLL polynomial term

Keep descending powers. At an equal power, add coefficients and delete a zero sum. Otherwise connect a new node between previous and current. Update the output tail whenever the final node changes.

```c

void sAddTerm(SPolynomial *polynomial, int coefficient, int exponent)
{
    if (coefficient == 0) {
        return;
    }
    STerm *previous = NULL;
    STerm *current = polynomial->head;
    while (current != NULL && current->exponent > exponent) {
        previous = current;
        current = current->next;
    }
    if (current != NULL && current->exponent == exponent) {
        current->coefficient = current->coefficient + coefficient;
        if (current->coefficient == 0) {
            if (previous == NULL) {
                polynomial->head = current->next;
            } else {
                previous->next = current->next;
            }
            if (polynomial->tail == current) {
                polynomial->tail = previous;
            }
            free(current);
        }
        return;
    }
    STerm *node = allocate(sizeof *node);
    node->coefficient = coefficient;
    node->exponent = exponent;
    node->next = current;
    if (previous == NULL) {
        polynomial->head = node;
    } else {
        previous->next = node;
    }
    if (current == NULL) {
        polynomial->tail = node;
    }
}

```


#### Multiply SLL term streams with explicit endings

Use NULL endings for ordinary SLL polynomials, or header endings for circular SLL inputs. The output here is linear; sMakeCircular can close it afterward.

```c

SPolynomial sMultiply(const STerm *a, const STerm *endA,
                      const STerm *c, const STerm *endC)
{
    SPolynomial result = {NULL, NULL};
    for (const STerm *first = a; first != endA; first = first->next) {
        for (const STerm *second = c; second != endC; second = second->next) {
            int coefficient = first->coefficient * second->coefficient;
            int exponent = first->exponent + second->exponent;
            sAddTerm(&result, coefficient, exponent);
        }
    }
    return result;
}

```


#### Multiply linear DLL inputs through the shared algebra

The stream routine accepts NULL endings. Detach only the new output header. Inputs stay unchanged.

```c

PolyTerm *multiplyLinearDoubly(const PolyTerm *first, const PolyTerm *second)
{
    PolyTerm *ring = multiplyPolynomialStreams(first, NULL, second, NULL);
    return detachPolynomialHeader(ring);
}

```


#### Main logic

Add 3x^2+2 and -3x^2+4x using a linear SLL, then the circular SLL wrapper, then a linear DLL. All three results are 4x+2. The earlier header-ring program covers circular DLL addition and multiplication.

```c

int main(void)
{
    SPolynomial a = {NULL, NULL};
    SPolynomial c = {NULL, NULL};
    sAttach(&a, 3, 2);
    sAttach(&a, 2, 0);
    sAttach(&c, -3, 2);
    sAttach(&c, 4, 1);
    SPolynomial sum = sAdd(&a, &c);
    for (STerm *p = sum.head; p != NULL; p = p->next) {
        printf("%+d*x^%d ", p->coefficient, p->exponent);
    }
    putchar('\n');
    sClear(sum.head, NULL);
    STerm *aRing = sMakeCircular(&a);
    STerm *cRing = sMakeCircular(&c);
    STerm *sumRing = sAddCircular(aRing, cRing);
    for (STerm *p = sumRing->next; p != sumRing; p = p->next) {
        printf("%+d*x^%d ", p->coefficient, p->exponent);
    }
    putchar('\n');
    sClear(aRing->next, aRing);
    sClear(cRing->next, cRing);
    sClear(sumRing->next, sumRing);
    free(aRing);
    free(cRing);
    free(sumRing);
    PolyTerm *d = newPolynomial();
    PolyTerm *e = newPolynomial();
    addTerm(d, 3, 2);
    addTerm(d, 2, 0);
    addTerm(e, -3, 2);
    addTerm(e, 4, 1);
    d = detachPolynomialHeader(d);
    e = detachPolynomialHeader(e);
    PolyTerm *linearSum = addLinearDoubly(d, e);
    for (PolyTerm *p = linearSum; p != NULL; p = p->next) {
        printf("%+d*x^%d ", p->coefficient, p->exponent);
    }
    putchar('\n');
    clearLinearDoubly(d);
    clearLinearDoubly(e);
    clearLinearDoubly(linearSum);
    return 0;
}

```


> **Q: What changes between these additions?**

> Answer: The merge decision does not change: compare exponents and combine equal powers. The ending marker and link-maintenance helper change. All these additions are O(m+n) time with O(m+n) result nodes. A header is not a polynomial term.


### Recursive Linked List Creation and Traversal

File: `37_recursive_lists.c`

The tutorial asks for recursive list creation. We use a fixed input array so the recursion is visible without an input menu. Replace the int stored value with a participant record when needed; the link operations stay the same.


#### Build one node plus the rest of the chain

The base case creates an empty suffix. Every other call creates a node and lets the next call build its next chain. A node's next link is assigned only after that call returns.

```c

/* Reuse the singly linked list types and operations already covered. */
#include "slist.h"
Node *createChainRecursive(const int values[], int count)
{
    if (count == 0) {
        return NULL;
    }
    Node *node = newNode(values[0]);
    node->next = createChainRecursive(values + 1, count - 1);
    return node;
}

```


#### Recursive traversal does not sort a list

Visit the current node, then the remaining chain. If IDs must appear ascending, the chain must already be ordered or be sorted first.

```c

void printChainRecursive(const Node *node)
{
    if (node == NULL) {
        return;
    }
    printf("%d ", node->value);
    printChainRecursive(node->next);
}

```


#### Main logic

The input values are already ascending. After creation, find tail once so the result satisfies the List container rule, then reuse clearList.

```c

int main(void)
{
    int values[] = {10, 20, 30};
    List list = {NULL, NULL};
    list.head = createChainRecursive(values, 3);
    list.tail = list.head;
    if (list.tail != NULL) {
        while (list.tail->next != NULL) {
            list.tail = list.tail->next;
        }
    }
    printChainRecursive(list.head);
    putchar('\n');
    clearList(&list);
    return 0;
}

```


> **Q: Will displaying a list in reverse make it descending?**

> Answer: Only if it was ascending already. Traversal direction changes visit order; it does not sort arbitrary IDs. Concatenating two sorted lists also does not necessarily produce a globally sorted list. Use the merge operation when global sorted order is required.


## 5 Stacks, Queues and Applications

Array stacks, circular queues, deques, multiple stacks, brackets, and priority queues.


### Array Stack Operations

File: `int_stack.h`

This header is shared by bracket checking and expression processing. top is the index of the last occupied slot. Empty means top=-1. Every mutating operation reports success separately from its output value, so -1 can remain ordinary data.


#### State and initialization

The header guard permits repeated inclusion. Static inline functions allow this small teaching library to live entirely in a header without linker conflicts.

```c

/* Header guard: include these declarations only once in this C file. */
#ifndef INT_STACK_H
/* Remember that this header has already been included. */
#define INT_STACK_H
/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct {
    int items[CAPACITY];
    int top;
} IntStack;
static inline void initStack(IntStack *stack)
{
    stack->top = -1;
}

```


#### Push checks space before moving top

The last legal occupied index is CAPACITY-1. Increment top only after ruling out overflow, then write into the newly occupied slot.

```c

static inline bool push(IntStack *stack, int value)
{
    if (stack->top == CAPACITY - 1) {
        return false;
    }
    stack->top++;
    stack->items[stack->top] = value;
    return true;
}

```


#### Pop reads before releasing the slot

A failed pop leaves *value unchanged. On success, copying the old top value happens before decrementing top.

```c

static inline bool pop(IntStack *stack, int *value)
{
    if (stack->top == -1) {
        return false;
    }
    *value = stack->items[stack->top];
    stack->top--;
    return true;
}

```


#### Peek borrows without removing

Peek has the same empty test as pop but does not change top. It supports precedence decisions without prematurely discarding an operator.

```c

static inline bool peek(const IntStack *stack, int *value)
{
    if (stack->top == -1) {
        return false;
    }
    *value = stack->items[stack->top];
    return true;
}

```


> **Q: Why not move the whole array?**

> Answer: Push and pop are O(1) because only top changes. Inserting at index 0 and shifting existing items would preserve LIFO if done consistently, but would cost O(n). Unused old values above top are outside the logical stack even though their bytes remain.


#### Display a stack from top to bottom

Visit occupied indices from top down to zero. Printing the stack does not pop it.

```c

static inline void displayStack(const IntStack *stack)
{
    for (int i = stack->top; i >= 0; i--) {
        printf("%d ", stack->items[i]);
    }
    putchar('\n');
}
#endif /* End of this header guard. */

```


### Circular Queue and Deque Operations

File: `int_queue.h`

This circular queue and deque share one representation: front is the first occupied index; count is the number of stored items. The next rear insertion position is (front+count)%CAPACITY. There is no reserved empty slot: count distinguishes empty from full.


#### Initialize an empty queue

A single representation supports queues, deques, graph BFS, and tree-level traversal. Keeping this in a reusable header prevents later algorithms from becoming queue implementations in disguise.

```c

/* Header guard: include these declarations only once in this C file. */
#ifndef INT_QUEUE_H
/* Remember that this header has already been included. */
#define INT_QUEUE_H
/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct {
    int items[CAPACITY];
    int front;
    int count;
} IntQueue;
static inline void initQueue(IntQueue *queue)
{
    queue->front = 0;
    queue->count = 0;
}

```


#### Enter at the rear

The computed rear position is currently free when count is below capacity. Modulo wraps the index, not the stored values. A failed insertion leaves the queue unchanged.

```c

static inline bool enqueue(IntQueue *queue, int value)
{
    if (queue->count == CAPACITY) {
        return false;
    }
    int rear = (queue->front + queue->count) % CAPACITY;
    queue->items[rear] = value;
    queue->count++;
    return true;
}

```


#### Leave at the front

Read the oldest item, advance front around the ring, and reduce count. No element moves. Empty queue indices need not return to their original values.

```c

static inline bool dequeue(IntQueue *queue, int *value)
{
    if (queue->count == 0) {
        return false;
    }
    *value = queue->items[queue->front];
    queue->front = (queue->front + 1) % CAPACITY;
    queue->count--;
    return true;
}

```


#### A deque may also enter at the front

Move front backward before storing the new item. Adding CAPACITY before modulo keeps the intermediate value nonnegative in C.

```c

static inline bool pushFront(IntQueue *queue, int value)
{
    if (queue->count == CAPACITY) {
        return false;
    }
    queue->front = (queue->front + CAPACITY - 1) % CAPACITY;
    queue->items[queue->front] = value;
    queue->count++;
    return true;
}

```


#### A deque may also leave at the rear

The last occupied position is one before the next rear insertion position. Removing it does not move front.

```c

static inline bool popRear(IntQueue *queue, int *value)
{
    if (queue->count == 0) {
        return false;
    }
    int rear = (queue->front + queue->count - 1) % CAPACITY;
    *value = queue->items[rear];
    queue->count--;
    return true;
}

```


> **Notice: Restricted means restricted operations**

> An input-restricted deque permits enqueue at the rear and deletion at either end; do not expose pushFront. An output-restricted deque permits insertion at both ends and deletion only at the front; do not expose popRear. These are interface restrictions on the same ring representation.

> Every operation here is O(1).


> **Q: Why a ring?**

> Answer: With capacity 5, enqueue A,B,C,D, then dequeue A,B. front=2,count=2. Enqueue E,F,G uses physical positions 4,0,1; logical order is C,D,E,F,G. A naive linear queue whose rear only increases would declare itself full despite reusable positions. A ring restores usable capacity; it does not increase allocated storage.


#### Peek at the front without moving it

Check count before using front. The caller keeps ownership of the queue.

```c

static inline bool peekQueue(const IntQueue *queue, int *value)
{
    if (queue->count == 0) {
        return false;
    }
    *value = queue->items[queue->front];
    return true;
}

```


#### Display logical queue order rather than physical array order

Start at front and print count values, wrapping each index. Unoccupied cells are not part of the queue.

```c

static inline void displayQueue(const IntQueue *queue)
{
    for (int i = 0; i < queue->count; i++) {
        int index = (queue->front + i) % CAPACITY;
        printf("%d ", queue->items[index]);
    }
    putchar('\n');
}
#endif /* End of this header guard. */

```


### Balanced Parentheses and Two Stacks in One Array

File: `06_stack_queue_apps.c`

We now consume the interfaces. Queue applications call enqueue and dequeue. Stack applications call push and pop. Those operations were already explained; embedding their implementation inside every new algorithm would make both ideas harder to see.


#### Bracket types must agree

When a closing bracket arrives, the most recent unmatched opener must match it. Matching counts alone cannot distinguish ([)] from ([]). Ignore nonbracket characters.

```c

/* Reuse the earlier array stack type and its operations. */
#include "int_stack.h"
/* Reuse the circular array queue: IntQueue, initQueue, enqueue and dequeue. */
#include "int_queue.h"
bool matchingPair(int open, int close)
{
    if (open == '(' && close == ')') {
        return true;
    }
    if (open == '[' && close == ']') {
        return true;
    }
    if (open == '{' && close == '}') {
        return true;
    }
    return false;
}

```


#### Balanced Parentheses

Push openings. On a closing bracket, reject an empty stack or mismatched type. The final empty test catches extra openings. Stack overflow is also reported as rejection in this bounded demo.

```c

bool bracketsBalanced(const char text[])
{
    IntStack stack;
    initStack(&stack);
    for (int i = 0; text[i] != '\0'; i++) {
        char ch = text[i];
        if (ch == '(' || ch == '[' || ch == '{') {
            bool stored = push(&stack, ch);
            if (stored == false) {
                return false;
            }
        } else if (ch == ')' || ch == ']' || ch == '}') {
            int opening;
            bool found = pop(&stack, &opening);
            if (found == false) {
                return false;
            }
            bool matches = matchingPair(opening, ch);
            if (matches == false) {
                return false;
            }
        }
    }
    return stack.top == -1;
}

```


#### Two stacks can share the same array

The left stack grows from -1 upward and the right stack from CAPACITY downward. The common overflow condition is that their tops are adjacent. Unlike a fixed half-and-half partition, either stack can borrow all free slots.

```c

typedef struct {
    int items[CAPACITY];
    int leftTop;
    int rightTop;
} TwoStacks;
void initTwoStacks(TwoStacks *stacks)
{
    stacks->leftTop = -1;
    stacks->rightTop = CAPACITY;
}

```


#### A shared push chooses its growth direction

Validate which stack is requested, then check the shared free region. Labels 0 and 1 identify left and right.

```c

bool sharedPush(TwoStacks *stacks, int which, int value)
{
    if (which != 0 && which != 1) {
        return false;
    }
    if (stacks->leftTop + 1 == stacks->rightTop) {
        return false;
    }
    if (which == 0) {
        stacks->leftTop++;
        stacks->items[stacks->leftTop] = value;
    } else {
        stacks->rightTop--;
        stacks->items[stacks->rightTop] = value;
    }
    return true;
}

```


#### A shared pop checks the selected empty boundary

The right stack becomes emptier by increasing its top. This is a useful reminder that top describes a logical role; it need not always increase on push.

```c

bool sharedPop(TwoStacks *stacks, int which, int *value)
{
    if (which == 0) {
        if (stacks->leftTop == -1) {
            return false;
        }
        *value = stacks->items[stacks->leftTop];
        stacks->leftTop--;
    } else if (which == 1) {
        if (stacks->rightTop == CAPACITY) {
            return false;
        }
        *value = stacks->items[stacks->rightTop];
        stacks->rightTop++;
    } else {
        return false;
    }
    return true;
}

```


#### Main logic

Demonstrate LIFO validation, FIFO service, deque access, and shared storage. Each call visibly precedes its status check.

```c

int main(void)
{
    printf("Balanced: %d\n", bracketsBalanced("{[a+(b*c)]}"));
    printf("Crossed: %d\n", bracketsBalanced("([)]"));
    IntQueue queue;
    initQueue(&queue);
    bool ok = enqueue(&queue, 10);
    if (ok == false) {
        return 1;
    }
    ok = enqueue(&queue, 20);
    if (ok == false) {
        return 1;
    }
    int value;
    ok = dequeue(&queue, &value);
    if (ok) {
        printf("First served: %d\n", value);
    }
    ok = pushFront(&queue, 5);
    if (ok == false) {
        return 1;
    }
    ok = popRear(&queue, &value);
    if (ok) {
        printf("Rear removed: %d\n", value);
    }
    TwoStacks stacks;
    initTwoStacks(&stacks);
    ok = sharedPush(&stacks, 0, 40);
    if (ok == false) {
        return 1;
    }
    ok = sharedPush(&stacks, 1, 90);
    if (ok == false) {
        return 1;
    }
    ok = sharedPop(&stacks, 1, &value);
    if (ok) {
        printf("Right stack: %d\n", value);
    }
    return 0;
}

```


> **Notice: Trace the failing bracket case**

> For ([)]: read ( gives bottom-to-top [(]; read [ gives [(,[]; read ) pops [. Counts are not the problem; nesting order is. The function rejects immediately. Time is O(n), extra live stack space O(depth), bounded by CAPACITY here.


### Sorted Array Priority Queue

File: `priority.h`

A hospital queue cannot always serve by arrival time alone. Here a smaller priority number means greater urgency. Equal-priority patients keep arrival order. We use a sorted array so removal is cheap; that choice makes insertion more expensive.


#### Store a patient record

The name points to a string literal in these demos, so this queue does not own or free the name. The most urgent patient is kept at the highest occupied index.

```c

/* Header guard: include these declarations only once in this C file. */
#ifndef COURSE_PRIORITY_H
/* Remember that this header has already been included. */
#define COURSE_PRIORITY_H
/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct {
    const char *name;
    int priority;
} Patient;
typedef struct {
    Patient items[CAPACITY];
    int count;
} PriorityQueue;

```


#### Insert while preserving the removal order

Shift more urgent existing patients right. Shift equal-priority patients too, so the older patient remains farther right and leaves first. Store the new record in the gap.

```c

bool admit(PriorityQueue *queue, Patient patient)
{
    if (queue->count == CAPACITY) {
        return false;
    }
    int i = queue->count - 1;
    while (i >= 0 && queue->items[i].priority <= patient.priority) {
        queue->items[i + 1] = queue->items[i];
        i--;
    }
    queue->items[i + 1] = patient;
    queue->count++;
    return true;
}

```


#### Serve from the ready end

The most urgent, oldest eligible patient is already at count-1. Copy the record and reduce count. The queue does not have to scan for a winner at service time.

```c

bool serve(PriorityQueue *queue, Patient *patient)
{
    if (queue->count == 0) {
        return false;
    }
    queue->count--;
    *patient = queue->items[queue->count];
    return true;
}
#endif /* End of this header guard. */

```


> **Q: Which operation should pay?**

> Answer: Sorted-array insertion is O(n), removal O(1). An unsorted array can insert in O(1), but finding the most urgent record costs O(n) at removal. A binary heap gives O(log n) insertion and removal, but is an extension rather than the representation implemented here.

> Priority order is a policy; no representation magically decides whether 1 or 100 means more urgent.


### Sorted Priority Queue Example

File: `07_priority_queue.c`


#### Main logic

Create an empty queue with count zero. Admit three patients, including a priority tie, then serve until empty. The expected order is Rose, Maria, Bruce.

```c

/* Reuse the sorted priority queue already covered. */
#include "priority.h"
int main(void)
{
    PriorityQueue queue = {0};
    Patient arrivals[] = {{"Bruce", 3}, {"Rose", 1}, {"Maria", 1}};
    for (int i = 0; i < 3; i++) {
        bool ok = admit(&queue, arrivals[i]);
        if (ok == false) {
            return 1;
        }
    }
    while (queue.count > 0) {
        Patient patient;
        bool ok = serve(&queue, &patient);
        if (ok) {
            printf("%s priority %d\n", patient.name, patient.priority);
        }
    }
    return 0;
}

```


### Duplicate Parentheses Detection

File: `27_duplicate_parentheses.c`

Here duplicate means a matched pair with no operator belonging directly to that pair. Examples: (a) and ((a+b)) contain duplicate parentheses; (a+b) does not. Invalid input is a separate result. We reuse the expression converter to validate the grammar first.


#### Duplicate Parentheses

Push only opening parentheses and operators. At a closing parenthesis, pop operators until its opening marker. Zero popped operators means the pair adds no operation of its own.

```c

/* Reuse the expression conversion and evaluation helpers. */
#include "expressions.h"
typedef enum { INVALID_EXPRESSION, NO_DUPLICATE, DUPLICATE_FOUND } DuplicateResult;
DuplicateResult duplicateParentheses(const char text[])
{
    char postfix[CAPACITY];
    bool valid = infixToPostfix(text, postfix, sizeof postfix);
    if (valid == false) {
        return INVALID_EXPRESSION;
    }
    IntStack stack;
    initStack(&stack);
    bool duplicate = false;
    for (size_t i = 0; text[i] != '\0'; i++) {
        char symbol = text[i];
        if (symbol == '(' || precedence(symbol) != 0) {
            bool ok = push(&stack, symbol);
            if (ok == false) {
                return INVALID_EXPRESSION;
            }
        } else if (symbol == ')') {
            int operatorCount = 0;
            int item;
            pop(&stack, &item);
            while (item != '(') {
                operatorCount++;
                pop(&stack, &item);
            }
            if (operatorCount == 0) {
                duplicate = true;
            }
        }
    }
    if (duplicate) {
        return DUPLICATE_FOUND;
    }
    return NO_DUPLICATE;
}

```


#### Main logic

The enum values are 0 for invalid, 1 for no duplicate, and 2 for duplicate found. Print labels rather than making students infer what an unexplained number means.

```c

int main(void)
{
    const char *tests[] = {"(a+b)", "((a+b))", "(a)", "(a+b"};
    for (int i = 0; i < 4; i++) {
        DuplicateResult result = duplicateParentheses(tests[i]);
        printf("%s: ", tests[i]);
        if (result == INVALID_EXPRESSION) {
            puts("invalid");
        } else if (result == DUPLICATE_FOUND) {
            puts("duplicate pair");
        } else {
            puts("no duplicate pair");
        }
    }
    return 0;
}

```


> **Q: Why does a nested operator not count twice?**

> Answer: In ((a+b)), the inner ) removes + and its own (. At the outer ), the top is the outer ( immediately, so that outer pair contains no direct operator. It is duplicate. This check is O(n), including the reused validation pass.

> It is not a general optimizer for every removable parenthesis, such as a+(b*c).


### Multiple Stacks with Fixed Partitions and Dynamic Sharing

File: `28_multiple_stacks.c`

Both are shown here. Stack numbers are 0 through STACKS-1. Failed operations leave the output unchanged.


#### Initialize fixed partitions

Each stack owns a separate index interval [start,limit). top is the last occupied index, initially start-1. Division may give slightly different partition sizes.

```c

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
/* A named size limit; change it here rather than in every array. */
#define STACKS 3
typedef struct {
    int items[CAPACITY];
    int top[STACKS];
    int start[STACKS];
    int limit[STACKS];
} FixedStacks;
void initFixed(FixedStacks *stacks)
{
    for (int i = 0; i < STACKS; i++) {
        stacks->start[i] = i * CAPACITY / STACKS;
        stacks->limit[i] = (i + 1) * CAPACITY / STACKS;
        stacks->top[i] = stacks->start[i] - 1;
    }
}

```


#### Push into the selected fixed partition

Check the stack number and that partition's exclusive boundary. A different partition's free cells are unavailable here.

```c

bool fixedPush(FixedStacks *stacks, int which, int value)
{
    if (which < 0 || which >= STACKS) {
        return false;
    }
    if (stacks->top[which] + 1 == stacks->limit[which]) {
        return false;
    }
    stacks->top[which]++;
    stacks->items[stacks->top[which]] = value;
    return true;
}

```


#### Pop within the selected partition

The lower boundary, not -1 in every partition, identifies that stack's empty state.

```c

bool fixedPop(FixedStacks *stacks, int which, int *value)
{
    if (which < 0 || which >= STACKS) {
        return false;
    }
    if (stacks->top[which] < stacks->start[which]) {
        return false;
    }
    *value = stacks->items[stacks->top[which]];
    stacks->top[which]--;
    return true;
}

```


#### Dynamically Shared Multiple Stacks

Every free slot links to the next free slot through next. Each top is an index or -1. A used slot's next entry links to the previous item in its stack. The same array has different roles depending on slot ownership.

```c

typedef struct {
    int items[CAPACITY];
    int next[CAPACITY];
    int top[STACKS];
    int freeHead;
} SharedStacks;
void initShared(SharedStacks *stacks)
{
    for (int i = 0; i < STACKS; i++) {
        stacks->top[i] = -1;
    }
    for (int i = 0; i < CAPACITY - 1; i++) {
        stacks->next[i] = i + 1;
    }
    stacks->next[CAPACITY - 1] = -1;
    stacks->freeHead = 0;
}

```


#### Push takes one slot from the free list

Remove the first free slot, link it to the selected stack's old top, then make it the new top. Any stack can use any free slot.

```c

bool dynamicPush(SharedStacks *stacks, int which, int value)
{
    if (which < 0 || which >= STACKS || stacks->freeHead == -1) {
        return false;
    }
    int slot = stacks->freeHead;
    stacks->freeHead = stacks->next[slot];
    stacks->next[slot] = stacks->top[which];
    stacks->top[which] = slot;
    stacks->items[slot] = value;
    return true;
}

```


#### Pop returns its slot to the free list

Unlink the top slot from its stack, copy the value, then attach that slot at the front of the free list. No allocated heap node is involved.

```c

bool dynamicPop(SharedStacks *stacks, int which, int *value)
{
    if (which < 0 || which >= STACKS) {
        return false;
    }
    int slot = stacks->top[which];
    if (slot == -1) {
        return false;
    }
    *value = stacks->items[slot];
    stacks->top[which] = stacks->next[slot];
    stacks->next[slot] = stacks->freeHead;
    stacks->freeHead = slot;
    return true;
}

```


#### Display one fixed partition

The empty boundary belongs to that partition. Do not print cells belonging to another stack.

```c

void displayFixed(const FixedStacks *stacks, int which)
{
    if (which < 0 || which >= STACKS) {
        return;
    }
    for (int i = stacks->top[which]; i >= stacks->start[which]; i--) {
        printf("%d ", stacks->items[i]);
    }
    putchar('\n');
}

```


#### Display a dynamically shared stack

Its items need not occupy adjacent array cells. Follow next indices from top instead of scanning a physical interval.

```c

void displayShared(const SharedStacks *stacks, int which)
{
    if (which < 0 || which >= STACKS) {
        return;
    }
    int index = stacks->top[which];
    while (index != -1) {
        printf("%d ", stacks->items[index]);
        index = stacks->next[index];
    }
    putchar('\n');
}

```


#### Main logic

Put one value in each stack and pop from each. The earlier two-ended implementation is simpler for exactly two stacks; this free-list version supports k stacks.

```c

int main(void)
{
    FixedStacks fixed;
    SharedStacks shared;
    initFixed(&fixed);
    initShared(&shared);
    for (int i = 0; i < STACKS; i++) {
        bool ok = fixedPush(&fixed, i, i + 10);
        if (ok == false) {
            return 1;
        }
        ok = dynamicPush(&shared, i, i + 20);
        if (ok == false) {
            return 1;
        }
    }
    for (int i = 0; i < STACKS; i++) {
        int value;
        bool ok = fixedPop(&fixed, i, &value);
        if (ok) {
            printf("Fixed stack %d: %d\n", i, value);
        }
        ok = dynamicPop(&shared, i, &value);
        if (ok) {
            printf("Shared stack %d: %d\n", i, value);
        }
    }
    return 0;
}

```


> **Q: Can one stack overflow while memory is still free?**

> Answer: Yes with fixed partitions: one interval can fill while another is empty. The dynamic free-list version rejects a valid stack push only when the entire shared pool is full. Both push/pop versions take O(1); dynamic sharing uses O(capacity+k) stored indices.


### Linear Queues, Multiple Queues and Restricted Deques

File: `29_queue_variants.c`

The simple array queue intentionally does not wrap or shift. Multiple linked queues reuse List. Restricted deques expose only the allowed entry and exit operations.


#### Initialize a simple linear array queue

front is the next item to leave; rear is the last occupied index. Empty means front>rear. We keep this version separate from the circular queue to make its limitation visible.

```c

/* Reuse the circular array queue: IntQueue, initQueue, enqueue and dequeue. */
#include "int_queue.h"
/* Reuse the singly linked list types and operations already covered. */
#include "slist.h"
typedef struct {
    int items[CAPACITY];
    int front;
    int rear;
} LinearQueue;
void initLinear(LinearQueue *queue)
{
    queue->front = 0;
    queue->rear = -1;
}

```


#### Linear insertion advances rear only

Vacated cells before front are not reused.

```c

bool linearEnqueue(LinearQueue *queue, int value)
{
    if (queue->rear == CAPACITY - 1) {
        return false;
    }
    queue->rear++;
    queue->items[queue->rear] = value;
    return true;
}

```


#### Linear deletion advances front only

Do not shift the remaining items. This makes deletion O(1), but it leaves the earlier positions unusable in this particular version.

```c

bool linearDequeue(LinearQueue *queue, int *value)
{
    if (queue->front > queue->rear) {
        return false;
    }
    *value = queue->items[queue->front];
    queue->front++;
    return true;
}

```


#### Create several linked queues

An array of List containers gives each queue its own head and tail. The nodes remain dynamically allocated, so queues do not compete for fixed partitions in one value array.

```c

/* A named size limit; change it here rather than in every array. */
#define QUEUES 3
typedef struct {
    List queues[QUEUES];
} QueueGroup;
void initGroup(QueueGroup *group)
{
    for (int i = 0; i < QUEUES; i++) {
        group->queues[i].head = NULL;
        group->queues[i].tail = NULL;
    }
}

```


#### Enqueue into a selected linked queue

Check its number, then reuse append. There is no embedded link code in this wrapper.

```c

bool groupEnqueue(QueueGroup *group, int which, int value)
{
    if (which < 0 || which >= QUEUES) {
        return false;
    }
    append(&group->queues[which], value);
    return true;
}

```


#### Dequeue from a selected linked queue

The same removeFront function enforces FIFO after rear insertion.

```c

bool groupDequeue(QueueGroup *group, int which, int *value)
{
    if (which < 0 || which >= QUEUES) {
        return false;
    }
    return removeFront(&group->queues[which], value);
}

```


#### Peek without deletion

Borrow the first value. Empty and invalid queue numbers both report failure in this small interface.

```c

bool groupPeek(const QueueGroup *group, int which, int *value)
{
    if (which < 0 || which >= QUEUES) {
        return false;
    }
    const Node *first = group->queues[which].head;
    if (first == NULL) {
        return false;
    }
    *value = first->value;
    return true;
}

```


#### Input restricted insertion has one allowed end

The interface exposes only rear insertion. It reuses the circular deque state and its initialization function.

```c

bool inputRestrictedInsert(IntQueue *deque, int value)
{
    return enqueue(deque, value);
}

```


#### Input restricted deletion may choose either end

The flag chooses the leaving end. There is deliberately no front-insertion wrapper.

```c

bool inputRestrictedDelete(IntQueue *deque, bool fromFront, int *value)
{
    if (fromFront) {
        return dequeue(deque, value);
    }
    return popRear(deque, value);
}

```


#### Output restricted insertion may choose either end

Choose pushFront or enqueue. Their internal circular-index logic stays in int_queue.h.

```c

bool outputRestrictedInsert(IntQueue *deque, bool atFront, int value)
{
    if (atFront) {
        return pushFront(deque, value);
    }
    return enqueue(deque, value);
}

```


#### Output restricted deletion has one allowed end

Only front deletion is exposed. In C these wrappers express the intended interface; code that directly accesses the underlying deque can bypass it.

```c

bool outputRestrictedDelete(IntQueue *deque, int *value)
{
    return dequeue(deque, value);
}

```


#### Main logic

Fill a linear queue, delete one, and observe that it still rejects a new insertion. Then demonstrate independent linked queues and both restricted deque policies.

```c

int main(void)
{
    LinearQueue linear;
    initLinear(&linear);
    for (int i = 0; i < CAPACITY; i++) {
        bool ok = linearEnqueue(&linear, i);
        if (ok == false) {
            return 1;
        }
    }
    int value;
    linearDequeue(&linear, &value);
    bool ok = linearEnqueue(&linear, 999);
    printf("Linear queue reused a slot: %d\n", ok);
    QueueGroup group;
    initGroup(&group);
    for (int i = 0; i < QUEUES; i++) {
        ok = groupEnqueue(&group, i, 10 + i);
        if (ok == false) {
            return 1;
        }
        ok = groupPeek(&group, i, &value);
        if (ok) {
            printf("Queue %d front: %d\n", i, value);
        }
        groupDequeue(&group, i, &value);
    }
    IntQueue inputRestricted;
    initQueue(&inputRestricted);
    ok = inputRestrictedInsert(&inputRestricted, 10);
    if (ok == false) {
        return 1;
    }
    inputRestrictedDelete(&inputRestricted, false, &value);
    printf("Input restricted rear deletion: %d\n", value);
    IntQueue outputRestricted;
    initQueue(&outputRestricted);
    ok = outputRestrictedInsert(&outputRestricted, true, 20);
    if (ok == false) {
        return 1;
    }
    outputRestrictedDelete(&outputRestricted, &value);
    printf("Output restricted front deletion: %d\n", value);
    return 0;
}

```


> **Q: Did dequeue reduce the physical capacity?**

> Answer: No. The array still has CAPACITY cells. This simple linear indexing policy merely fails to reuse earlier cells. Circular indexing fixes that. Resetting indices when completely empty also helps, but does not recover front space while some items remain.


### Unsorted Array Priority Queue and Min Max Policies

File: `30_priority_variants.c`

The sorted-array queue is in priority.h. Here we add an unsorted-array version. A flag chooses lowest-number-first or highest-number-first. Ties keep arrival order.


#### Unsorted insertion just appends

This version spends O(1) on arrival. It postpones choosing the winner until peek or deletion.

```c

/* Reuse the sorted priority queue already covered. */
#include "priority.h"
bool admitUnsorted(PriorityQueue *queue, Patient patient)
{
    if (queue->count == CAPACITY) {
        return false;
    }
    queue->items[queue->count] = patient;
    queue->count++;
    return true;
}

```


#### Find the best index under the chosen policy

Keep the first occurrence when priorities tie. Return -1 when empty. The scan is O(n).

```c

int bestPatientIndex(const PriorityQueue *queue, bool highestNumberFirst)
{
    if (queue->count == 0) {
        return -1;
    }
    int best = 0;
    for (int i = 1; i < queue->count; i++) {
        bool better = queue->items[i].priority < queue->items[best].priority;
        if (highestNumberFirst) {
            better = queue->items[i].priority > queue->items[best].priority;
        }
        if (better) {
            best = i;
        }
    }
    return best;
}

```


#### Unsorted peek finds but does not remove

Reuse the selection helper. The output remains unchanged if no patient exists.

```c

bool peekUnsorted(const PriorityQueue *queue, bool highestNumberFirst,
                  Patient *patient)
{
    int best = bestPatientIndex(queue, highestNumberFirst);
    if (best == -1) {
        return false;
    }
    *patient = queue->items[best];
    return true;
}

```


#### Unsorted deletion selects then closes the gap

Shift remaining records left. Replacing the removed record with the final item would be cheaper to move, but could disturb arrival order for future equal-priority service.

```c

bool serveUnsorted(PriorityQueue *queue, bool highestNumberFirst,
                   Patient *patient)
{
    int best = bestPatientIndex(queue, highestNumberFirst);
    if (best == -1) {
        return false;
    }
    *patient = queue->items[best];
    for (int i = best; i < queue->count - 1; i++) {
        queue->items[i] = queue->items[i + 1];
    }
    queue->count--;
    return true;
}

```


#### Sorted peek reads the ready end

Only use this helper with a queue maintained by the sorted admit function. Mixing sorted and unsorted operations on one queue would break the representation rule.

```c

bool peekSorted(const PriorityQueue *queue, Patient *patient)
{
    if (queue->count == 0) {
        return false;
    }
    *patient = queue->items[queue->count - 1];
    return true;
}

```


#### Empty and full are separate questions

The same container count works for either array representation.

```c

bool priorityEmpty(const PriorityQueue *queue)
{
    return queue->count == 0;
}

```


#### Full compares logical count with allocated capacity

A full queue may still contain low-priority records. Priority does not create extra storage.

```c

bool priorityFull(const PriorityQueue *queue)
{
    return queue->count == CAPACITY;
}

```


#### Main logic

Use the unsorted version as a max-priority queue. Use a separate sorted queue as a min-priority queue. The direction is explicit rather than hidden in the function name.

```c

int main(void)
{
    PriorityQueue unsorted = {0};
    Patient arrivals[] = {{"A", 2}, {"B", 5}, {"C", 5}};
    for (int i = 0; i < 3; i++) {
        bool ok = admitUnsorted(&unsorted, arrivals[i]);
        if (ok == false) {
            return 1;
        }
    }
    Patient patient;
    bool ok = peekUnsorted(&unsorted, true, &patient);
    if (ok) {
        printf("Max peek: %s\n", patient.name);
    }
    while (priorityEmpty(&unsorted) == false) {
        serveUnsorted(&unsorted, true, &patient);
        puts(patient.name);
    }
    PriorityQueue sorted = {0};
    ok = admit(&sorted, arrivals[0]);
    if (ok == false) {
        return 1;
    }
    ok = peekSorted(&sorted, &patient);
    if (ok) {
        printf("Min sorted peek: %s Full: %d\n",
               patient.name, priorityFull(&sorted));
    }
    return 0;
}

```


> **Q: Which priority representation should we choose?**

> Answer: Unsorted array: O(1) insert, O(n) peek/delete. Sorted array here: O(n) insert, O(1) peek/delete at the ready end. AVL and red-black code show the tree operations; the next example shows the heap alternative.


### Heap Priority Queue

File: `31_heap_priority.c`

This min-heap serves smaller priority numbers first. Arrival sequence breaks ties, so equal priorities remain FIFO. The heap array is complete in shape but is not fully sorted.


#### Store priority and arrival order

The sequence counter is assumed not to overflow during a demo. Its job is tie handling; it is not a tree index.

```c

/* Reuse the sorted priority queue already covered. */
#include "priority.h"
typedef struct {
    Patient patient;
    unsigned long long sequence;
} HeapItem;
typedef struct {
    HeapItem items[CAPACITY];
    int count;
    unsigned long long nextSequence;
} MinHeap;

```


#### Define which item should come earlier

Compare priority first and sequence second. The heap code can now ask one clear question instead of repeating a long comparison.

```c

bool comesBefore(HeapItem first, HeapItem second)
{
    if (first.patient.priority != second.patient.priority) {
        return first.patient.priority < second.patient.priority;
    }
    return first.sequence < second.sequence;
}

```


#### Swap complete heap records

Moving a patient without its sequence would lose the tie-breaking information.

```c

void swapHeapItems(HeapItem *first, HeapItem *second)
{
    HeapItem temporary = *first;
    *first = *second;
    *second = temporary;
}

```


#### Insert at the end then move upward

Append in the next complete-tree slot. Swap with the parent while the child should come earlier. Only one ancestor path can need repair.

```c

bool heapInsert(MinHeap *heap, Patient patient)
{
    if (heap->count == CAPACITY) {
        return false;
    }
    int index = heap->count;
    HeapItem item = {patient, heap->nextSequence};
    heap->nextSequence++;
    heap->items[index] = item;
    heap->count++;
    while (index > 0) {
        int parent = (index - 1) / 2;
        bool earlier = comesBefore(heap->items[index], heap->items[parent]);
        if (earlier == false) {
            break;
        }
        swapHeapItems(&heap->items[index], &heap->items[parent]);
        index = parent;
    }
    return true;
}

```


#### Peek at the root

The best item is at index 0. No search is needed.

```c

bool heapPeek(const MinHeap *heap, Patient *patient)
{
    if (heap->count == 0) {
        return false;
    }
    *patient = heap->items[0].patient;
    return true;
}

```


#### Remove the root then move the replacement downward

Move the last record to the root to preserve the complete shape. Repeatedly swap it with the earlier of its children until the parent rule holds.

```c

bool heapRemove(MinHeap *heap, Patient *patient)
{
    if (heap->count == 0) {
        return false;
    }
    *patient = heap->items[0].patient;
    heap->count--;
    if (heap->count == 0) {
        return true;
    }
    heap->items[0] = heap->items[heap->count];
    int index = 0;
    while (true) {
        int best = index;
        int left = 2 * index + 1;
        int right = left + 1;
        if (left < heap->count) {
            bool earlier = comesBefore(heap->items[left], heap->items[best]);
            if (earlier) {
                best = left;
            }
        }
        if (right < heap->count) {
            bool earlier = comesBefore(heap->items[right], heap->items[best]);
            if (earlier) {
                best = right;
            }
        }
        if (best == index) {
            break;
        }
        swapHeapItems(&heap->items[index], &heap->items[best]);
        index = best;
    }
    return true;
}

```


#### Main logic

Initialize count and sequence to zero. The service order is B,C,A: B and C tie on priority, so their sequence decides.

```c

int main(void)
{
    MinHeap heap = {0};
    Patient arrivals[] = {{"A", 3}, {"B", 1}, {"C", 1}};
    for (int i = 0; i < 3; i++) {
        bool ok = heapInsert(&heap, arrivals[i]);
        if (ok == false) {
            return 1;
        }
    }
    Patient patient;
    bool ok = heapPeek(&heap, &patient);
    if (ok) {
        printf("Next: %s\n", patient.name);
    }
    while (heap.count > 0) {
        heapRemove(&heap, &patient);
        puts(patient.name);
    }
    return 0;
}

```


> **Q: Why are heap operations logarithmic?**

> Answer: A complete binary tree has O(log n) height. Insertion moves up one path; removal moves down one path. Both take O(log n) worst-case time, while peek is O(1). A max-heap reverses the priority comparison in comesBefore but keeps the sequence tie rule.


### AVL Tree Priority Queue

File: `39_tree_priority.c`

Read the AVL section before this example. The tree stores active priority numbers; each priority has a FIFO queue of record indices. Priorities are 0 through CAPACITY-1, and at most CAPACITY patients may wait overall. Existing stack, queue, and AVL functions do the work.


#### Keep records separate from their service order

A free-index stack tracks reusable record slots. Queue entries are indices into records. Equal priorities share one FIFO queue, so their arrival order is preserved.

```c

/* Reuse the sorted priority queue already covered. */
#include "priority.h"
/* Reuse the AVL node type and balancing operations already covered. */
#include "avl.h"
/* Reuse the earlier array stack type and its operations. */
#include "int_stack.h"
/* Reuse the circular array queue: IntQueue, initQueue, enqueue and dequeue. */
#include "int_queue.h"
typedef struct {
    Patient records[CAPACITY];
    IntQueue waiting[CAPACITY];
    IntStack freeSlots;
    AVL *priorities;
} TreePriorityQueue;
void initTreePriority(TreePriorityQueue *queue)
{
    queue->priorities = NULL;
    initStack(&queue->freeSlots);
    for (int i = 0; i < CAPACITY; i++) {
        initQueue(&queue->waiting[i]);
        push(&queue->freeSlots, i);
    }
}

```


#### Choose the smallest or largest active priority

Use one tree path. The caller has already checked that the tree is nonempty.

```c

AVL *selectPriority(AVL *root, bool highestNumberFirst)
{
    if (highestNumberFirst) {
        while (root->right != NULL) {
            root = root->right;
        }
    } else {
        while (root->left != NULL) {
            root = root->left;
        }
    }
    return root;
}

```


#### Admit a patient and activate its priority if needed

Reserve a record slot first. A successful reservation guarantees room in the chosen bucket because the total waiting count is below CAPACITY. Add the priority to the AVL tree only when its bucket was empty.

```c

bool treePriorityInsert(TreePriorityQueue *queue, Patient patient)
{
    int priority = patient.priority;
    if (priority < 0 || priority >= CAPACITY) {
        return false;
    }
    int slot;
    bool available = pop(&queue->freeSlots, &slot);
    if (available == false) {
        return false;
    }
    bool wasEmpty = queue->waiting[priority].count == 0;
    queue->records[slot] = patient;
    bool ok = enqueue(&queue->waiting[priority], slot);
    if (ok == false) {
        fprintf(stderr, "Record pool rule failed\n");
        exit(EXIT_FAILURE);
    }
    if (wasEmpty) {
        queue->priorities = avlInsert(queue->priorities, priority);
    }
    return true;
}

```


#### Peek uses a tree choice and a FIFO observer

Choose a priority, peek its queue index, then copy the patient record. Neither the tree nor the waiting order changes.

```c

bool treePriorityPeek(const TreePriorityQueue *queue, bool highestNumberFirst,
                       Patient *patient)
{
    if (queue->priorities == NULL) {
        return false;
    }
    AVL *best = selectPriority(queue->priorities, highestNumberFirst);
    int slot;
    bool ok = peekQueue(&queue->waiting[best->value], &slot);
    if (ok == false) {
        return false;
    }
    *patient = queue->records[slot];
    return true;
}

```


#### Serve and release the record slot

Remove the oldest record from the selected priority, return its index to freeSlots, then remove that priority from the AVL tree if no patient remains there.

```c

bool treePriorityRemove(TreePriorityQueue *queue, bool highestNumberFirst,
                         Patient *patient)
{
    if (queue->priorities == NULL) {
        return false;
    }
    AVL *best = selectPriority(queue->priorities, highestNumberFirst);
    int priority = best->value;
    int slot;
    bool ok = dequeue(&queue->waiting[priority], &slot);
    if (ok == false) {
        return false;
    }
    *patient = queue->records[slot];
    push(&queue->freeSlots, slot);
    if (queue->waiting[priority].count == 0) {
        queue->priorities = avlDelete(queue->priorities, priority);
    }
    return true;
}

```


#### Clear by serving until empty

Draining removes the allocated AVL nodes through avlDelete. The array queues and record table are embedded storage, so they require no free.

```c

void clearTreePriority(TreePriorityQueue *queue)
{
    while (queue->priorities != NULL) {
        Patient discarded;
        treePriorityRemove(queue, false, &discarded);
    }
}

```


#### Main logic

Use a min-priority policy. B and C tie, so their bucket serves B first. The same remove function with highestNumberFirst=true gives the opposite priority direction.

```c

int main(void)
{
    TreePriorityQueue queue;
    initTreePriority(&queue);
    Patient arrivals[] = {{"A", 3}, {"B", 1}, {"C", 1}};
    for (int i = 0; i < 3; i++) {
        bool ok = treePriorityInsert(&queue, arrivals[i]);
        if (ok == false) {
            return 1;
        }
    }
    Patient patient;
    bool ok = treePriorityPeek(&queue, false, &patient);
    if (ok) {
        printf("Next: %s\n", patient.name);
    }
    while (queue.priorities != NULL) {
        treePriorityRemove(&queue, false, &patient);
        puts(patient.name);
    }
    clearTreePriority(&queue);
    return 0;
}

```


> **Q: Why not rebuild enqueue and AVL insertion here?**

> Answer: Those operations already maintain their own rules. This implementation only coordinates them. With P distinct active priorities, selecting and updating the tree takes O(log(P+1)); bucket enqueue/dequeue takes O(1). The fixed bucket array trades extra preallocated storage for very simple lookup.


## 6 Expression Conversion and Evaluation

Stack-based conversion, expression trees, and numeric prefix/postfix evaluation.


### Infix, Postfix and Prefix Conversion and Evaluation

File: `expressions.h`

The conversion demo accepts single-letter or single-digit operands and binary + - * / ^, with parentheses and optional spaces. There is no unary minus or implicit multiplication.

The numeric evaluators are separate: they accept whitespace-separated finite numbers, including decimals and signed numbers. ^ means exponentiation here, not the C XOR operator.


#### Name the operators and their precedence

Return zero for a nonoperator. Exponentiation has the highest precedence and is right associative. The helpers keep these rules out of the conversion loop.

```c

/* Header guard: include these declarations only once in this C file. */
#ifndef COURSE_EXPRESSIONS_H
/* Remember that this header has already been included. */
#define COURSE_EXPRESSIONS_H
/* Reuse the earlier array stack type and its operations. */
#include "int_stack.h"
#include <errno.h>
int precedence(int symbol)
{
    if (symbol == '+' || symbol == '-') {
        return 1;
    }
    if (symbol == '*' || symbol == '/') {
        return 2;
    }
    if (symbol == '^') {
        return 3;
    }
    return 0;
}

```


#### Append a symbol without overflowing the output

length is the number of actual characters, excluding the terminator. Leave room for the terminating null after every append. A failed conversion leaves partial output that the caller must discard.

```c

bool appendSymbol(char output[], size_t capacity,
                  size_t *length, char symbol)
{
    if (*length + 1 >= capacity) {
        return false;
    }
    output[*length] = symbol;
    (*length)++;
    output[*length] = '\0';
    return true;
}

```


#### Decide whether the waiting operator can leave

A higher-precedence top operator is ready before the incoming operator. At equal precedence, pop for left-associative incoming operators, but not for ^. This is why a^b^c becomes abc^^.

```c

bool shouldPop(int top, int incoming)
{
    if (top == '(') {
        return false;
    }
    int waiting = precedence(top);
    int arriving = precedence(incoming);
    if (waiting > arriving) {
        return true;
    }
    return waiting == arriving && incoming != '^';
}

```


#### Infix to Postfix Conversion

expectOperand is a simple grammar check: an operand or ( must appear when true; an operator or ) is allowed when false. Operands go directly to output. Operators wait on the stack. A closing parenthesis empties only its matching opening region.

All stack calls remain separate from their checks.

```c

bool infixToPostfix(const char input[], char output[], size_t capacity)
{
    if (capacity == 0) {
        return false;
    }
    output[0] = '\0';
    size_t length = 0;
    IntStack operators;
    initStack(&operators);
    bool expectOperand = true;
    for (size_t i = 0; input[i] != '\0'; i++) {
        unsigned char symbol = (unsigned char)input[i];
        if (isspace(symbol)) {
            continue;
        }
        if (isalnum(symbol)) {
            if (expectOperand == false) {
                return false;
            }
            bool ok = appendSymbol(output, capacity, &length, (char)symbol);
            if (ok == false) {
                return false;
            }
            expectOperand = false;
        } else if (symbol == '(') {
            if (expectOperand == false) {
                return false;
            }
            bool ok = push(&operators, symbol);
            if (ok == false) {
                return false;
            }
        } else if (symbol == ')') {
            if (expectOperand) {
                return false;
            }
            bool matched = false;
            while (operators.top != -1) {
                int waiting;
                pop(&operators, &waiting);
                if (waiting == '(') {
                    matched = true;
                    break;
                }
                bool ok = appendSymbol(output, capacity, &length,
                                       (char)waiting);
                if (ok == false) {
                    return false;
                }
            }
            if (matched == false) {
                return false;
            }
        } else if (precedence(symbol) != 0) {
            if (expectOperand) {
                return false;
            }
            while (operators.top != -1) {
                int waiting;
                peek(&operators, &waiting);
                bool ready = shouldPop(waiting, symbol);
                if (ready == false) {
                    break;
                }
                pop(&operators, &waiting);
                bool ok = appendSymbol(output, capacity, &length,
                                       (char)waiting);
                if (ok == false) {
                    return false;
                }
            }
            bool ok = push(&operators, symbol);
            if (ok == false) {
                return false;
            }
            expectOperand = true;
        } else {
            return false;
        }
    }
    if (expectOperand) {
        return false;
    }
    while (operators.top != -1) {
        int waiting;
        pop(&operators, &waiting);
        if (waiting == '(') {
            return false;
        }
        bool ok = appendSymbol(output, capacity, &length, (char)waiting);
        if (ok == false) {
            return false;
        }
    }
    return true;
}

```


> **Notice: Conversion trace with the stack top on the right**

> Input a+b*c. Read a: output a, stack empty. Read +: output a, stack [+]. Read b: output ab, stack [+]. Read *: + is lower, so stack [+,*]. Read c: output abc. Drain * then +: abc*+.

> For a^b^c, the second ^ does not pop the first; output is abc^^, representing a^(b^c). Each operator enters and leaves once: O(n) time and O(n) stack/output space.


#### Represent an expression tree with a bounded node pool

An operand is a leaf. An operator has left and right child indices. Pool indices let us reuse IntStack without changing it into a pointer stack. -1 means no child. The pool owns its nodes as part of the Expression object, so no per-node free is needed.

```c

typedef struct {
    char symbol;
    int left;
    int right;
} ExpressionNode;
typedef struct {
    ExpressionNode nodes[CAPACITY];
    int count;
    int root;
} Expression;

```


#### Expression Tree from Postfix

Read left to right. Push an operand's node index. For an operator, pop the right subtree first, then the left. Join them under the new operator and push the result index. End with exactly one tree. Before calling: no whitespace in this single-character postfix string.

```c

bool treeFromPostfix(const char postfix[], Expression *tree)
{
    tree->count = 0;
    tree->root = -1;
    IntStack roots;
    initStack(&roots);
    for (size_t i = 0; postfix[i] != '\0'; i++) {
        if (tree->count == CAPACITY) {
            return false;
        }
        char symbol = postfix[i];
        ExpressionNode node = {symbol, -1, -1};
        if (precedence(symbol) != 0) {
            bool rightFound = pop(&roots, &node.right);
            bool leftFound = pop(&roots, &node.left);
            if (rightFound == false || leftFound == false) {
                return false;
            }
        } else if (isalnum((unsigned char)symbol) == 0) {
            return false;
        }
        int index = tree->count;
        tree->nodes[index] = node;
        tree->count++;
        bool ok = push(&roots, index);
        if (ok == false) {
            return false;
        }
    }
    if (roots.top != 0) {
        return false;
    }
    pop(&roots, &tree->root);
    return true;
}

```


#### Prefix Conversion by Preorder Traversal

Visit the operator before its two subexpressions. This prints an infix-to-prefix conversion after the stack-based infix-to-postfix and tree construction steps.

```c

void printPrefix(const Expression *tree, int index)
{
    if (index == -1) {
        return;
    }
    ExpressionNode node = tree->nodes[index];
    putchar(node.symbol);
    printPrefix(tree, node.left);
    printPrefix(tree, node.right);
}

```


#### Postfix Conversion by Postorder Traversal

Print both operands before the operator. Using the tree avoids a second set of precedence rules.

```c

void printPostfix(const Expression *tree, int index)
{
    if (index == -1) {
        return;
    }
    ExpressionNode node = tree->nodes[index];
    printPostfix(tree, node.left);
    printPostfix(tree, node.right);
    putchar(node.symbol);
}

```


#### Fully Parenthesized Infix Conversion

A plain inorder sequence could lose grouping. Wrap each binary operator subtree in parentheses. A leaf needs no parentheses.

```c

void printInfix(const Expression *tree, int index)
{
    ExpressionNode node = tree->nodes[index];
    if (node.left == -1) {
        putchar(node.symbol);
        return;
    }
    putchar('(');
    printInfix(tree, node.left);
    putchar(node.symbol);
    printInfix(tree, node.right);
    putchar(')');
}

```


#### Expression Tree from Prefix

Scan right to left. A prefix operator now pops left first, then right. The rest is the same pool and stack model. This gives prefix-to-infix and prefix-to-postfix through the existing traversals.

```c

bool treeFromPrefix(const char prefix[], Expression *tree)
{
    tree->count = 0;
    tree->root = -1;
    IntStack roots;
    initStack(&roots);
    size_t length = strlen(prefix);
    while (length > 0) {
        length--;
        if (tree->count == CAPACITY) {
            return false;
        }
        char symbol = prefix[length];
        ExpressionNode node = {symbol, -1, -1};
        if (precedence(symbol) != 0) {
            bool leftFound = pop(&roots, &node.left);
            bool rightFound = pop(&roots, &node.right);
            if (leftFound == false || rightFound == false) {
                return false;
            }
        } else if (isalnum((unsigned char)symbol) == 0) {
            return false;
        }
        int index = tree->count;
        tree->nodes[index] = node;
        tree->count++;
        bool ok = push(&roots, index);
        if (ok == false) {
            return false;
        }
    }
    if (roots.top != 0) {
        return false;
    }
    pop(&roots, &tree->root);
    return true;
}

```


#### A numeric stack needs numeric storage

The interface is the same as IntStack, but the stored value is double. Keep push/pop separate from evaluation. We show this type change explicitly rather than pretend an int stack can hold floating-point values.

```c

typedef struct {
    double items[CAPACITY];
    int count;
} NumberStack;
bool pushNumber(NumberStack *stack, double value)
{
    if (stack->count == CAPACITY) {
        return false;
    }
    stack->items[stack->count] = value;
    stack->count++;
    return true;
}

```


#### Pop a number

Do not use a numeric sentinel for failure. Every finite number, including -1, is legitimate expression data.

```c

bool popNumber(NumberStack *stack, double *value)
{
    if (stack->count == 0) {
        return false;
    }
    stack->count--;
    *value = stack->items[stack->count];
    return true;
}

```


#### Apply one binary operator

Operand order matters for subtraction, division, and exponentiation. Reject division by zero and results that are not finite. pow implements the expression language's ^ operator; C's own ^ does not.

```c

bool applyOperator(char symbol, double left, double right, double *answer)
{
    double result;
    if (symbol == '+') {
        result = left + right;
    } else if (symbol == '-') {
        result = left - right;
    } else if (symbol == '*') {
        result = left * right;
    } else if (symbol == '/') {
        if (right == 0.0) {
            return false;
        }
        result = left / right;
    } else if (symbol == '^') {
        result = pow(left, right);
    } else {
        return false;
    }
    if (isfinite(result) == 0) {
        return false;
    }
    *answer = result;
    return true;
}

```


#### Tokenize before evaluating

Copy tokens into a fixed table so prefix can read them backward. Reject a token that would not fit rather than truncate it. Whitespace is mandatory between separate numeric operands and operators.

```c

bool splitTokens(const char text[], char tokens[][32], int *count)
{
    *count = 0;
    size_t i = 0;
    while (text[i] != '\0') {
        if (isspace((unsigned char)text[i])) {
            i++;
            continue;
        }
        if (*count == CAPACITY) {
            return false;
        }
        int length = 0;
        while (text[i] != '\0' && isspace((unsigned char)text[i]) == 0) {
            if (length == 31) {
                return false;
            }
            tokens[*count][length] = text[i];
            length++;
            i++;
        }
        tokens[*count][length] = '\0';
        (*count)++;
    }
    return *count > 0;
}

```


#### Postfix and Prefix Evaluation

For postfix, scan left to right and pop right then left. For prefix, scan right to left and pop left then right. A one-character operator token is processed as an operator; otherwise strtod must consume the complete token. Exactly one value must remain.

The output is unchanged on failure.

```c

bool evaluate(const char text[], bool prefix, double *answer)
{
    char tokens[CAPACITY][32];
    int count;
    bool valid = splitTokens(text, tokens, &count);
    if (valid == false) {
        return false;
    }
    NumberStack stack = {{0}, 0};
    for (int step = 0; step < count; step++) {
        int index = step;
        if (prefix) {
            index = count - 1 - step;
        }
        char *token = tokens[index];
        bool isOperator = token[1] == '\0' && precedence(token[0]) != 0;
        double value;
        if (isOperator) {
            double first;
            double second;
            bool gotFirst = popNumber(&stack, &first);
            bool gotSecond = popNumber(&stack, &second);
            if (gotFirst == false || gotSecond == false) {
                return false;
            }
            double left = second;
            double right = first;
            if (prefix) {
                left = first;
                right = second;
            }
            valid = applyOperator(token[0], left, right, &value);
            if (valid == false) {
                return false;
            }
        } else {
            char *end;
            errno = 0;
            value = strtod(token, &end);
            if (end == token || *end != '\0' || errno == ERANGE) {
                return false;
            }
            if (isfinite(value) == 0) {
                return false;
            }
        }
        valid = pushNumber(&stack, value);
        if (valid == false) {
            return false;
        }
    }
    if (stack.count != 1) {
        return false;
    }
    return popNumber(&stack, answer);
}
#endif /* End of this header guard. */

```


> **Notice: Numeric trace**

> Postfix 12.5 2 3 * +. Bottom-to-top stack: [12.5], [12.5,2], [12.5,2,3], [12.5,6], [18.5]. For 10 3 -, the first pop is 3, the right operand; the answer is 7, not -7. Prefix - 10 3 scans 3 then 10, so the first pop is the left operand 10.

> Same tree, different scan direction.


> **Q: Why not ch minus zero?**

> Answer: For the character '7', ch-'0' gives integer 7 because digit codes are consecutive in C. It cannot turn the two-character text 12 into twelve, or 2.5 into a floating-point value. strtod parses a whole numeric token and tells us where it stopped.

> A cast changes a value's type; it does not parse decimal text.


> **Q: Why not just reverse everything?**

> Answer: The reverse-swap-parentheses trick for infix-to-prefix must also reverse equal-precedence associativity handling. Reusing an ordinary postfix converter blindly gives wrong groupings for expressions such as a-b-c or a^b^c. The tree route here keeps a single authoritative grouping.

> All six directed conversions between infix, prefix, and postfix are available by choosing the appropriate builder and traversal. Conversion and tree traversal cost O(n); numeric evaluation is O(tokens) stack work plus parsing and arithmetic costs.


### Expression Conversion and Evaluation Example

File: `12_expressions.c`


#### Main logic

Convert infix, build its tree, and print three orders. Then evaluate a decimal postfix expression and its prefix equivalent. This separates symbolic conversion from numeric token parsing; a student can learn one without guessing the other's input format.

```c

/* Reuse the expression conversion and evaluation helpers. */
#include "expressions.h"
int main(void)
{
    char postfix[CAPACITY];
    bool ok = infixToPostfix("a+b*c^d^e", postfix, sizeof postfix);
    if (ok == false) {
        puts("Invalid infix expression");
        return 1;
    }
    printf("Postfix: %s\n", postfix);
    Expression tree;
    ok = treeFromPostfix(postfix, &tree);
    if (ok == false) {
        return 1;
    }
    printf("Prefix: ");
    printPrefix(&tree, tree.root);
    putchar('\n');
    printf("Infix: ");
    printInfix(&tree, tree.root);
    putchar('\n');
    ok = treeFromPrefix("+a*bc", &tree);
    if (ok == false) {
        return 1;
    }
    printf("Prefix converted to postfix: ");
    printPostfix(&tree, tree.root);
    putchar('\n');
    double answer;
    ok = evaluate("12.5 2 3 * +", false, &answer);
    if (ok) {
        printf("Postfix value: %.2f\n", answer);
    }
    ok = evaluate("+ 12.5 * 2 3", true, &answer);
    if (ok) {
        printf("Prefix value: %.2f\n", answer);
    }
    return 0;
}

```


## 7 Binary Trees and Binary Search Trees

Binary-tree operations, traversals, BST operations, ordinary binary deletion, and threads.


### Array Binary Tree: Storage and Traversals

File: `40_array_binary_tree.c`

An ordinary array can represent a binary tree without nodes or child pointers. Start here for the simplest storage model. The linked version follows separately.


#### Use two ordinary arrays

tree stores the values. occupied says whether a position contains a node. These are standard C headers; this example does not need course_common.h. TREE_SIZE is a named limit, not the number of nodes currently stored.

```c

#include <stdio.h>
#include <stdbool.h>
/* A named size limit; change it here rather than in every array. */
#define TREE_SIZE 31

```


#### Check a position before reading it

Check the bounds first. Only then read occupied[index]. Keeping this in one helper avoids repeating the same checks in every traversal.

```c

bool hasArrayNode(const bool occupied[], int index)
{
    if (index < 0 || index >= TREE_SIZE) {
        return false;
    }
    return occupied[index];
}

```


#### Store a node only below an existing parent

Index 0 is the root. At any other index, the parent must already exist. Storing at an occupied position replaces its value; it does not move its children.

```c

bool storeArrayNode(int tree[], bool occupied[], int index, int value)
{
    if (index < 0 || index >= TREE_SIZE) {
        return false;
    }
    if (index > 0) {
        int parent = (index - 1) / 2;
        bool parentExists = hasArrayNode(occupied, parent);
        if (parentExists == false) {
            return false;
        }
    }
    tree[index] = value;
    occupied[index] = true;
    return true;
}

```


> **Notice: Where did the child pointers go**

> The positions do their job: for a node at i, left = 2*i+1 and right = 2*i+2. For a nonroot node, parent = (i-1)/2. We start at 0. With a root at 1, the child formulas become 2*i and 2*i+1; do not mix the two conventions.


#### Array Binary Tree Preorder

The rule is still root, left, right. Only the way we reach a child changes: calculate its index instead of following a pointer.

```c

void arrayPreorder(const int tree[], const bool occupied[], int index)
{
    bool exists = hasArrayNode(occupied, index);
    if (exists == false) {
        return;
    }
    int left = 2 * index + 1;
    int right = 2 * index + 2;
    printf("%d ", tree[index]);
    arrayPreorder(tree, occupied, left);
    arrayPreorder(tree, occupied, right);
}

```


#### Array Binary Tree Inorder

Visit left, root, right. Inorder is sorted only when the stored tree follows the BST rule; using an array does not make a tree a BST.

```c

void arrayInorder(const int tree[], const bool occupied[], int index)
{
    bool exists = hasArrayNode(occupied, index);
    if (exists == false) {
        return;
    }
    int left = 2 * index + 1;
    int right = 2 * index + 2;
    arrayInorder(tree, occupied, left);
    printf("%d ", tree[index]);
    arrayInorder(tree, occupied, right);
}

```


#### Array Binary Tree Postorder

Visit left, right, root. Compare just the position of printf with the previous two traversals.

```c

void arrayPostorder(const int tree[], const bool occupied[], int index)
{
    bool exists = hasArrayNode(occupied, index);
    if (exists == false) {
        return;
    }
    int left = 2 * index + 1;
    int right = 2 * index + 2;
    arrayPostorder(tree, occupied, left);
    arrayPostorder(tree, occupied, right);
    printf("%d ", tree[index]);
}

```


#### Array Binary Tree Level Order

Increasing array positions already follow level order. Skip the unused slots. No queue is needed for this representation.

```c

void arrayLevelOrder(const int tree[], const bool occupied[])
{
    for (int index = 0; index < TREE_SIZE; index++) {
        if (occupied[index] == true) {
            printf("%d ", tree[index]);
        }
    }
}

```


#### Remove a whole array subtree

Clear the children before the parent. We only change occupancy flags; the integer left in a cleared slot is ignored. This removes the entire chosen subtree, not one BST key.

```c

void clearArraySubtree(bool occupied[], int index)
{
    bool exists = hasArrayNode(occupied, index);
    if (exists == false) {
        return;
    }
    int left = 2 * index + 1;
    int right = 2 * index + 2;
    clearArraySubtree(occupied, left);
    clearArraySubtree(occupied, right);
    occupied[index] = false;
}

```


#### Main logic

Store 10 at the root, 20 and 30 below it, then 0 and 50 below 20. The values are deliberately not in BST order. Try each traversal, then remove the subtree at index 1.

```c

int main(void)
{
    int tree[TREE_SIZE] = {0};
    bool occupied[TREE_SIZE] = {false};
    int positions[] = {0, 1, 2, 3, 4};
    int values[] = {10, 20, 30, 0, 50};
    for (int i = 0; i < 5; i++) {
        bool stored = storeArrayNode(tree, occupied, positions[i], values[i]);
        if (stored == false) {
            printf("Cannot store this node.\n");
            return 1;
        }
    }
    printf("Preorder: ");
    arrayPreorder(tree, occupied, 0);
    printf("\nInorder: ");
    arrayInorder(tree, occupied, 0);
    printf("\nPostorder: ");
    arrayPostorder(tree, occupied, 0);
    printf("\nLevel order: ");
    arrayLevelOrder(tree, occupied);
    clearArraySubtree(occupied, 1);
    printf("\nAfter removing subtree at index 1: ");
    arrayLevelOrder(tree, occupied);
    putchar('\n');
    return 0;
}

```


> **Notice: Trace the same tree in four orders**

> Index:value is 0:10, 1:20, 2:30, 3:0, 4:50. Preorder: 10 20 0 50 30. Inorder: 0 20 50 10 30. Postorder: 0 50 20 30 10. Level order: 10 20 30 0 50. After clearing index 1: 10 30.


> **Q: Why keep occupied when tree already contains integers?**

> Answer: Zero, -1, and every other int may be real data. An extra flag lets us distinguish an absent node from a node whose value is zero. Never decide occupancy by checking the stored value.


> **Q: Why can a small skewed tree run out of array positions?**

> Answer: A chain of right children uses indices 0, 2, 6, 14, 30, 62. Our 31 slots fit only the first five nodes on that route. Complete trees pack well; a full tree need not be complete and can still leave gaps.


> **Q: What is the traversal cost here?**

> Answer: For n reachable nodes, preorder, inorder and postorder take Theta(n) time and O(h) call space. Our level-order scan checks all TREE_SIZE slots, so it costs Theta(TREE_SIZE), even when few are occupied. Clearing k nodes takes Theta(k).


### Linked Binary Tree Operations and Binary Search Trees

File: `tree.h`

We use pointer-linked nodes. An empty tree is NULL. A leaf has two NULL children. Height counts edges: an empty tree has height -1 and a leaf has height 0. Other books count nodes instead; neither convention is useful unless we state it.


#### Create one node

The constructor initializes both child links. Tree algorithms can now assume a new node starts as a valid leaf.

```c

/* Header guard: include these declarations only once in this C file. */
#ifndef COURSE_TREE_H
/* Remember that this header has already been included. */
#define COURSE_TREE_H
/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct Tree {
    int value;
    struct Tree *left;
    struct Tree *right;
} Tree;
static inline Tree *newTreeNode(int value)
{
    Tree *node = allocate(sizeof *node);
    node->value = value;
    node->left = NULL;
    node->right = NULL;
    return node;
}

```


#### Recursive Preorder Traversal

An empty subtree contributes no visit. Print the root, then recursively process the complete left subtree and the complete right subtree.

```c

static inline void preorder(const Tree *root)
{
    if (root == NULL) {
        return;
    }
    printf("%d ", root->value);
    preorder(root->left);
    preorder(root->right);
}

```


#### Recursive Inorder Traversal

This order is sorted only for a BST. It is still a valid traversal of an arbitrary binary tree, but no sortedness follows.

```c

static inline void inorder(const Tree *root)
{
    if (root == NULL) {
        return;
    }
    inorder(root->left);
    printf("%d ", root->value);
    inorder(root->right);
}

```


#### Recursive Postorder Traversal

Both child subtrees finish before the root is visited. This is the same dependency order needed to free children before their parent.

```c

static inline void postorder(const Tree *root)
{
    if (root == NULL) {
        return;
    }
    postorder(root->left);
    postorder(root->right);
    printf("%d ", root->value);
}

```


#### Count all nodes

Each nonempty subtree contributes its own root plus the counts from its two children. There is no need for a global counter.

```c

static inline int nodeCount(const Tree *root)
{
    if (root == NULL) {
        return 0;
    }
    int left = nodeCount(root->left);
    int right = nodeCount(root->right);
    return 1 + left + right;
}

```


#### Count leaves

A leaf contributes one. A nonleaf contributes the leaves from its children. Test for two missing children, not merely one.

```c

static inline int leafCount(const Tree *root)
{
    if (root == NULL) {
        return 0;
    }
    if (root->left == NULL && root->right == NULL) {
        return 1;
    }
    return leafCount(root->left) + leafCount(root->right);
}

```


#### Height follows the longer route

Compute both subtree heights, choose the larger, then add the edge to that child. The empty result -1 makes a leaf's height 0.

```c

static inline int treeHeight(const Tree *root)
{
    if (root == NULL) {
        return -1;
    }
    int left = treeHeight(root->left);
    int right = treeHeight(root->right);
    int largest = left;
    if (right > largest) {
        largest = right;
    }
    return largest + 1;
}

```


#### Binary Tree Copy

Copying only the root pointer creates an alias, not a second tree. This recursive copy allocates a distinct node for every original node.

```c

static inline Tree *copyTree(const Tree *root)
{
    if (root == NULL) {
        return NULL;
    }
    Tree *copy = newTreeNode(root->value);
    copy->left = copyTree(root->left);
    copy->right = copyTree(root->right);
    return copy;
}

```


#### Binary Tree Equality

If one root is NULL, both must be NULL. Otherwise compare the stored value and the matching child subtrees. Equal inorder output alone does not prove equal structure.

```c

static inline bool equalTrees(const Tree *first, const Tree *second)
{
    if (first == NULL || second == NULL) {
        return first == second;
    }
    if (first->value != second->value) {
        return false;
    }
    bool sameLeft = equalTrees(first->left, second->left);
    bool sameRight = equalTrees(first->right, second->right);
    return sameLeft && sameRight;
}

```


#### Binary Tree Mirror

Swap the two child routes at each node, then mirror those subtrees. This changes an ordinary BST into a reverse-ordered tree, so ordinary BST search would no longer apply.

```c

static inline void mirrorTree(Tree *root)
{
    if (root == NULL) {
        return;
    }
    Tree *temporary = root->left;
    root->left = root->right;
    root->right = temporary;
    mirrorTree(root->left);
    mirrorTree(root->right);
}

```


#### Destroy children before their parent

After freeing a node, its child routes cannot safely be read. Postorder cleanup reads those routes while the parent still exists.

```c

static inline void destroyTree(Tree *root)
{
    if (root == NULL) {
        return;
    }
    destroyTree(root->left);
    destroyTree(root->right);
    free(root);
}

```


#### Iterative BST Search

At each node, equality succeeds; a smaller key goes left and a larger key goes right. Before calling: the whole tree obeys strict BST ordering.

```c

static inline Tree *bstSearch(Tree *root, int key)
{
    while (root != NULL) {
        if (key == root->value) {
            return root;
        }
        if (key < root->value) {
            root = root->left;
        } else {
            root = root->right;
        }
    }
    return NULL;
}

```


#### BST Insertion

At an empty route, create a leaf. Otherwise insert into the appropriate child and store the returned route. Duplicate keys are ignored in this implementation.

```c

static inline Tree *bstInsert(Tree *root, int key)
{
    if (root == NULL) {
        return newTreeNode(key);
    }
    if (key < root->value) {
        root->left = bstInsert(root->left, key);
    } else if (key > root->value) {
        root->right = bstInsert(root->right, key);
    }
    return root;
}

```


#### Minimum and maximum follow an extreme route

The minimum has no left child; the maximum has no right child. NULL input gives NULL. These helpers return borrowed nodes.

```c

static inline Tree *bstMinimum(Tree *root)
{
    if (root == NULL) {
        return NULL;
    }
    while (root->left != NULL) {
        root = root->left;
    }
    return root;
}

```


#### Maximum follows the right route

The symmetric operation is shown separately so the direction is easy to see.

```c

static inline Tree *bstMaximum(Tree *root)
{
    if (root == NULL) {
        return NULL;
    }
    while (root->right != NULL) {
        root = root->right;
    }
    return root;
}

```


#### BST Deletion

Search first. With zero or one child, return the remaining child route after freeing the target node. With two children, copy only the successor's value, then delete that successor from the right subtree. The successor has no left child, so that second deletion reduces to a simpler case.

```c

static inline Tree *bstDelete(Tree *root, int key)
{
    if (root == NULL) {
        return NULL;
    }
    if (key < root->value) {
        root->left = bstDelete(root->left, key);
    } else if (key > root->value) {
        root->right = bstDelete(root->right, key);
    } else {
        if (root->left == NULL || root->right == NULL) {
            Tree *replacement = root->left;
            if (replacement == NULL) {
                replacement = root->right;
            }
            free(root);
            return replacement;
        }
        Tree *successor = bstMinimum(root->right);
        root->value = successor->value;
        root->right = bstDelete(root->right, successor->value);
    }
    return root;
}
#endif /* End of this header guard. */

```


> **Q: Which node actually disappears?**

> Answer: Delete 20 from a BST containing 20 with left child 10 and right subtree rooted at 30 with left child 25. The object that held 20 stays allocated but now stores 25. The original node that held 25 is freed.

> If 25 had a right child 27, that child would take 25's old place. Copying an entire node structure would copy child pointers too and could lose subtrees.


> **Q: What can we say about the cost?**

> Answer: Traversals, counts, copy, mirror, and cleanup are Theta(n) time. Recursive extra space is O(h+1), not always O(log n). BST search, insertion, and deletion take O(h+1); a chain gives O(n). Copy additionally owns Theta(n) output nodes. Height balance is a separate promise that an ordinary BST does not make.


### Queue of Binary Tree Pointers

File: `tree_queue.h`

A level-order traversal must queue Tree pointers. This is the same linked queue from the list chapter with a changed stored value type. We isolate it here so the traversal contains no queue-link manipulation. A queue cell owns its next link; it only borrows its Tree pointer.


#### Define queue cells

Keep front and rear. Empty means both are NULL. No tree node is copied or freed by the queue.

```c

/* Header guard: include these declarations only once in this C file. */
#ifndef TREE_QUEUE_H
/* Remember that this header has already been included. */
#define TREE_QUEUE_H
/* Reuse the linked binary tree type and tree operations. */
#include "tree.h"
typedef struct TreeCell {
    const Tree *value;
    struct TreeCell *next;
} TreeCell;
typedef struct {
    TreeCell *front;
    TreeCell *rear;
} TreeQueue;

```


#### Enqueue a borrowed tree route

Append a queue cell at rear. This is the same O(1) rear-insertion choice already justified for a linked queue.

```c

static inline void enqueueTree(TreeQueue *queue, const Tree *value)
{
    TreeCell *cell = allocate(sizeof *cell);
    cell->value = value;
    cell->next = NULL;
    if (queue->rear == NULL) {
        queue->front = cell;
    } else {
        queue->rear->next = cell;
    }
    queue->rear = cell;
}

```


#### Dequeue frees the cell not the tree

Return the borrowed route through an output parameter, advance front, and clear rear when the final cell leaves.

```c

static inline bool dequeueTree(TreeQueue *queue, const Tree **value)
{
    if (queue->front == NULL) {
        return false;
    }
    TreeCell *old = queue->front;
    *value = old->value;
    queue->front = old->next;
    if (queue->front == NULL) {
        queue->rear = NULL;
    }
    free(old);
    return true;
}
#endif /* End of this header guard. */

```


### Binary Tree Traversals and BST Example

File: `13_trees.c`

First build an arbitrary binary tree directly. Then build a separate BST through its insertion function. They share the same node representation but make different ordering promises.


#### Level Order Traversal

Enqueue the root, repeatedly remove the oldest waiting node, visit it, and enqueue its existing children. A child is not visited immediately because earlier nodes on the same level still deserve their turn.

```c

/* Reuse the queue of tree pointers; its link operations are already covered. */
#include "tree_queue.h"
void levelOrder(const Tree *root)
{
    if (root == NULL) {
        return;
    }
    TreeQueue queue = {NULL, NULL};
    enqueueTree(&queue, root);
    while (queue.front != NULL) {
        const Tree *current;
        bool ok = dequeueTree(&queue, &current);
        if (ok == false) {
            break;
        }
        printf("%d ", current->value);
        if (current->left != NULL) {
            enqueueTree(&queue, current->left);
        }
        if (current->right != NULL) {
            enqueueTree(&queue, current->right);
        }
    }
    putchar('\n');
}

```


#### Main logic

The first tree has root 10, left child 30 with left child 40, and right child 20. Its inorder is not sorted. After the general operations, build and modify a genuine BST.

```c

int main(void)
{
    Tree *root = newTreeNode(10);
    root->left = newTreeNode(30);
    root->left->left = newTreeNode(40);
    root->right = newTreeNode(20);
    printf("Preorder: ");
    preorder(root);
    printf("\nInorder: ");
    inorder(root);
    printf("\nPostorder: ");
    postorder(root);
    printf("\nLevel order: ");
    levelOrder(root);
    printf("Nodes %d Leaves %d Height %d\n",
           nodeCount(root), leafCount(root), treeHeight(root));
    Tree *copy = copyTree(root);
    printf("Equal copy: %d\n", equalTrees(root, copy));
    mirrorTree(copy);
    printf("Mirrored copy: ");
    levelOrder(copy);
    destroyTree(root);
    destroyTree(copy);
    Tree *bst = NULL;
    int keys[] = {20, 10, 30, 25, 40, 27};
    for (int i = 0; i < 6; i++) {
        bst = bstInsert(bst, keys[i]);
    }
    Tree *found = bstSearch(bst, 27);
    printf("Found 27: %d\n", found != NULL);
    printf("Min %d Max %d\n", bstMinimum(bst)->value,
           bstMaximum(bst)->value);
    bst = bstDelete(bst, 20);
    inorder(bst);
    putchar('\n');
    destroyTree(bst);
    return 0;
}

```


> **Q: What is waiting in the queue?**

> Answer: For the arbitrary tree, queue contents by value are [10], then [30,20], then [20,40], then [40], then empty. Visit order: 10,30,20,40. Time Theta(n), maximum queue space O(w), where w is maximum width. For a chain, width is 1 but recursive depth-first traversal needs O(n) call depth.


> **Notice: Array representation**

> With root at index 0, children of index i are at 2i+1 and 2i+2, and the parent of i>0 is (i-1)/2 using integer division. This fits complete trees well. A chain of h edges can require an index growing exponentially in h, wasting many positions.

> Linked representation allocates only existing nodes.


> **Q: Which BST traversal gives admission order?**

> Answer: None is guaranteed to. A BST stores key order, not arrival history. Inorder gives ascending IDs; preorder, postorder, and level order reflect shape. Keep a separate arrival queue or timestamp if admission order matters.


### Deletion in a General Binary Tree

File: `14_binary_delete.c`

In an arbitrary binary tree, replacing a target with its inorder successor need not have any special benefit. One common policy is to copy the deepest rightmost node's value into the target, then remove that deepest node. This preserves a complete shape if the tree was complete.

It is a policy, not the definition of all binary-tree deletion.


#### Find target and deepest node by breadth first order

Queue cells carry node and parent routes. A bounded helper queue is local to this demonstration. Before calling: at most CAPACITY nodes; overflow returns false without changing the tree. We locate everything before performing mutation. Duplicate policy: delete the first level-order match.

```c

/* Reuse the linked binary tree type and tree operations. */
#include "tree.h"
typedef struct {
    Tree *node;
    Tree *parent;
} Visit;
typedef struct {
    Visit items[CAPACITY];
    int count;
    int next;
} VisitQueue;
bool enqueueVisit(VisitQueue *queue, Tree *node, Tree *parent)
{
    if (queue->count == CAPACITY) {
        return false;
    }
    Visit visit = {node, parent};
    queue->items[queue->count] = visit;
    queue->count++;
    return true;
}

```


#### Dequeue the next recorded visit

This queue never reuses cells within one traversal, so its capacity bounds the total tree size. We state that choice instead of calling it a general circular queue.

```c

bool dequeueVisit(VisitQueue *queue, Visit *visit)
{
    if (queue->next == queue->count) {
        return false;
    }
    *visit = queue->items[queue->next];
    queue->next++;
    return true;
}

```


#### Apply the deepest rightmost replacement policy

The last BFS visit is deepest rightmost. It must be a leaf: a child would be visited later. Copy its value into the target, disconnect its parent link, and free it. If the tree has one node, set the caller's root to NULL.

```c

bool deleteBinary(Tree **root, int key)
{
    if (*root == NULL) {
        return false;
    }
    VisitQueue queue = {0};
    bool ok = enqueueVisit(&queue, *root, NULL);
    if (ok == false) {
        return false;
    }
    Tree *target = NULL;
    Visit deepest = {*root, NULL};
    while (queue.next < queue.count) {
        Visit visit;
        dequeueVisit(&queue, &visit);
        deepest = visit;
        if (target == NULL && visit.node->value == key) {
            target = visit.node;
        }
        if (visit.node->left != NULL) {
            ok = enqueueVisit(&queue, visit.node->left, visit.node);
            if (ok == false) {
                return false;
            }
        }
        if (visit.node->right != NULL) {
            ok = enqueueVisit(&queue, visit.node->right, visit.node);
            if (ok == false) {
                return false;
            }
        }
    }
    if (target == NULL) {
        return false;
    }
    target->value = deepest.node->value;
    if (deepest.parent == NULL) {
        *root = NULL;
    } else if (deepest.parent->left == deepest.node) {
        deepest.parent->left = NULL;
    } else {
        deepest.parent->right = NULL;
    }
    free(deepest.node);
    return true;
}

```


#### Main logic

Build 10 with children 30 and 20, then delete 10. The root object stays but receives value 20; its former right leaf is removed.

```c

int main(void)
{
    Tree *root = newTreeNode(10);
    root->left = newTreeNode(30);
    root->right = newTreeNode(20);
    bool deleted = deleteBinary(&root, 10);
    printf("Deleted: %d\n", deleted);
    preorder(root);
    putchar('\n');
    destroyTree(root);
    return 0;
}

```


> **Q: Why not use this for a BST?**

> Answer: A deepest leaf can have a value outside the target's permitted key range. Copying it into the target could break BST ordering. The BST uses a successor or predecessor precisely because it fits that range. Arbitrary binary deletion here takes O(n) time and O(n) recorded visits.


### Right Threaded Binary Search Tree

File: `15_threaded_tree.c`

This is a right-threaded BST. A missing right child may instead point to the inorder successor. rightIsThread tells us which meaning the pointer has. Left links are ordinary child links.


#### Create a leaf with a successor thread

A new leaf has no left child. Its right link is a thread, possibly NULL when there is no successor.

```c

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct ThreadNode {
    int value;
    struct ThreadNode *left;
    struct ThreadNode *right;
    bool rightIsThread;
} ThreadNode;
ThreadNode *newThreadNode(int value, ThreadNode *successor)
{
    ThreadNode *node = allocate(sizeof *node);
    node->value = value;
    node->left = NULL;
    node->right = successor;
    node->rightIsThread = true;
    return node;
}

```


#### Insert without confusing a thread with a child

Go left normally. Go right only when the link is a real child. A new left child threads to its parent. A new right child inherits the parent's old successor thread; the parent's right link becomes a real child.

```c

ThreadNode *threadInsert(ThreadNode *root, int value)
{
    if (root == NULL) {
        return newThreadNode(value, NULL);
    }
    ThreadNode *current = root;
    while (true) {
        if (value == current->value) {
            return root;
        }
        if (value < current->value) {
            if (current->left == NULL) {
                current->left = newThreadNode(value, current);
                return root;
            }
            current = current->left;
        } else {
            if (current->rightIsThread) {
                ThreadNode *node = newThreadNode(value, current->right);
                current->right = node;
                current->rightIsThread = false;
                return root;
            }
            current = current->right;
        }
    }
}

```


#### Find the leftmost real node

Left links never carry threads in this representation. An empty input has no leftmost node.

```c

ThreadNode *threadLeftmost(ThreadNode *root)
{
    if (root == NULL) {
        return NULL;
    }
    while (root->left != NULL) {
        root = root->left;
    }
    return root;
}

```


#### Find the next inorder node

Follow a thread directly. Otherwise, enter the real right subtree and walk to its leftmost node. No parent route or explicit stack is needed.

```c

ThreadNode *inorderSuccessor(ThreadNode *node)
{
    if (node->rightIsThread) {
        return node->right;
    }
    return threadLeftmost(node->right);
}

```


#### Traverse by successor routes

Visit the leftmost node, then repeatedly ask for its successor. Each node is printed once.

```c

void threadedInorder(ThreadNode *root)
{
    ThreadNode *current = threadLeftmost(root);
    while (current != NULL) {
        printf("%d ", current->value);
        current = inorderSuccessor(current);
    }
    putchar('\n');
}

```


#### Cleanup follows children only

A thread can point to an ancestor. Recursing through it would revisit nodes and could double-free them. Recurse right only when rightIsThread is false.

```c

void destroyThreaded(ThreadNode *root)
{
    if (root == NULL) {
        return;
    }
    destroyThreaded(root->left);
    if (root->rightIsThread == false) {
        destroyThreaded(root->right);
    }
    free(root);
}

```


#### Main logic

Insert five keys, traverse without recursion, and clean up through real children. Insertion order determines shape because this is not a balanced tree.

```c

int main(void)
{
    ThreadNode *root = NULL;
    int keys[] = {20, 10, 30, 15, 25};
    for (int i = 0; i < 5; i++) {
        root = threadInsert(root, keys[i]);
    }
    threadedInorder(root);
    destroyThreaded(root);
    return 0;
}

```


> **Q: Which right pointers are threads?**

> Answer: For the demo, 15.right threads to 20 and 25.right threads to 30. The maximum node 30 threads to NULL. But 20.right is a child link to 30. The tag is essential: the pointer value alone does not tell us its role.

> Traversal costs Theta(n) time and O(1) extra space; insertion remains O(h+1). Cleanup here still uses O(h+1) recursion space.


### Stack of Binary Tree Pointers

File: `tree_stack.h`

This is the linked stack rule with a Tree pointer as its stored value. The stack owns its cells and borrows tree nodes. Traversals call these functions rather than embedding push and pop logic.


#### Define and push one cell

The stack top is the head. Each push adds one cell in O(1). Initialize a TreeStack with {NULL}.

```c

/* Header guard: include these declarations only once in this C file. */
#ifndef COURSE_TREE_STACK_H
/* Remember that this header has already been included. */
#define COURSE_TREE_STACK_H
/* Reuse the linked binary tree type and tree operations. */
#include "tree.h"
typedef struct TreeStackCell {
    const Tree *value;
    struct TreeStackCell *next;
} TreeStackCell;
typedef struct {
    TreeStackCell *top;
} TreeStack;
static inline void pushTree(TreeStack *stack, const Tree *value)
{
    TreeStackCell *cell = allocate(sizeof *cell);
    cell->value = value;
    cell->next = stack->top;
    stack->top = cell;
}

```


#### Pop releases a cell

The tree node remains owned by its tree. Empty pop leaves the output unchanged.

```c

static inline bool popTree(TreeStack *stack, const Tree **value)
{
    if (stack->top == NULL) {
        return false;
    }
    TreeStackCell *old = stack->top;
    *value = old->value;
    stack->top = old->next;
    free(old);
    return true;
}

```


#### Peek keeps the cell

Iterative postorder needs to inspect an unfinished ancestor without removing it yet.

```c

static inline bool peekTree(const TreeStack *stack, const Tree **value)
{
    if (stack->top == NULL) {
        return false;
    }
    *value = stack->top->value;
    return true;
}
#endif /* End of this header guard. */

```


### Recursive Tree Creation and Iterative Traversals

File: `32_more_tree_operations.c`

The iterative traversals use tree_stack.h. Tree creation uses explicit missing-node tokens so -1 remains available as an ordinary value.


#### Recursive Binary Tree Creation

Consume one token per subtree. A missing token means NULL. Otherwise create a root, then its left and right subtrees. On malformed input, release the partial result. The caller starts position=0 and valid=true.

```c

/* Reuse the stack of tree pointers; its push and pop are already covered. */
#include "tree_stack.h"
/* Reuse the expression conversion and evaluation helpers. */
#include "expressions.h"
typedef struct {
    bool present;
    int value;
} TreeToken;
Tree *buildFromTokens(const TreeToken tokens[], int count,
                     int *position, bool *valid)
{
    if (*position >= count) {
        *valid = false;
        return NULL;
    }
    TreeToken token = tokens[*position];
    (*position)++;
    if (token.present == false) {
        return NULL;
    }
    Tree *root = newTreeNode(token.value);
    root->left = buildFromTokens(tokens, count, position, valid);
    if (*valid == false) {
        destroyTree(root);
        return NULL;
    }
    root->right = buildFromTokens(tokens, count, position, valid);
    if (*valid == false) {
        destroyTree(root);
        return NULL;
    }
    return root;
}

```


#### Search in a General Binary Tree

Check root, then left, then right. A result from one call must not linger in a static flag and affect a later search.

```c

const Tree *binaryTreeSearch(const Tree *root, int key)
{
    if (root == NULL) {
        return NULL;
    }
    if (root->value == key) {
        return root;
    }
    const Tree *found = binaryTreeSearch(root->left, key);
    if (found != NULL) {
        return found;
    }
    return binaryTreeSearch(root->right, key);
}

```


#### Recursive BST Search

Use this only when BST ordering holds. General binaryTreeSearch may need both subtrees.

```c

const Tree *recursiveBstSearch(const Tree *root, int key)
{
    if (root == NULL || root->value == key) {
        return root;
    }
    if (key < root->value) {
        return recursiveBstSearch(root->left, key);
    }
    return recursiveBstSearch(root->right, key);
}

```


#### Iterative Preorder Traversal

LIFO reverses insertion order. Push right first so left is the next node popped. Visit the node as soon as it leaves the stack.

```c

void iterativePreorder(const Tree *root)
{
    TreeStack stack = {NULL};
    if (root != NULL) {
        pushTree(&stack, root);
    }
    while (stack.top != NULL) {
        const Tree *current;
        popTree(&stack, &current);
        printf("%d ", current->value);
        if (current->right != NULL) {
            pushTree(&stack, current->right);
        }
        if (current->left != NULL) {
            pushTree(&stack, current->left);
        }
    }
    putchar('\n');
}

```


#### Iterative Inorder Traversal

Walk left while saving each ancestor. When no left node remains, pop and visit the waiting ancestor, then enter its right subtree.

```c

void iterativeInorder(const Tree *root)
{
    TreeStack stack = {NULL};
    const Tree *current = root;
    while (current != NULL || stack.top != NULL) {
        while (current != NULL) {
            pushTree(&stack, current);
            current = current->left;
        }
        popTree(&stack, &current);
        printf("%d ", current->value);
        current = current->right;
    }
    putchar('\n');
}

```


#### Iterative Postorder Traversal

lastVisited remembers the subtree just completed. At a waiting ancestor, enter its right subtree if it still needs work. Otherwise pop and visit that ancestor. This uses one stack.

```c

void iterativePostorder(const Tree *root)
{
    TreeStack stack = {NULL};
    const Tree *current = root;
    const Tree *lastVisited = NULL;
    while (current != NULL || stack.top != NULL) {
        if (current != NULL) {
            pushTree(&stack, current);
            current = current->left;
        } else {
            const Tree *waiting;
            peekTree(&stack, &waiting);
            if (waiting->right != NULL && lastVisited != waiting->right) {
                current = waiting->right;
            } else {
                popTree(&stack, &waiting);
                printf("%d ", waiting->value);
                lastVisited = waiting;
            }
        }
    }
    putchar('\n');
}

```


#### Expression Tree Evaluation

This small tree evaluator accepts single-digit leaves only. Evaluate left and right first, then reuse applyOperator. For multi-digit numeric input, use the separate token evaluators already provided.

```c

bool evaluateExpressionTree(const Expression *tree, int index, double *answer)
{
    ExpressionNode node = tree->nodes[index];
    if (node.left == -1) {
        if (isdigit((unsigned char)node.symbol) == 0) {
            return false;
        }
        *answer = node.symbol - '0';
        return true;
    }
    double left;
    double right;
    bool leftOK = evaluateExpressionTree(tree, node.left, &left);
    bool rightOK = evaluateExpressionTree(tree, node.right, &right);
    if (leftOK == false || rightOK == false) {
        return false;
    }
    return applyOperator(node.symbol, left, right, answer);
}

```


#### Main logic

Build root 10 with left 30 and right 20 from seven tokens. Both children are leaves. Confirm that two different searches work, run all iterative traversals, then evaluate (5-3)*4+9 as a tree.

```c

int main(void)
{
    TreeToken tokens[] = {{true,10}, {true,30}, {false,0}, {false,0},
                          {true,20}, {false,0}, {false,0}};
    int position = 0;
    bool valid = true;
    Tree *root = buildFromTokens(tokens, 7, &position, &valid);
    if (valid == false || position != 7) {
        destroyTree(root);
        return 1;
    }
    const Tree *first = binaryTreeSearch(root, 30);
    const Tree *second = binaryTreeSearch(root, 20);
    printf("Both searches found: %d %d\n", first != NULL, second != NULL);
    iterativePreorder(root);
    iterativeInorder(root);
    iterativePostorder(root);
    destroyTree(root);
    Tree *bst = NULL;
    bst = bstInsert(bst, 10);
    bst = bstInsert(bst, 20);
    const Tree *found = recursiveBstSearch(bst, 20);
    printf("Recursive BST found: %d\n", found != NULL);
    destroyTree(bst);
    char postfix[CAPACITY];
    bool ok = infixToPostfix("(5-3)*4+9", postfix, sizeof postfix);
    if (ok == false) {
        return 1;
    }
    Expression expression;
    ok = treeFromPostfix(postfix, &expression);
    if (ok == false) {
        return 1;
    }
    double answer;
    ok = evaluateExpressionTree(&expression, expression.root, &answer);
    if (ok) {
        printf("Tree value: %.0f\n", answer);
    }
    return 0;
}

```


> **Q: Why does a static found flag break later searches?**

> Answer: A static variable survives after the first function call returns. If it still says found, a later call may skip the subtree containing a different key. Return the current call's result instead. These general searches and traversals are O(n); explicit stacks use O(h+1) extra space.


> **Q: Why does postorder need lastVisited?**

> Answer: Consider root 10 with right leaf 20. After 20 is visited, root 10 is still waiting on the stack. Without remembering that its right subtree just finished, we could enter 20 again forever. lastVisited==waiting.right tells us it is now safe to visit the parent.


### Double Threaded Binary Tree with a Header

File: `33_fully_threaded.c`

A missing left child threads to the inorder predecessor. A missing right child threads to the successor. The header is the boundary marker and owns the real root through left.


#### Create the header

An empty header has a left thread to itself. Its right link points to itself and is tagged as a child link by this convention. For a nonempty tree, header.left becomes the root and leftThread becomes false.

```c

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct FNode {
    int value;
    struct FNode *left;
    struct FNode *right;
    bool leftThread;
    bool rightThread;
} FNode;
FNode *newThreadHeader(void)
{
    FNode *header = allocate(sizeof *header);
    header->value = 0;
    header->left = header;
    header->right = header;
    header->leftThread = true;
    header->rightThread = false;
    return header;
}

```


#### Create one threaded leaf

Its left and right routes initially represent predecessor and successor, not children.

```c

FNode *newFullyThreaded(int value, FNode *predecessor, FNode *successor)
{
    FNode *node = allocate(sizeof *node);
    node->value = value;
    node->left = predecessor;
    node->right = successor;
    node->leftThread = true;
    node->rightThread = true;
    return node;
}

```


#### Inorder Successor in a Threaded Tree

Follow a right thread directly. With a real right child, enter it and follow only real left children. Applied to the header, this finds the first node or returns the header if empty.

```c

FNode *fullSuccessor(FNode *node)
{
    FNode *next = node->right;
    if (node->rightThread == false) {
        while (next->leftThread == false) {
            next = next->left;
        }
    }
    return next;
}

```


#### Find the inorder predecessor

The same rule works backward: use a left thread or the rightmost node of a real left subtree.

```c

FNode *fullPredecessor(FNode *node)
{
    FNode *previous = node->left;
    if (node->leftThread == false) {
        while (previous->rightThread == false) {
            previous = previous->right;
        }
    }
    return previous;
}

```


#### Insert a new key where a search reaches a thread

Use BST comparisons to locate a missing child. A left insertion inherits the parent's predecessor and threads right to the parent. A right insertion inherits the successor and threads left to the parent. Duplicate keys return the existing node.

```c

FNode *fullInsert(FNode *header, int value)
{
    if (header->leftThread) {
        FNode *node = newFullyThreaded(value, header, header);
        header->left = node;
        header->leftThread = false;
        return node;
    }
    FNode *current = header->left;
    while (true) {
        if (value == current->value) {
            return current;
        }
        if (value < current->value) {
            if (current->leftThread) {
                FNode *node = newFullyThreaded(value, current->left, current);
                current->left = node;
                current->leftThread = false;
                return node;
            }
            current = current->left;
        } else {
            if (current->rightThread) {
                FNode *node = newFullyThreaded(value, current, current->right);
                current->right = node;
                current->rightThread = false;
                return node;
            }
            current = current->right;
        }
    }
}

```


#### Right Child Insertion in a Threaded Tree

The new node inherits the old right subtree. If that subtree exists, its leftmost node's predecessor thread must now point to the new node. The caller must choose a value that preserves ordering if this is a BST.

```c

FNode *insertRightOf(FNode *parent, int value)
{
    FNode *node = newFullyThreaded(value, parent, parent->right);
    if (parent->rightThread == false) {
        node->rightThread = false;
        FNode *oldSuccessor = parent->right;
        while (oldSuccessor->leftThread == false) {
            oldSuccessor = oldSuccessor->left;
        }
        oldSuccessor->left = node;
    }
    parent->right = node;
    parent->rightThread = false;
    return node;
}

```


#### Traverse forward or backward without a stack

Start at the header and ask for successor or predecessor. Stop when the header returns. Never print it as a data node.

```c

void printFullyThreaded(FNode *header, bool backward)
{
    FNode *current = header;
    while (true) {
        if (backward) {
            current = fullPredecessor(current);
        } else {
            current = fullSuccessor(current);
        }
        if (current == header) {
            break;
        }
        printf("%d ", current->value);
    }
    putchar('\n');
}

```


#### Cleanup computes the next route before freeing

Use inorder successors to free every real node once, then free the header. Do not treat threads as ordinary recursive child routes.

```c

void destroyFullyThreaded(FNode *header)
{
    FNode *current = fullSuccessor(header);
    while (current != header) {
        FNode *next = fullSuccessor(current);
        free(current);
        current = next;
    }
    free(header);
}

```


#### Display Predecessor and Successor Threads

Walk real nodes in inorder. Print only links tagged as threads. A boundary thread prints HEADER instead of the header's unused value.

```c

void displayThreads(FNode *header)
{
    FNode *current = fullSuccessor(header);
    while (current != header) {
        if (current->leftThread) {
            printf("%d left thread -> ", current->value);
            if (current->left == header) {
                puts("HEADER");
            } else {
                printf("%d\n", current->left->value);
            }
        }
        if (current->rightThread) {
            printf("%d right thread -> ", current->value);
            if (current->right == header) {
                puts("HEADER");
            } else {
                printf("%d\n", current->right->value);
            }
        }
        current = fullSuccessor(current);
    }
}

```


#### Main logic

Build 20,10,30,25. Insert 22 between 20 and its old right subtree. The predecessor thread at 25 must change from 20 to 22. Verify both traversal directions.

```c

int main(void)
{
    FNode *header = newThreadHeader();
    FNode *twenty = fullInsert(header, 20);
    fullInsert(header, 10);
    fullInsert(header, 30);
    fullInsert(header, 25);
    insertRightOf(twenty, 22);
    printFullyThreaded(header, false);
    printFullyThreaded(header, true);
    displayThreads(header);
    destroyFullyThreaded(header);
    return 0;
}

```


> **Q: Why must the old successor thread change?**

> Answer: Before insertion, 25 is the first inorder node after 20, so its predecessor thread points to 20. After inserting 22 as 20's new right child, the order is 20,22,25. The old thread must now point to 22.

> Forward traversal alone may miss a broken predecessor thread; check backward traversal too.


> **Q: What does threading save?**

> Answer: Forward and backward traversals use O(1) extra space and O(n) total time. A single successor call can still walk O(h) links. Full traversal is linear because those walks do not repeatedly traverse every edge for every node.


> **Q: Can inorder threads directly give every traversal?**

> Answer: No. These threads encode inorder neighbors. Preorder and postorder are possible with adapted algorithms, different threading rules, or extra bookkeeping. Following ordinary inorder successors does not magically become preorder. Thread maintenance also makes insertion and deletion more involved than in an unthreaded tree.


### General Tree with First Child and Next Sibling Links

File: `35_tree_representations.c`

A general tree can have more than two children. child reaches the first child; sibling reaches the next child of the same parent. The array binary tree is a separate example at the start of this chapter.


#### Define a first child next sibling node

child reaches the first child. sibling reaches the next child of the same parent. The root's sibling is NULL in this example.

```c

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct GeneralNode {
    int value;
    struct GeneralNode *child;
    struct GeneralNode *sibling;
} GeneralNode;
GeneralNode *newGeneralNode(int value)
{
    GeneralNode *node = allocate(sizeof *node);
    node->value = value;
    node->child = NULL;
    node->sibling = NULL;
    return node;
}

```


#### Append one child

The child must be a separate owned tree with sibling=NULL. Walk the existing sibling chain to keep child order.

```c

void appendChild(GeneralNode *parent, GeneralNode *child)
{
    if (parent->child == NULL) {
        parent->child = child;
        return;
    }
    GeneralNode *last = parent->child;
    while (last->sibling != NULL) {
        last = last->sibling;
    }
    last->sibling = child;
}

```


#### Visit a general tree in preorder

Visit the parent, then each child subtree in sibling order. A sibling link is not a right child in the original general-tree meaning.

```c

void generalPreorder(const GeneralNode *root)
{
    if (root == NULL) {
        return;
    }
    printf("%d ", root->value);
    for (const GeneralNode *child = root->child;
         child != NULL; child = child->sibling) {
        generalPreorder(child);
    }
}

```


#### Release a general tree

Save each next sibling before destroying that child subtree. Finally free the parent.

```c

void destroyGeneral(GeneralNode *root)
{
    if (root == NULL) {
        return;
    }
    GeneralNode *child = root->child;
    while (child != NULL) {
        GeneralNode *next = child->sibling;
        destroyGeneral(child);
        child = next;
    }
    free(root);
}

```


#### Main logic

Give root 1 three children. Print the general tree in preorder, then release it. This is a general linked tree, not a binary tree.

```c

int main(void)
{
    GeneralNode *root = newGeneralNode(1);
    GeneralNode *child = newGeneralNode(2);
    appendChild(root, child);
    child = newGeneralNode(3);
    appendChild(root, child);
    child = newGeneralNode(4);
    appendChild(root, child);
    generalPreorder(root);
    putchar('\n');
    destroyGeneral(root);
    return 0;
}

```


## 8 AVL Trees

AVL insertion, deletion, heights, and rotations.


### AVL Tree Insertion, Deletion and Rotations

File: `avl.h`

Height here counts nodes: NULL has height 0 and a leaf has height 1. Balance factor is left height minus right height. Every node must have balance -1, 0, or 1. This convention differs from tree.h by one, but balance factors are unchanged.


#### Store cached heights

Without cached heights, repeatedly traversing subtrees to calculate balance could make updates much slower. A constructor gives a new leaf height 1.

```c

/* Header guard: include these declarations only once in this C file. */
#ifndef COURSE_AVL_H
/* Remember that this header has already been included. */
#define COURSE_AVL_H
/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct AVL {
    int value;
    int height;
    struct AVL *left;
    struct AVL *right;
} AVL;
AVL *newAVL(int value)
{
    AVL *node = allocate(sizeof *node);
    node->value = value;
    node->height = 1;
    node->left = NULL;
    node->right = NULL;
    return node;
}

```


#### Read a cached height

The NULL convention keeps later arithmetic simple.

```c

int avlHeight(const AVL *node)
{
    if (node == NULL) {
        return 0;
    }
    return node->height;
}

```


#### Refresh after a child route changes

Read both heights, keep the larger, then add one for this node.

```c

void updateHeight(AVL *node)
{
    int largest = avlHeight(node->left);
    int right = avlHeight(node->right);
    if (right > largest) {
        largest = right;
    }
    node->height = largest + 1;
}

```


#### Measure the imbalance

Positive means taller on the left. Negative means taller on the right.

```c

int balanceFactor(const AVL *node)
{
    if (node == NULL) {
        return 0;
    }
    return avlHeight(node->left) - avlHeight(node->right);
}

```


#### AVL Right Rotation

Let pivot be root.left. The pivot's old right subtree moves to root.left, then root becomes pivot.right. Update the lower node's height before the new root's height.

```c

AVL *rotateRight(AVL *root)
{
    AVL *pivot = root->left;
    AVL *middle = pivot->right;
    pivot->right = root;
    root->left = middle;
    updateHeight(root);
    updateHeight(pivot);
    return pivot;
}

```


#### AVL Left Rotation

A rotation changes shape while preserving inorder order. The middle subtree stays between the same two key values.

```c

AVL *rotateLeft(AVL *root)
{
    AVL *pivot = root->right;
    AVL *middle = pivot->left;
    pivot->left = root;
    root->right = middle;
    updateHeight(root);
    updateHeight(pivot);
    return pivot;
}

```


#### AVL Rebalancing with LL, RR, LR and RL Cases

After refreshing height, repair left-heavy or right-heavy nodes. An inward-heavy child needs a preliminary rotation. Child balance zero belongs to the single-rotation case; this matters after deletion.

```c

AVL *rebalance(AVL *root)
{
    if (root == NULL) {
        return NULL;
    }
    updateHeight(root);
    int balance = balanceFactor(root);
    if (balance > 1) {
        if (balanceFactor(root->left) < 0) {
            root->left = rotateLeft(root->left);
        }
        return rotateRight(root);
    }
    if (balance < -1) {
        if (balanceFactor(root->right) > 0) {
            root->right = rotateRight(root->right);
        }
        return rotateLeft(root);
    }
    return root;
}

```


#### AVL Insertion

Store each returned child root. A rotation may change that root. Duplicates are ignored.

```c

AVL *avlInsert(AVL *root, int value)
{
    if (root == NULL) {
        return newAVL(value);
    }
    if (value < root->value) {
        root->left = avlInsert(root->left, value);
    } else if (value > root->value) {
        root->right = avlInsert(root->right, value);
    } else {
        return root;
    }
    return rebalance(root);
}

```


#### Locate the successor

The minimum of a nonempty right subtree has no left child. This is the same BST fact used before balancing was introduced.

```c

AVL *avlMinimum(AVL *root)
{
    while (root->left != NULL) {
        root = root->left;
    }
    return root;
}

```


#### AVL Deletion

Zero/one-child deletion frees the target and returns its child. Two-child deletion copies the successor value and deletes the successor. On return, rebalance every surviving ancestor, since deletion can reduce height repeatedly toward the root.

```c

AVL *avlDelete(AVL *root, int value)
{
    if (root == NULL) {
        return NULL;
    }
    if (value < root->value) {
        root->left = avlDelete(root->left, value);
    } else if (value > root->value) {
        root->right = avlDelete(root->right, value);
    } else {
        if (root->left == NULL || root->right == NULL) {
            AVL *child = root->left;
            if (child == NULL) {
                child = root->right;
            }
            free(root);
            return child;
        }
        AVL *successor = avlMinimum(root->right);
        root->value = successor->value;
        root->right = avlDelete(root->right, successor->value);
    }
    return rebalance(root);
}

```


#### Print values and current balance factors

Inorder output checks key order. The printed balance factors help a student see where a rotation was needed, but are not a complete correctness test by themselves.

```c

void printAVL(const AVL *root)
{
    if (root == NULL) {
        return;
    }
    printAVL(root->left);
    printf("%d(b=%d) ", root->value, balanceFactor(root));
    printAVL(root->right);
}

```


#### Destroy the AVL tree

Cleanup uses the same postorder rule as the ordinary tree; only the node type changed.

```c

void destroyAVL(AVL *root)
{
    if (root == NULL) {
        return;
    }
    destroyAVL(root->left);
    destroyAVL(root->right);
    free(root);
}
#endif /* End of this header guard. */

```


> **Notice: Four insertion shapes four answers**

> LL: insert 30,20,10; rotate right at 30. RR: insert 10,20,30; rotate left at 10. LR: insert 30,10,20; rotate left at 10 then right at 30. RL: insert 10,30,20; rotate right at 30 then left at 10. Each gives root 20 with children 10 and 30.

> LL/RR name the heavy path, not the rotation direction.


> **Notice: The deletion case that catches people**

> Before deleting 40 in the demo, root 30 has left child 20 with children 10 and 25, and right leaf 40. Delete 40: balance(30)=2 and balance(20)=0. A single right rotation is correct. New root 20 has left 10 and right 30 with left 25.

> Using the deleted key to classify the rotation is unreliable; use the surviving child's balance.


> **Q: Why heights are worth storing?**

> Answer: Each repair does O(1) local work and the AVL height is O(log n). Search, insertion, and deletion are O(log n). The recursive update paths use O(log n) extra space.

> Cached height is stored information that must be refreshed whenever child links change; stale stored information can choose the wrong repair.


### AVL Tree Example

File: `16_avl.c`


#### Main logic

Build a balanced tree, then delete two keys. Always assign the returned root: a root rotation or root deletion can change it.

```c

/* Reuse the AVL node type and balancing operations already covered. */
#include "avl.h"
int main(void)
{
    AVL *root = NULL;
    int keys[] = {30, 20, 40, 10, 25};
    for (int i = 0; i < 5; i++) {
        root = avlInsert(root, keys[i]);
    }
    root = avlDelete(root, 40);
    printAVL(root);
    putchar('\n');
    root = avlDelete(root, 20);
    printAVL(root);
    putchar('\n');
    destroyAVL(root);
    return 0;
}

```


## 9 Red-Black Trees

Insertion, colors, rotations, black height, and deletion.


### Red Black Tree Insertion and Deletion

File: `18_red_black.c`

Rules: the root is black, all NIL leaves are black, red nodes have black children, and every route from a node to a NIL leaf has the same black count. A shared black NIL sentinel replaces NULL child links. Duplicate keys are ignored.


#### Create one shared black NIL node

The sentinel points to itself so color checks on missing children are safe. Real nodes use NIL for missing children. NIL.parent is temporarily used during deletion repair; it is not a permanent parent for every leaf.

```c

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef enum { RED, BLACK } Color;
typedef struct RB {
    int value;
    Color color;
    struct RB *left;
    struct RB *right;
    struct RB *parent;
} RB;
RB sentinel;
RB *NIL = &sentinel;
void initRB(void)
{
    NIL->value = 0;
    NIL->color = BLACK;
    NIL->left = NIL;
    NIL->right = NIL;
    NIL->parent = NIL;
}

```


#### Create a red leaf

Making a new leaf red does not add a black node to existing root-to-leaf paths. A red parent may still need repair.

```c

RB *newRB(int value)
{
    RB *node = allocate(sizeof *node);
    node->value = value;
    node->color = RED;
    node->left = NIL;
    node->right = NIL;
    node->parent = NIL;
    return node;
}

```


#### Rotate left and reconnect the parent

Unlike the recursive AVL code, these nodes store parent routes. Repair the moved middle child's parent, reconnect the old parent or root, then put the old root under the pivot. Rotations do not recolor by themselves.

```c

void rbRotateLeft(RB **root, RB *node)
{
    RB *pivot = node->right;
    node->right = pivot->left;
    if (pivot->left != NIL) {
        pivot->left->parent = node;
    }
    pivot->parent = node->parent;
    if (node->parent == NIL) {
        *root = pivot;
    } else if (node == node->parent->left) {
        node->parent->left = pivot;
    } else {
        node->parent->right = pivot;
    }
    pivot->left = node;
    node->parent = pivot;
}

```


#### Rotate right with the symmetric links

The same reconnection steps apply in the opposite direction.

```c

void rbRotateRight(RB **root, RB *node)
{
    RB *pivot = node->left;
    node->left = pivot->right;
    if (pivot->right != NIL) {
        pivot->right->parent = node;
    }
    pivot->parent = node->parent;
    if (node->parent == NIL) {
        *root = pivot;
    } else if (node == node->parent->right) {
        node->parent->right = pivot;
    } else {
        node->parent->left = pivot;
    }
    pivot->right = node;
    node->parent = pivot;
}

```


#### Red Black Insertion Fixup

A red uncle allows recoloring and moving the check to the grandparent. A black uncle needs a rotation: first straighten an inward bend, then recolor and rotate the grandparent. Mirror the logic when the parent is a right child. Finish with a black root.

```c

void fixInsert(RB **root, RB *node)
{
    while (node->parent->color == RED) {
        RB *parent = node->parent;
        RB *grandparent = parent->parent;
        if (parent == grandparent->left) {
            RB *uncle = grandparent->right;
            if (uncle->color == RED) {
                parent->color = BLACK;
                uncle->color = BLACK;
                grandparent->color = RED;
                node = grandparent;
            } else {
                if (node == parent->right) {
                    node = parent;
                    rbRotateLeft(root, node);
                }
                node->parent->color = BLACK;
                node->parent->parent->color = RED;
                rbRotateRight(root, node->parent->parent);
            }
        } else {
            RB *uncle = grandparent->left;
            if (uncle->color == RED) {
                parent->color = BLACK;
                uncle->color = BLACK;
                grandparent->color = RED;
                node = grandparent;
            } else {
                if (node == parent->left) {
                    node = parent;
                    rbRotateRight(root, node);
                }
                node->parent->color = BLACK;
                node->parent->parent->color = RED;
                rbRotateLeft(root, node->parent->parent);
            }
        }
    }
    (*root)->color = BLACK;
}

```


#### Red Black Insertion

Search before allocating, so duplicate insertion creates no unused node. Attach the new leaf, set its parent, and call the balancing function.

```c

void rbInsert(RB **root, int value)
{
    RB *parent = NIL;
    RB *current = *root;
    while (current != NIL) {
        parent = current;
        if (value == current->value) {
            return;
        }
        if (value < current->value) {
            current = current->left;
        } else {
            current = current->right;
        }
    }
    RB *node = newRB(value);
    node->parent = parent;
    if (parent == NIL) {
        *root = node;
    } else if (value < parent->value) {
        parent->left = node;
    } else {
        parent->right = node;
    }
    fixInsert(root, node);
}

```


#### Search follows the BST rule

Return NIL rather than NULL when absent. Keep the representation consistent throughout this file.

```c

RB *rbSearch(RB *root, int value)
{
    while (root != NIL) {
        if (value == root->value) {
            return root;
        }
        if (value < root->value) {
            root = root->left;
        } else {
            root = root->right;
        }
    }
    return NIL;
}

```


#### Find the minimum of a nonempty subtree

The successor for a two-child deletion is the minimum of the right subtree. It has no real left child.

```c

RB *rbMinimum(RB *node)
{
    while (node->left != NIL) {
        node = node->left;
    }
    return node;
}

```


#### Transplant replaces a subtree route

Connect replacement to old's parent, including when old is the root. Set replacement.parent even when replacement is NIL: deletion repair needs that route. This helper does not copy colors or attach the replacement's other children.

```c

void transplant(RB **root, RB *old, RB *replacement)
{
    if (old->parent == NIL) {
        *root = replacement;
    } else if (old == old->parent->left) {
        old->parent->left = replacement;
    } else {
        old->parent->right = replacement;
    }
    replacement->parent = old->parent;
}

```


#### Red Black Deletion Fixup

Think of x as carrying one missing black count at its position. Case 1: red sibling, rotate to get a black sibling. Case 2: black sibling with two black children, recolor sibling and move the deficit up. Case 3: near child red and far child black, rotate sibling.

Case 4: far child red, recolor and rotate parent to finish. The second branch mirrors left and right.

```c

void fixDelete(RB **root, RB *x)
{
    while (x != *root && x->color == BLACK) {
        if (x == x->parent->left) {
            RB *sibling = x->parent->right;
            if (sibling->color == RED) {
                sibling->color = BLACK;
                x->parent->color = RED;
                rbRotateLeft(root, x->parent);
                sibling = x->parent->right;
            }
            if (sibling->left->color == BLACK
                && sibling->right->color == BLACK) {
                sibling->color = RED;
                x = x->parent;
            } else {
                if (sibling->right->color == BLACK) {
                    sibling->left->color = BLACK;
                    sibling->color = RED;
                    rbRotateRight(root, sibling);
                    sibling = x->parent->right;
                }
                sibling->color = x->parent->color;
                x->parent->color = BLACK;
                sibling->right->color = BLACK;
                rbRotateLeft(root, x->parent);
                x = *root;
            }
        } else {
            RB *sibling = x->parent->left;
            if (sibling->color == RED) {
                sibling->color = BLACK;
                x->parent->color = RED;
                rbRotateRight(root, x->parent);
                sibling = x->parent->left;
            }
            if (sibling->right->color == BLACK
                && sibling->left->color == BLACK) {
                sibling->color = RED;
                x = x->parent;
            } else {
                if (sibling->left->color == BLACK) {
                    sibling->right->color = BLACK;
                    sibling->color = RED;
                    rbRotateLeft(root, sibling);
                    sibling = x->parent->left;
                }
                sibling->color = x->parent->color;
                x->parent->color = BLACK;
                sibling->left->color = BLACK;
                rbRotateRight(root, x->parent);
                x = *root;
            }
        }
    }
    x->color = BLACK;
}

```


#### Red Black Deletion

z is the requested node. y is the node removed from its old position; x replaces y there. With two children, physically move the successor y into z's position and give y the old color of z. Save y's original color before that move.

Only a black original color can require black-count repair.

```c

bool rbDelete(RB **root, int value)
{
    RB *z = rbSearch(*root, value);
    if (z == NIL) {
        return false;
    }
    RB *y = z;
    Color originalColor = y->color;
    RB *x;
    if (z->left == NIL) {
        x = z->right;
        transplant(root, z, z->right);
    } else if (z->right == NIL) {
        x = z->left;
        transplant(root, z, z->left);
    } else {
        y = rbMinimum(z->right);
        originalColor = y->color;
        x = y->right;
        if (y->parent == z) {
            x->parent = y;
        } else {
            transplant(root, y, y->right);
            y->right = z->right;
            y->right->parent = y;
        }
        transplant(root, z, y);
        y->left = z->left;
        y->left->parent = y;
        y->color = z->color;
    }
    free(z);
    if (originalColor == BLACK) {
        fixDelete(root, x);
    }
    return true;
}

```


#### Print keys with their colors

Color tags make the state visible, but full validation also needs black-height and parent-link checks.

```c

void printRB(const RB *root)
{
    if (root == NIL) {
        return;
    }
    printRB(root->left);
    char color = 'B';
    if (root->color == RED) {
        color = 'R';
    }
    printf("%d%c ", root->value, color);
    printRB(root->right);
}

```


#### Free real nodes only

NIL is shared static storage. It must never be freed.

```c

void destroyRB(RB *root)
{
    if (root == NIL) {
        return;
    }
    destroyRB(root->left);
    destroyRB(root->right);
    free(root);
}

```


#### Main logic

Initialize NIL before building a tree. Insert a small standard sequence, then delete a red leaf, a black node, and a two-child target. The randomized checks supplied with the source exercise many more paths.

```c

int main(void)
{
    initRB();
    RB *root = NIL;
    int keys[] = {11, 2, 14, 1, 7, 15, 5, 8, 4};
    for (int i = 0; i < 9; i++) {
        rbInsert(&root, keys[i]);
    }
    printRB(root);
    putchar('\n');
    int removals[] = {15, 1, 7};
    for (int i = 0; i < 3; i++) {
        bool deleted = rbDelete(&root, removals[i]);
        printf("Deleted %d: %d\n", removals[i], deleted);
        printRB(root);
        putchar('\n');
    }
    destroyRB(root);
    return 0;
}

```


> **Q: Deleted node or removed node?**

> Answer: Two valid implementations use different physical moves. tree.h copies the successor's value and frees the successor object. This red-black version moves the successor object and frees z.

> In both, the color that matters for repair is the color removed from the successor's OLD position, before it takes the target's color. Do not decide from which object was passed to free.


> **Q: If the successor is red?**

> Answer: Example: 10B with children 5B and 15B, and 15 has left child 12R. Delete 10. Move 12 to the root and color it black, the old color of 10. Remove 12 from its old red-leaf position. No black count was removed there, so no deficit repair is needed.

> A red successor must be a leaf in a valid red-black tree: it has no left child, and a real right subtree would break its black height.


> **Q: If a black node has one real child?**

> Answer: That child must be a red leaf in a valid red-black tree. Example: 10B with left 5B and right 15B, where 5 has left 2R. Delete 5: 2 replaces it and fixDelete turns 2 black.

> The loop does not run because x is red; the final recoloring supplies the missing black count.


> **Notice: Case 2 moves the problem up**

> Example: root 10B with two leaves 5B and 15B. Delete 5. x is NIL on the left; sibling 15B has two black NIL children. Make 15 red and move x to 10. x is now the root, so the loop ends. The root remains black.

> Both root-to-NIL paths again have equal black counts.


> **Notice: Near and far depend on the side**

> When x is a left child, near is sibling.left and far is sibling.right. With root 10B, left 5B, right 15B with right 20R, deleting 5 uses case 4: rotate left at 10, make 20 black, and finish with root 15.

> If 15 instead has left 12R, use case 3 first: rotate right at 15, then case 4 at 10. When x is on the right, swap left and right everywhere.


> **Q: Why the loop needs several cases?**

> Answer: A red sibling does not directly absorb the deficit. Case 1 rotates it into a position where the new sibling is black. Then one of cases 2, 3, or 4 applies. Only case 2 may propagate the deficit upward.

> Search, insertion, and deletion are O(log n) because red-black height is O(log n). The iterative repair uses O(1) extra space; recursive printing and cleanup use O(log n).


## 10 Graphs

Adjacency matrix, adjacency lists, DFS, and BFS.


### Adjacency Matrix Graph: Array Only DFS and BFS

File: `41_array_graph.c`

This version stores the graph in a plain two-dimensional int array. Study it before the adjacency-list version. Indices start at 0; vertexCount stays between 0 and MAX.


#### Store only the adjacency matrix

graph[u][v] is 1 when an edge goes from u to v, and 0 otherwise. No linked edge nodes are created. MAX limits this graph to 10 vertices; int_queue.h reuses the earlier circular array queue for BFS.

```c

#include <stdio.h>
#include <stdbool.h>
/* Reuse the circular array queue: IntQueue, initQueue, enqueue and dequeue. */
#include "int_queue.h"
/* A named size limit; change it here rather than in every array. */
#define MAX 10

```


#### Check a vertex number

An active graph may have fewer vertices than the array can hold. Check against vertexCount, not just the physical capacity. A caller supplies a count from 0 to MAX.

```c

bool validMatrixVertex(int vertex, int vertexCount)
{
    if (vertex < 0 || vertex >= vertexCount) {
        return false;
    }
    return true;
}

```


#### Add a directed or undirected edge

Check both endpoints before using them as indices. A directed edge sets one cell. An undirected edge also sets the reverse cell. Repeating the same edge simply writes 1 again.

```c

bool addMatrixEdge(int graph[][MAX], int vertexCount,
                   int from, int to, bool directed)
{
    bool fromIsValid = validMatrixVertex(from, vertexCount);
    bool toIsValid = validMatrixVertex(to, vertexCount);
    if (fromIsValid == false || toIsValid == false) {
        return false;
    }
    graph[from][to] = 1;
    if (directed == false) {
        graph[to][from] = 1;
    }
    return true;
}

```


#### Display the active matrix

Print only the rows and columns belonging to actual vertices. Reading one row tells us all outgoing neighbors of that vertex.

```c

void displayMatrix(int graph[][MAX], int vertexCount)
{
    for (int row = 0; row < vertexCount; row++) {
        for (int column = 0; column < vertexCount; column++) {
            printf("%d ", graph[row][column]);
        }
        putchar('\n');
    }
}

```


#### DFS with an Array Adjacency Matrix

Mark and print this vertex. Scan its row for an edge to an unvisited neighbor, then recurse. The start vertex must be valid. DFS uses the call stack; it does not use a queue.

```c

void matrixOnlyDFS(int graph[][MAX], int vertexCount,
                   int vertex, bool visited[])
{
    visited[vertex] = true;
    printf("%d ", vertex);
    for (int neighbor = 0; neighbor < vertexCount; neighbor++) {
        if (graph[vertex][neighbor] == 0) {
            continue;
        }
        if (visited[neighbor] == false) {
            matrixOnlyDFS(graph, vertexCount, neighbor, visited);
        }
    }
}

```


#### BFS with an Array Adjacency Matrix

Reuse initQueue, enqueue and dequeue from the queue section. Mark a vertex before enqueueing it. Each vertex enters at most once; the earlier queue holds 128 items and this graph has at most 10 vertices. The start must be valid.

```c

void matrixOnlyBFS(int graph[][MAX], int vertexCount,
                   int start, bool visited[])
{
    IntQueue queue;
    initQueue(&queue);
    visited[start] = true;
    enqueue(&queue, start);
    while (queue.count > 0) {
        int vertex;
        dequeue(&queue, &vertex);
        printf("%d ", vertex);
        for (int neighbor = 0; neighbor < vertexCount; neighbor++) {
            if (graph[vertex][neighbor] == 0) {
                continue;
            }
            if (visited[neighbor] == false) {
                visited[neighbor] = true;
                enqueue(&queue, neighbor);
            }
        }
    }
}

```


> **Q: Is the graph linked just because BFS uses a queue?**

> Answer: No. The matrix stores the graph. A queue only remembers discovered vertices that are waiting for their turn. Here the reused queue is also array based. Changing the queue representation would not change how the graph is stored.


#### Visit every component with the same DFS

A start at 0 cannot reach a disconnected component. Start DFS again at each still-unvisited vertex. For an undirected graph, the number of new starts is the number of connected components.

```c

int matrixOnlyComponents(int graph[][MAX], int vertexCount)
{
    bool visited[MAX] = {false};
    int components = 0;
    for (int vertex = 0; vertex < vertexCount; vertex++) {
        if (visited[vertex] == false) {
            components++;
            matrixOnlyDFS(graph, vertexCount, vertex, visited);
        }
    }
    return components;
}

```


#### Main logic

Zero initialization means no edges. Vertices 0 to 3 form a cycle; 4 and 5 form another component. Reset visited before switching from DFS to BFS. false requests undirected edges; use true for directed edges.

```c

int main(void)
{
    int graph[MAX][MAX] = {0};
    int vertexCount = 6;
    int edges[][2] = {{0, 1}, {0, 2}, {1, 3}, {2, 3}, {4, 5}};
    for (int i = 0; i < 5; i++) {
        int from = edges[i][0];
        int to = edges[i][1];
        bool added = addMatrixEdge(graph, vertexCount, from, to, false);
        if (added == false) {
            printf("Invalid vertex.\n");
            return 1;
        }
    }
    printf("Adjacency matrix:\n");
    displayMatrix(graph, vertexCount);
    bool visited[MAX] = {false};
    printf("DFS from 0: ");
    matrixOnlyDFS(graph, vertexCount, 0, visited);
    for (int i = 0; i < vertexCount; i++) {
        visited[i] = false;
    }
    printf("\nBFS from 0: ");
    matrixOnlyBFS(graph, vertexCount, 0, visited);
    printf("\nDFS across all components: ");
    int components = matrixOnlyComponents(graph, vertexCount);
    printf("\nConnected components: %d\n", components);
    return 0;
}

```


> **Notice: Trace the difference between DFS and BFS**

> Neighbors are checked in increasing number order. DFS from 0 prints 0 1 3 2. BFS prints 0 1 2 3: after visiting 0, the queue contains [1, 2]; after 1, [2, 3]; after 2, [3]. Vertices 4 and 5 require another start. There are 2 components.


> **Q: Why is matrix traversal Theta(V squared) rather than Theta(V plus E)?**

> Answer: Every visited vertex scans V possible neighbors, even if most cells are zero. A full traversal visits V vertices, so it scans V*V cells. From a single start reaching r vertices, the cost is Theta(r*V). Adjacency lists inspect actual neighbor records instead.


> **Q: Does an undirected edge need two separate function calls?**

> Answer: No. addMatrixEdge with directed=false writes both [u][v] and [v][u]. With directed=true, it writes only [u][v]. The matrix is symmetric only when every stored edge has its reverse.


> **Q: What should I do with int_queue.h in one C file?**

> Answer: It contains the array queue already covered earlier. Keep that header beside this program, or place its IntQueue type and queue functions above the graph functions. The graph needs the queue operations, not a special filename. Do not paste a second main.


### Adjacency List Graph and Shared Matrix Traversals

File: `graph.h`

Vertices are numbered 0 to vertexCount-1. This demo supports at most CAPACITY vertices. It builds an undirected simple graph using adjacency lists and a matching matrix. Vertices are marked when discovered, before they enter BFS's queue.


#### Define list and matrix representations

A list node stores one neighbor. The Graph owns all such nodes. The fixed matrix reserves capacity squared cells even for a sparse graph; an input-sized matrix would use Theta(V^2) cells.

```c

/* Header guard: include these declarations only once in this C file. */
#ifndef COURSE_GRAPH_H
/* Remember that this header has already been included. */
#define COURSE_GRAPH_H
/* Reuse the circular array queue: IntQueue, initQueue, enqueue and dequeue. */
#include "int_queue.h"
typedef struct Edge {
    int to;
    struct Edge *next;
} Edge;
typedef struct {
    int vertexCount;
    Edge *neighbors[CAPACITY];
    bool matrix[CAPACITY][CAPACITY];
} Graph;

```


#### Initialize only a valid graph size

Zero initialization clears all head routes and adjacency cells. Dimensions are validated before any vertex is used.

```c

bool initGraph(Graph *graph, int vertices)
{
    if (vertices < 0 || vertices > CAPACITY) {
        return false;
    }
    memset(graph, 0, sizeof *graph);
    graph->vertexCount = vertices;
    return true;
}

```


#### Add one directed adjacency record

Head insertion is O(1). It reverses the order of edge input in each neighbor list. Traversal order therefore depends on representation order, not on an invisible promise to visit the smallest number first.

```c

void addArc(Graph *graph, int from, int to)
{
    Edge *edge = allocate(sizeof *edge);
    edge->to = to;
    edge->next = graph->neighbors[from];
    graph->neighbors[from] = edge;
    graph->matrix[from][to] = true;
}

```


#### An undirected edge has two adjacency records

Reject invalid vertices and self loops for this simple-graph demo. Repeated input edges are accepted without allocating duplicates. A directed version would call addArc only once.

```c

bool addUndirected(Graph *graph, int first, int second)
{
    if (first < 0 || second < 0 || first >= graph->vertexCount
        || second >= graph->vertexCount || first == second) {
        return false;
    }
    if (graph->matrix[first][second]) {
        return true;
    }
    addArc(graph, first, second);
    addArc(graph, second, first);
    return true;
}

```


#### Depth First Search with Adjacency Lists

Mark this vertex immediately, visit it, and recurse only into unvisited neighbors. Marking first prevents a back edge from recursively reentering the same vertex.

```c

void dfsFrom(const Graph *graph, int vertex, bool visited[])
{
    visited[vertex] = true;
    printf("%d ", vertex);
    for (const Edge *edge = graph->neighbors[vertex];
         edge != NULL; edge = edge->next) {
        if (visited[edge->to] == false) {
            dfsFrom(graph, edge->to, visited);
        }
    }
}

```


#### A DFS forest covers disconnected parts

A call from one start reaches only its connected component. The outer loop starts a new traversal whenever an unvisited vertex remains.

```c

void dfsAll(const Graph *graph)
{
    bool visited[CAPACITY] = {false};
    for (int vertex = 0; vertex < graph->vertexCount; vertex++) {
        if (visited[vertex] == false) {
            dfsFrom(graph, vertex, visited);
        }
    }
    putchar('\n');
}

```


#### Breadth First Search with Adjacency Lists

Queue the start. Dequeue a vertex, then discover all its unvisited neighbors. Mark a neighbor before enqueueing it. The queue stores vertex numbers through the existing IntQueue functions.

```c

void bfsFrom(const Graph *graph, int start, bool visited[])
{
    IntQueue queue;
    initQueue(&queue);
    visited[start] = true;
    bool ok = enqueue(&queue, start);
    if (ok == false) {
        return;
    }
    while (queue.count > 0) {
        int vertex;
        dequeue(&queue, &vertex);
        printf("%d ", vertex);
        for (const Edge *edge = graph->neighbors[vertex];
             edge != NULL; edge = edge->next) {
            int neighbor = edge->to;
            if (visited[neighbor] == false) {
                visited[neighbor] = true;
                ok = enqueue(&queue, neighbor);
                if (ok == false) {
                    fprintf(stderr, "Queue capacity invariant failed\n");
                    exit(EXIT_FAILURE);
                }
            }
        }
    }
}

```


#### A BFS forest also needs an outer loop

Each vertex enters a queue at most once. With at most CAPACITY vertices, the shared queue has enough room.

```c

void bfsAll(const Graph *graph)
{
    bool visited[CAPACITY] = {false};
    for (int vertex = 0; vertex < graph->vertexCount; vertex++) {
        if (visited[vertex] == false) {
            bfsFrom(graph, vertex, visited);
        }
    }
    putchar('\n');
}

```


#### Breadth First Search with an Adjacency Matrix

This version scans all possible vertex numbers to find neighbors. The queue operations and discovery timing remain the same.

```c

void matrixBfsFrom(const Graph *graph, int start, bool visited[])
{
    IntQueue queue;
    initQueue(&queue);
    visited[start] = true;
    enqueue(&queue, start);
    while (queue.count > 0) {
        int vertex;
        dequeue(&queue, &vertex);
        printf("%d ", vertex);
        for (int neighbor = 0; neighbor < graph->vertexCount; neighbor++) {
            if (graph->matrix[vertex][neighbor]
                && visited[neighbor] == false) {
                visited[neighbor] = true;
                bool ok = enqueue(&queue, neighbor);
                if (ok == false) {
                    exit(EXIT_FAILURE);
                }
            }
        }
    }
}

```


#### Cleanup releases adjacency records

Save next before freeing each edge. The matrix is part of Graph itself and needs no separate free.

```c

void destroyGraph(Graph *graph)
{
    for (int vertex = 0; vertex < graph->vertexCount; vertex++) {
        Edge *edge = graph->neighbors[vertex];
        while (edge != NULL) {
            Edge *next = edge->next;
            free(edge);
            edge = next;
        }
        graph->neighbors[vertex] = NULL;
    }
}
#endif /* End of this header guard. */

```


> **Q: Why mark when enqueueing?**

> Answer: In the diamond 0 connected to 1 and 2, both connected to 3, vertex 1 and vertex 2 can both discover 3. If 3 stays unmarked until it leaves the queue, both may enqueue it. Marking on discovery reserves it immediately. Here list BFS visits 0,2,1,3, then 4,5.

> Matrix BFS from 0 visits 0,1,2,3 because it scans indices upward. Both are correct.


> **Notice: Where the complexity comes from**

> Adjacency-list DFS/BFS takes Theta(V+E) for a full traversal: each vertex is handled once and each adjacency record is scanned once. An undirected edge has two records, still Theta(E). Matrix traversal scans V potential neighbors per visited vertex, giving Theta(V^2) for the full graph.

> Visited plus queue/call depth needs O(V) extra space. This demo stores both representations for comparison; a real application can choose one.


### Graph Traversal Example

File: `17_graphs.c`


#### Main logic

Vertices 0 through 3 form one component, and 4 and 5 form another. Run full list traversals, then a matrix traversal from 0 to show that one start does not cover the second component.

```c

/* Reuse the earlier graph types and graph operations. */
#include "graph.h"
int main(void)
{
    Graph graph;
    bool ok = initGraph(&graph, 6);
    if (ok == false) {
        return 1;
    }
    int edges[][2] = {{0,1}, {0,2}, {1,3}, {2,3}, {4,5}};
    for (int i = 0; i < 5; i++) {
        ok = addUndirected(&graph, edges[i][0], edges[i][1]);
        if (ok == false) {
            destroyGraph(&graph);
            return 1;
        }
    }
    printf("DFS forest: ");
    dfsAll(&graph);
    printf("BFS forest: ");
    bfsAll(&graph);
    bool visited[CAPACITY] = {false};
    printf("Matrix BFS from 0: ");
    matrixBfsFrom(&graph, 0, visited);
    putchar('\n');
    destroyGraph(&graph);
    return 0;
}

```


### Connected Components and Spanning Forests

File: `34_graph_connectivity.c`

Reuse graph.h and int_queue.h. Component counting below assumes an undirected graph. For directed graphs, reachability alone does not identify strongly connected components.


#### Add a directed edge

Validate both endpoints, suppress duplicates, then add one arc. Unlike the undirected helper, do not add the reverse arc.

```c

/* Reuse the earlier graph types and graph operations. */
#include "graph.h"
bool addDirected(Graph *graph, int from, int to)
{
    if (from < 0 || to < 0 || from >= graph->vertexCount
        || to >= graph->vertexCount) {
        return false;
    }
    if (graph->matrix[from][to]) {
        return true;
    }
    addArc(graph, from, to);
    return true;
}

```


#### Depth First Search with an Adjacency Matrix

The DFS rule is unchanged: mark before recursing. A full matrix-based forest scans Theta(V^2) cells.

```c

void matrixDfsFrom(const Graph *graph, int vertex, bool visited[])
{
    visited[vertex] = true;
    printf("%d ", vertex);
    for (int neighbor = 0; neighbor < graph->vertexCount; neighbor++) {
        if (graph->matrix[vertex][neighbor] && visited[neighbor] == false) {
            matrixDfsFrom(graph, neighbor, visited);
        }
    }
}

```


#### BFS Spanning Tree and Distances

label=-1 means undiscovered. On first discovery, store the parent and distance as well as the label. A new vertex gets distance[parent]+1 because every edge here counts as one step.

```c

void recordBfs(const Graph *graph, int start, int component,
               int labels[], int parents[], int distances[])
{
    IntQueue queue;
    initQueue(&queue);
    labels[start] = component;
    parents[start] = -1;
    distances[start] = 0;
    enqueue(&queue, start);
    while (queue.count > 0) {
        int vertex;
        dequeue(&queue, &vertex);
        for (const Edge *edge = graph->neighbors[vertex];
             edge != NULL; edge = edge->next) {
            int neighbor = edge->to;
            if (labels[neighbor] == -1) {
                labels[neighbor] = component;
                parents[neighbor] = vertex;
                distances[neighbor] = distances[vertex] + 1;
                bool ok = enqueue(&queue, neighbor);
                if (ok == false) {
                    exit(EXIT_FAILURE);
                }
            }
        }
    }
}

```


#### Connected Components

Initialize every vertex as undiscovered. Each unvisited start grows exactly one component in an undirected graph. Its recorded parents form a spanning tree for that component.

```c

int graphComponents(const Graph *graph, int labels[],
                     int parents[], int distances[])
{
    for (int i = 0; i < graph->vertexCount; i++) {
        labels[i] = -1;
        parents[i] = -1;
        distances[i] = -1;
    }
    int count = 0;
    for (int vertex = 0; vertex < graph->vertexCount; vertex++) {
        if (labels[vertex] == -1) {
            recordBfs(graph, vertex, count, labels, parents, distances);
            count++;
        }
    }
    return count;
}

```


#### DFS Spanning Tree

The edge that first discovers a vertex becomes its parent edge. An already visited neighbor does not get a new parent. The root starts with parent=-1.

```c

void recordDfs(const Graph *graph, int vertex, bool visited[], int parents[])
{
    visited[vertex] = true;
    for (const Edge *edge = graph->neighbors[vertex];
         edge != NULL; edge = edge->next) {
        int neighbor = edge->to;
        if (visited[neighbor] == false) {
            parents[neighbor] = vertex;
            recordDfs(graph, neighbor, visited, parents);
        }
    }
}

```


#### Print tree edges without repeating graph traversal

Each nonroot discovered vertex has one parent. These links are the tree edges. Remaining graph edges are nontree edges; an undirected parent edge is stored twice in the adjacency lists but is still one graph edge.

```c

void printForestEdges(const Graph *graph, const int parents[])
{
    for (int vertex = 0; vertex < graph->vertexCount; vertex++) {
        if (parents[vertex] != -1) {
            printf("%d - %d\n", parents[vertex], vertex);
        }
    }
}

```


#### Count incoming and outgoing directed edges

For this adjacency matrix, column vertex counts incoming edges and row vertex counts outgoing edges. In an undirected simple graph, either count is its ordinary degree.

```c

void vertexDegrees(const Graph *graph, int vertex, int *in, int *out)
{
    *in = 0;
    *out = 0;
    for (int other = 0; other < graph->vertexCount; other++) {
        if (graph->matrix[other][vertex]) {
            (*in)++;
        }
        if (graph->matrix[vertex][other]) {
            (*out)++;
        }
    }
}

```


#### Adjacency List to Adjacency Matrix Conversion

Clear the destination, then set one cell per stored arc. An undirected graph already has both arc directions. Clearing an input-sized matrix costs Theta(V^2), even when scanning the lists costs only O(V+E).

```c

void listsToMatrix(const Graph *graph, bool matrix[][CAPACITY])
{
    for (int row = 0; row < graph->vertexCount; row++) {
        for (int column = 0; column < graph->vertexCount; column++) {
            matrix[row][column] = false;
        }
    }
    for (int vertex = 0; vertex < graph->vertexCount; vertex++) {
        for (const Edge *edge = graph->neighbors[vertex];
             edge != NULL; edge = edge->next) {
            matrix[vertex][edge->to] = true;
        }
    }
}

```


#### Main logic

A triangle plus an isolated vertex has two components. Record its BFS forest, then a DFS tree from 0. Finally build a separate directed graph to show in-degree and out-degree.

```c

int main(void)
{
    Graph graph;
    bool ok = initGraph(&graph, 4);
    if (ok == false) {
        return 1;
    }
    addUndirected(&graph, 0, 1);
    addUndirected(&graph, 1, 2);
    addUndirected(&graph, 2, 0);
    int labels[CAPACITY];
    int parents[CAPACITY];
    int distances[CAPACITY];
    int components = graphComponents(&graph, labels, parents, distances);
    printf("Components: %d Connected: %d\n", components, components == 1);
    printForestEdges(&graph, parents);
    bool visited[CAPACITY] = {false};
    matrixDfsFrom(&graph, 0, visited);
    putchar('\n');
    for (int i = 0; i < graph.vertexCount; i++) {
        parents[i] = -1;
        visited[i] = false;
    }
    recordDfs(&graph, 0, visited, parents);
    printForestEdges(&graph, parents);
    destroyGraph(&graph);
    Graph directed;
    initGraph(&directed, 3);
    addDirected(&directed, 0, 1);
    addDirected(&directed, 2, 1);
    int in;
    int out;
    vertexDegrees(&directed, 1, &in, &out);
    printf("Vertex 1 in-degree %d out-degree %d\n", in, out);

    bool rebuilt[CAPACITY][CAPACITY];
    listsToMatrix(&directed, rebuilt);
    bool same = true;
    for (int row = 0; row < directed.vertexCount; row++) {
        for (int column = 0; column < directed.vertexCount; column++) {
            if (rebuilt[row][column] != directed.matrix[row][column]) {
                same = false;
            }
        }
    }
    printf("Rebuilt matrix matches: %d\n", same);
    destroyGraph(&directed);
    return 0;
}

```


> **Q: How many edges are in the recorded forest?**

> Answer: With V vertices and c undirected connected components, a spanning forest has V-c edges. A connected nonempty graph gives one tree with V-1 edges. DFS and BFS may choose different parent edges. Neither is automatically a minimum-weight spanning-tree algorithm.


> **Q: Does one BFS solve directed connectivity?**

> Answer: No. From 0 in the directed graph 0->1, we can reach 1, but 1 cannot reach 0. Strong connectivity needs reachability both ways. The undirected component-counting loop above must not be relabeled as a strongly-connected-components algorithm.


### Sorting on reverse input 4 3 2 1

| Algorithm | Pass | Array after pass | Movement |

| --- | --- | --- | --- |

| Bubble | 1 | 3 2 1 4 | 3 swaps |

| Bubble | 2 | 2 1 3 4 | 2 swaps |

| Bubble | 3 | 1 2 3 4 | 1 swap |

| Selection | 1 | 1 3 2 4 | 1 swap |

| Selection | 2 | 1 2 3 4 | 1 swap |

| Selection | 3 | 1 2 3 4 | 0 swaps |

| Insertion | Insert 3 | 3 4 2 1 | 1 shift |

| Insertion | Insert 2 | 2 3 4 1 | 2 shifts |

| Insertion | Insert 1 | 1 2 3 4 | 3 shifts |


### Sorting costs for these implementations

| Algorithm | Best time | Worst time | Equal keys stay ordered |

| --- | --- | --- | --- |

| Bubble with early stop | Theta(n) | Theta(n^2) | Yes |

| Selection | Theta(n^2) | Theta(n^2) | No |

| Insertion | Theta(n) | Theta(n^2) | Yes |


### Choose an end in a singly linked list

| Structure | Insertion | Deletion | Why |

| --- | --- | --- | --- |

| Stack | Head | Head | Both O(1) |

| Queue with tail route | Tail | Head | Both O(1) |

| Stack with top at tail | Tail | Tail | Pop needs predecessor: O(n) |

| Queue with reversed ends | Head | Tail | Deletion needs predecessor: O(n) |


### Shared cost reference

| Operation | Time | Extra working space |

| --- | --- | --- |

| Array stack / circular deque operation | O(1) | O(1) per operation |

| SLL insert or delete at known front | O(1) | O(1) excluding new node |

| SLL positional search / reverse | O(n) | O(1) |

| DLL delete a known real node | O(1) | O(1) |

| Polynomial merge addition | O(m+n) | O(1) excluding result |

| Full binary-tree traversal | Theta(n) | O(h+1) recursive |

| BST search / insert / delete | O(h+1) | O(h+1) for recursive updates |

| AVL or red-black update | O(log n) | AVL O(log n); RB repair O(1) |

| Full adjacency-list DFS / BFS | Theta(V+E) | O(V) |

| Full adjacency-matrix DFS / BFS | Theta(V^2) | O(V) |


> **Q: Why do we insert at the rear and delete from the front of a linked queue?**

> Answer: With head and tail routes, both operations take O(1). Reversing the ends still gives FIFO, but deleting the tail of a singly linked list takes O(n) because we must find its predecessor.


> **Q: Why is head the better top for a singly linked stack?**

> Answer: Push and pop both change the head in O(1). A tail route makes push easy, but it does not reveal the node before tail. Pop would need a traversal.


> **Q: Does one swap per pass make selection sort linear?**

> Answer: No. Finding the minimum still scans the remaining suffix. Its comparison total is n(n-1)/2. It uses at most n-1 swaps over the whole sort.


> **Q: Does insertion sort skip every check on sorted input?**

> Answer: No. It checks the while condition, but the body performs no shifts. The outer loop still runs n-1 times, so the best time is Theta(n), not O(1).


> **Q: Why does a head-changing function need a returned head or a double pointer?**

> Answer: A plain Node * parameter is a copied route. Reassigning it changes only the local copy. Return the new route and assign it, use Node **, or pass a List * whose head field can be changed.


> **Q: Why do we save next before freeing a node?**

> Answer: After free, the node no longer exists as a usable object. Reading node->next then is invalid. Save the route while the node is still alive.


> **Q: Can front and rear returning to their old values prove the queue contents are unchanged?**

> Answer: No. Indices describe positions, not the values stored there. After enough wraparound operations, the same positions may hold entirely different items.


> **Q: Why does BFS need a queue rather than a stack?**

> Answer: The queue processes earlier discoveries first, so it finishes nearer layers before deeper ones. A stack follows a recent route deeply. BFS gives shortest edge-count distances in an unweighted graph; DFS does not promise that.


> **Q: Why mark a BFS vertex before enqueueing it?**

> Answer: Two already-discovered vertices may share the same unvisited neighbor. Marking it immediately prevents both from queueing it. Each vertex then enters the queue at most once.


> **Q: Why does a BST deletion copy a successor value instead of an entire node?**

> Answer: The successor value fits the target position in sorted order. Copying the whole node would also copy child routes and could discard the target's original subtrees.


> **Q: Why can AVL deletion continue balancing above the first rotation?**

> Answer: Deleting a node may reduce a subtree height. A repair can leave that subtree shorter than before, so another ancestor may become unbalanced. The recursive code checks every ancestor on return.


> **Q: Why does a red successor need no black-deficit repair?**

> Answer: The old successor position loses a red node, so its black count stays unchanged. The successor must still take the target's old color at the target position. Its original color decides repair.


> **Q: Why not repeat enqueue code inside BFS?**

> Answer: The queue already has a clear job and a tested interface. BFS should decide which vertex to discover next; enqueue should maintain queue links or indices. Keeping those jobs separate makes both easier to read and fix.