/* Keep traversal separate from queue mechanics
 * Vertices are numbered 0 to vertexCount-1. This demo supports at most CAPACITY vertices. It builds an undirected simple graph using adjacency lists and a matching matrix. Vertices are marked when discovered, before they enter BFS's queue.
 */

/* Define list and matrix representations
 * A list node stores one neighbor. The Graph owns all such nodes. The fixed matrix reserves capacity squared cells even for a sparse graph; an input-sized matrix would use Theta(V^2) cells.
 */

/* Header guard: include these declarations only once in this C file. */
#ifndef COURSE_GRAPH_H
/* Remember that this header has already been included. */
#define COURSE_GRAPH_H
/* Reuse the circular array queue: IntQueue, initQueue, enqueue and dequeue. */
#include "int_queue.h"
typedef struct Edge {
    int to;
    struct Edge *next;
} Edge;
typedef struct {
    int vertexCount;
    Edge *neighbors[CAPACITY];
    bool matrix[CAPACITY][CAPACITY];
} Graph;

/* Initialize only a valid graph size
 * Zero initialization clears all head routes and adjacency cells. Dimensions are validated before any vertex is used.
 */

bool initGraph(Graph *graph, int vertices)
{
    if (vertices < 0 || vertices > CAPACITY) {
        return false;
    }
    memset(graph, 0, sizeof *graph);
    graph->vertexCount = vertices;
    return true;
}

/* Add one directed adjacency record
 * Head insertion is O(1). It reverses the order of edge input in each neighbor list. Traversal order therefore depends on representation order, not on an invisible promise to visit the smallest number first.
 */

void addArc(Graph *graph, int from, int to)
{
    Edge *edge = allocate(sizeof *edge);
    edge->to = to;
    edge->next = graph->neighbors[from];
    graph->neighbors[from] = edge;
    graph->matrix[from][to] = true;
}

/* An undirected edge has two adjacency records
 * Reject invalid vertices and self loops for this simple-graph demo. Repeated input edges are accepted without allocating duplicates. A directed version would call addArc only once.
 */

bool addUndirected(Graph *graph, int first, int second)
{
    if (first < 0 || second < 0 || first >= graph->vertexCount
        || second >= graph->vertexCount || first == second) {
        return false;
    }
    if (graph->matrix[first][second]) {
        return true;
    }
    addArc(graph, first, second);
    addArc(graph, second, first);
    return true;
}

/* DFS commits to one unfinished route
 * Mark this vertex immediately, visit it, and recurse only into unvisited neighbors. Marking first prevents a back edge from recursively reentering the same vertex.
 */

void dfsFrom(const Graph *graph, int vertex, bool visited[])
{
    visited[vertex] = true;
    printf("%d ", vertex);
    for (const Edge *edge = graph->neighbors[vertex];
         edge != NULL; edge = edge->next) {
        if (visited[edge->to] == false) {
            dfsFrom(graph, edge->to, visited);
        }
    }
}

/* A DFS forest covers disconnected parts
 * A call from one start reaches only its connected component. The outer loop starts a new traversal whenever an unvisited vertex remains.
 */

void dfsAll(const Graph *graph)
{
    bool visited[CAPACITY] = {false};
    for (int vertex = 0; vertex < graph->vertexCount; vertex++) {
        if (visited[vertex] == false) {
            dfsFrom(graph, vertex, visited);
        }
    }
    putchar('\n');
}

/* BFS lets older discoveries go first
 * Queue the start. Dequeue a vertex, then discover all its unvisited neighbors. Mark a neighbor before enqueueing it. The queue stores vertex numbers through the existing IntQueue functions.
 */

void bfsFrom(const Graph *graph, int start, bool visited[])
{
    IntQueue queue;
    initQueue(&queue);
    visited[start] = true;
    bool ok = enqueue(&queue, start);
    if (ok == false) {
        return;
    }
    while (queue.count > 0) {
        int vertex;
        dequeue(&queue, &vertex);
        printf("%d ", vertex);
        for (const Edge *edge = graph->neighbors[vertex];
             edge != NULL; edge = edge->next) {
            int neighbor = edge->to;
            if (visited[neighbor] == false) {
                visited[neighbor] = true;
                ok = enqueue(&queue, neighbor);
                if (ok == false) {
                    fprintf(stderr, "Queue capacity invariant failed\n");
                    exit(EXIT_FAILURE);
                }
            }
        }
    }
}

/* A BFS forest also needs an outer loop
 * Each vertex enters a queue at most once. With at most CAPACITY vertices, the shared queue has enough room.
 */

void bfsAll(const Graph *graph)
{
    bool visited[CAPACITY] = {false};
    for (int vertex = 0; vertex < graph->vertexCount; vertex++) {
        if (visited[vertex] == false) {
            bfsFrom(graph, vertex, visited);
        }
    }
    putchar('\n');
}

/* Matrix BFS changes neighbor discovery not the queue rule
 * This version scans all possible vertex numbers to find neighbors. The queue operations and discovery timing remain the same.
 */

void matrixBfsFrom(const Graph *graph, int start, bool visited[])
{
    IntQueue queue;
    initQueue(&queue);
    visited[start] = true;
    enqueue(&queue, start);
    while (queue.count > 0) {
        int vertex;
        dequeue(&queue, &vertex);
        printf("%d ", vertex);
        for (int neighbor = 0; neighbor < graph->vertexCount; neighbor++) {
            if (graph->matrix[vertex][neighbor]
                && visited[neighbor] == false) {
                visited[neighbor] = true;
                bool ok = enqueue(&queue, neighbor);
                if (ok == false) {
                    exit(EXIT_FAILURE);
                }
            }
        }
    }
}

/* Cleanup releases adjacency records
 * Save next before freeing each edge. The matrix is part of Graph itself and needs no separate free.
 */

void destroyGraph(Graph *graph)
{
    for (int vertex = 0; vertex < graph->vertexCount; vertex++) {
        Edge *edge = graph->neighbors[vertex];
        while (edge != NULL) {
            Edge *next = edge->next;
            free(edge);
            edge = next;
        }
        graph->neighbors[vertex] = NULL;
    }
}
#endif /* End of this header guard. */
