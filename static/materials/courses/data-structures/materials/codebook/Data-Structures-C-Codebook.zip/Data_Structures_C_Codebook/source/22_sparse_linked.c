/* Sparse matrices as a linked list
 * The PPT also shows a node-based sparse matrix. Each node stores one nonzero entry. Dimensions and the tail route belong to the container. This uses memory proportional to the nonzeros, plus one link per stored entry.
 */

/* Define a sparse entry node
 * A NULL head means no nonzero entries, not a matrix with no shape.
 */

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct SparseNode {
    int row;
    int column;
    int value;
    struct SparseNode *next;
} SparseNode;
typedef struct {
    int rows;
    int columns;
    SparseNode *head;
    SparseNode *tail;
} LinkedSparse;

/* Append one nonzero entry
 * Before calling: coordinates are valid and arrive in row-major order without duplicates. Skip zero. The stored tail makes each append O(1).
 */

void appendEntry(LinkedSparse *matrix, int row, int column, int value)
{
    if (value == 0) {
        return;
    }
    SparseNode *node = allocate(sizeof *node);
    node->row = row;
    node->column = column;
    node->value = value;
    node->next = NULL;
    if (matrix->tail == NULL) {
        matrix->head = node;
    } else {
        matrix->tail->next = node;
    }
    matrix->tail = node;
}

/* Release all entries
 * Save next before freeing. Reset both endpoints.
 */

void clearEntries(LinkedSparse *matrix)
{
    SparseNode *current = matrix->head;
    while (current != NULL) {
        SparseNode *next = current->next;
        free(current);
        current = next;
    }
    matrix->head = NULL;
    matrix->tail = NULL;
}

/* Main logic
 * Scan a dense matrix and reuse appendEntry. Then walk only the stored nonzeros.
 */

int main(void)
{
    const int dense[2][3] = {{0, 7, 0}, {4, 0, 9}};
    LinkedSparse matrix = {2, 3, NULL, NULL};
    for (int row = 0; row < matrix.rows; row++) {
        for (int column = 0; column < matrix.columns; column++) {
            appendEntry(&matrix, row, column, dense[row][column]);
        }
    }
    for (SparseNode *p = matrix.head; p != NULL; p = p->next) {
        printf("(%d,%d) = %d\n", p->row, p->column, p->value);
    }
    clearEntries(&matrix);
    return 0;
}
