/* Reuse the queue rule with a different payload
 * A level-order traversal must queue Tree pointers. This is the same linked queue from the list chapter with a changed payload type. We isolate it here so the traversal contains no queue-link manipulation. A queue cell owns its next link; it only borrows its Tree pointer.
 */

/* Define queue cells
 * Keep front and rear. Empty means both are NULL. No tree node is copied or freed by the queue.
 */

/* Header guard: include these declarations only once in this C file. */
#ifndef TREE_QUEUE_H
/* Remember that this header has already been included. */
#define TREE_QUEUE_H
/* Reuse the linked binary tree type and tree operations. */
#include "tree.h"
typedef struct TreeCell {
    const Tree *value;
    struct TreeCell *next;
} TreeCell;
typedef struct {
    TreeCell *front;
    TreeCell *rear;
} TreeQueue;

/* Enqueue a borrowed tree route
 * Append a queue cell at rear. This is the same O(1) rear-insertion choice already justified for a linked queue.
 */

static inline void enqueueTree(TreeQueue *queue, const Tree *value)
{
    TreeCell *cell = allocate(sizeof *cell);
    cell->value = value;
    cell->next = NULL;
    if (queue->rear == NULL) {
        queue->front = cell;
    } else {
        queue->rear->next = cell;
    }
    queue->rear = cell;
}

/* Dequeue frees the cell not the tree
 * Return the borrowed route through an output parameter, advance front, and clear rear when the final cell leaves.
 */

static inline bool dequeueTree(TreeQueue *queue, const Tree **value)
{
    if (queue->front == NULL) {
        return false;
    }
    TreeCell *old = queue->front;
    *value = old->value;
    queue->front = old->next;
    if (queue->front == NULL) {
        queue->rear = NULL;
    }
    free(old);
    return true;
}
#endif /* End of this header guard. */
