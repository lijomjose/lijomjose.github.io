#include <assert.h>
#define main demo_main
#include "13_trees.c"
#undef main

int checkTree(Tree *p,long long lo,long long hi) {
 if(!p)return 0;
 assert(p->value>lo && p->value<hi);
 return 1+checkTree(p->left,lo,p->value)+checkTree(p->right,p->value,hi);
}
int main(void) {
 srand(55);Tree *root=NULL;bool present[80]={false};
 for(int step=0;step<4000;step++) {
  int v=rand()%80;
  if(rand()%2){root=bstInsert(root,v);present[v]=true;}else{root=bstDelete(root,v);present[v]=false;}
  int count=0;
  for(int i=0;i<80;i++){assert((bstSearch(root,i)!=NULL)==present[i]);count+=present[i];}
  assert(checkTree(root,LLONG_MIN,LLONG_MAX)==count);
 }
 Tree *copy=copyTree(root);assert(equalTrees(copy,root));mirrorTree(copy);mirrorTree(copy);assert(equalTrees(copy,root));
 destroyTree(copy);destroyTree(root);return 0;
}
