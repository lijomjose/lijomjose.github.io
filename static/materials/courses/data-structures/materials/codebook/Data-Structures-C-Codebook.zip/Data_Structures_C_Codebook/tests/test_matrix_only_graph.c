#include <assert.h>
#include <stdlib.h>
#define main matrix_demo_main
#include "41_array_graph.c"
#undef main

int main(void)
{
    assert(freopen("/dev/null", "w", stdout) != NULL);
    srand(43);
    for (int n = 0; n <= MAX; n++) {
        for (int directed = 0; directed <= 1; directed++) {
            for (int trial = 0; trial < 20; trial++) {
                int graph[MAX][MAX] = {0};
                bool reachable[MAX][MAX] = {{false}};
                assert(addMatrixEdge(graph, n, -1, 0, directed) == false);
                assert(addMatrixEdge(graph, n, 0, n, directed) == false);
                for (int i = 0; i < n; i++) {
                    reachable[i][i] = true;
                    for (int j = 0; j < n; j++) {
                        if (rand() % 5 == 0) {
                            assert(addMatrixEdge(graph, n, i, j, directed));
                            assert(addMatrixEdge(graph, n, i, j, directed));
                        }
                    }
                }
                for (int i = 0; i < n; i++) {
                    for (int j = 0; j < n; j++) {
                        if (graph[i][j]) reachable[i][j] = true;
                        if (!directed) assert(graph[i][j] == graph[j][i]);
                    }
                }
                for (int k = 0; k < n; k++) {
                    for (int i = 0; i < n; i++) {
                        for (int j = 0; j < n; j++) {
                            if (reachable[i][k] && reachable[k][j]) {
                                reachable[i][j] = true;
                            }
                        }
                    }
                }
                for (int start = 0; start < n; start++) {
                    bool dfsSeen[MAX] = {false};
                    bool bfsSeen[MAX] = {false};
                    matrixOnlyDFS(graph, n, start, dfsSeen);
                    matrixOnlyBFS(graph, n, start, bfsSeen);
                    for (int v = 0; v < n; v++) {
                        assert(dfsSeen[v] == reachable[start][v]);
                        assert(bfsSeen[v] == reachable[start][v]);
                    }
                }
                if (!directed) {
                    int expected = 0;
                    bool counted[MAX] = {false};
                    for (int v = 0; v < n; v++) {
                        if (!counted[v]) {
                            expected++;
                            for (int j = 0; j < n; j++) {
                                if (reachable[v][j]) counted[j] = true;
                            }
                        }
                    }
                    assert(matrixOnlyComponents(graph, n) == expected);
                }
            }
        }
    }
    return 0;
}
