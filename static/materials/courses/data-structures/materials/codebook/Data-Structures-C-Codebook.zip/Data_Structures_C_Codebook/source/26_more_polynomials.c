/* Singly linked circular and linear DLL polynomials
 * Use one merge idea for each node representation. SLL terms have only next. The circular SLL wrapper changes the ending marker and closes a new header ring. The DLL version reuses polynomial.h rather than repeating its algebra.
 */

/* Define singly linked terms and append once
 * Append only nonzero terms. The output tail makes each attachment O(1). Input streams must already have distinct descending nonnegative exponents.
 */

/* Reuse the polynomial types and operations already covered. */
#include "polynomial.h"
typedef struct STerm {
    int coefficient;
    int exponent;
    struct STerm *next;
} STerm;
typedef struct {
    STerm *head;
    STerm *tail;
} SPolynomial;
void sAttach(SPolynomial *polynomial, int coefficient, int exponent)
{
    if (coefficient == 0) {
        return;
    }
    STerm *node = allocate(sizeof *node);
    node->coefficient = coefficient;
    node->exponent = exponent;
    node->next = NULL;
    if (polynomial->tail == NULL) {
        polynomial->head = node;
    } else {
        polynomial->tail->next = node;
    }
    polynomial->tail = node;
}

/* Merge singly linked term streams
 * The end markers may be NULL or header nodes. Each input cursor advances once per consumed term. sAttach keeps link details out of the comparison logic.
 */

SPolynomial sMerge(const STerm *a, const STerm *endA,
                   const STerm *c, const STerm *endC)
{
    SPolynomial result = {NULL, NULL};
    while (a != endA || c != endC) {
        int coefficient;
        int exponent;
        if (c == endC || (a != endA && a->exponent > c->exponent)) {
            coefficient = a->coefficient;
            exponent = a->exponent;
            a = a->next;
        } else if (a == endA || c->exponent > a->exponent) {
            coefficient = c->coefficient;
            exponent = c->exponent;
            c = c->next;
        } else {
            coefficient = a->coefficient + c->coefficient;
            exponent = a->exponent;
            a = a->next;
            c = c->next;
        }
        sAttach(&result, coefficient, exponent);
    }
    return result;
}

/* Add linear singly linked polynomials
 * NULL marks both ends. Returning the head and tail preserves a convenient complete list object.
 */

SPolynomial sAdd(const SPolynomial *first, const SPolynomial *second)
{
    return sMerge(first->head, NULL, second->head, NULL);
}

/* Turn an owned linear SLL polynomial into a header ring
 * Create a header even for zero. Connect the final real term to it and clear the old owner. The header is recognized by its address, not by borrowing an exponent value.
 */

STerm *sMakeCircular(SPolynomial *linear)
{
    STerm *header = allocate(sizeof *header);
    header->coefficient = 0;
    header->exponent = 0;
    header->next = header;
    if (linear->head != NULL) {
        header->next = linear->head;
        linear->tail->next = header;
    }
    linear->head = NULL;
    linear->tail = NULL;
    return header;
}

/* Circular SLL addition changes only the boundary handling
 * Skip the headers, use them as end markers in the same merge, then close the result ring. No repeated term-comparison algorithm is needed.
 */

STerm *sAddCircular(const STerm *first, const STerm *second)
{
    SPolynomial sum = sMerge(first->next, first, second->next, second);
    return sMakeCircular(&sum);
}

/* Clear a singly linked term stream
 * Use NULL as end for a linear chain or the header as end for a circle. This function does not free an ending header; the caller frees that separately.
 */

void sClear(STerm *current, const STerm *end)
{
    while (current != end) {
        STerm *next = current->next;
        free(current);
        current = next;
    }
}

/* Remove a DLL polynomial header to get a linear DLL
 * Transfer all real terms out of an owned ring. Break the two boundary links, then free only the header. An empty polynomial becomes NULL.
 */

PolyTerm *detachPolynomialHeader(PolyTerm *header)
{
    PolyTerm *first = NULL;
    if (header->next != header) {
        first = header->next;
        first->previous = NULL;
        header->previous->next = NULL;
    }
    free(header);
    return first;
}

/* Add linear DLL polynomials through the same merge
 * NULL marks both input ends. mergePolynomialStreams already maintains previous and next in its output. Detaching that result header gives the requested linear DLL.
 */

PolyTerm *addLinearDoubly(const PolyTerm *first, const PolyTerm *second)
{
    PolyTerm *ring = mergePolynomialStreams(first, NULL, second, NULL);
    return detachPolynomialHeader(ring);
}

/* Release a linear DLL polynomial
 * Save next before freeing. The previous links need no repair because the entire list is being destroyed.
 */

void clearLinearDoubly(PolyTerm *first)
{
    while (first != NULL) {
        PolyTerm *next = first->next;
        free(first);
        first = next;
    }
}

/* Insert or combine one SLL polynomial term
 * Keep descending powers. At an equal power, add coefficients and delete a zero sum. Otherwise connect a new node between previous and current. Update the output tail whenever the final node changes.
 */

void sAddTerm(SPolynomial *polynomial, int coefficient, int exponent)
{
    if (coefficient == 0) {
        return;
    }
    STerm *previous = NULL;
    STerm *current = polynomial->head;
    while (current != NULL && current->exponent > exponent) {
        previous = current;
        current = current->next;
    }
    if (current != NULL && current->exponent == exponent) {
        current->coefficient = current->coefficient + coefficient;
        if (current->coefficient == 0) {
            if (previous == NULL) {
                polynomial->head = current->next;
            } else {
                previous->next = current->next;
            }
            if (polynomial->tail == current) {
                polynomial->tail = previous;
            }
            free(current);
        }
        return;
    }
    STerm *node = allocate(sizeof *node);
    node->coefficient = coefficient;
    node->exponent = exponent;
    node->next = current;
    if (previous == NULL) {
        polynomial->head = node;
    } else {
        previous->next = node;
    }
    if (current == NULL) {
        polynomial->tail = node;
    }
}

/* Multiply SLL term streams with explicit endings
 * Use NULL endings for ordinary SLL polynomials, or header endings for circular SLL inputs. The output here is linear; sMakeCircular can close it afterward.
 */

SPolynomial sMultiply(const STerm *a, const STerm *endA,
                      const STerm *c, const STerm *endC)
{
    SPolynomial result = {NULL, NULL};
    for (const STerm *first = a; first != endA; first = first->next) {
        for (const STerm *second = c; second != endC; second = second->next) {
            int coefficient = first->coefficient * second->coefficient;
            int exponent = first->exponent + second->exponent;
            sAddTerm(&result, coefficient, exponent);
        }
    }
    return result;
}

/* Multiply linear DLL inputs through the shared algebra
 * The stream routine accepts NULL endings. Detach only the new output header. Inputs stay unchanged.
 */

PolyTerm *multiplyLinearDoubly(const PolyTerm *first, const PolyTerm *second)
{
    PolyTerm *ring = multiplyPolynomialStreams(first, NULL, second, NULL);
    return detachPolynomialHeader(ring);
}

/* Main logic
 * Add 3x^2+2 and -3x^2+4x using a linear SLL, then the circular SLL wrapper, then a linear DLL. All three results are 4x+2. The earlier header-ring program covers circular DLL addition and multiplication.
 */

int main(void)
{
    SPolynomial a = {NULL, NULL};
    SPolynomial c = {NULL, NULL};
    sAttach(&a, 3, 2);
    sAttach(&a, 2, 0);
    sAttach(&c, -3, 2);
    sAttach(&c, 4, 1);
    SPolynomial sum = sAdd(&a, &c);
    for (STerm *p = sum.head; p != NULL; p = p->next) {
        printf("%+d*x^%d ", p->coefficient, p->exponent);
    }
    putchar('\n');
    sClear(sum.head, NULL);
    STerm *aRing = sMakeCircular(&a);
    STerm *cRing = sMakeCircular(&c);
    STerm *sumRing = sAddCircular(aRing, cRing);
    for (STerm *p = sumRing->next; p != sumRing; p = p->next) {
        printf("%+d*x^%d ", p->coefficient, p->exponent);
    }
    putchar('\n');
    sClear(aRing->next, aRing);
    sClear(cRing->next, cRing);
    sClear(sumRing->next, sumRing);
    free(aRing);
    free(cRing);
    free(sumRing);
    PolyTerm *d = newPolynomial();
    PolyTerm *e = newPolynomial();
    addTerm(d, 3, 2);
    addTerm(d, 2, 0);
    addTerm(e, -3, 2);
    addTerm(e, 4, 1);
    d = detachPolynomialHeader(d);
    e = detachPolynomialHeader(e);
    PolyTerm *linearSum = addLinearDoubly(d, e);
    for (PolyTerm *p = linearSum; p != NULL; p = p->next) {
        printf("%+d*x^%d ", p->coefficient, p->exponent);
    }
    putchar('\n');
    clearLinearDoubly(d);
    clearLinearDoubly(e);
    clearLinearDoubly(linearSum);
    return 0;
}
