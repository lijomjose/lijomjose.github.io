/* Linear queues multiple queues and restricted deques
 * The simple array queue intentionally does not wrap or shift. Multiple linked queues reuse List. Restricted deques expose only the allowed entry and exit operations.
 */

/* Initialize a simple linear array queue
 * front is the next item to leave; rear is the last occupied index. Empty means front>rear. We keep this version separate from the circular queue to make its limitation visible.
 */

/* Reuse the circular array queue: IntQueue, initQueue, enqueue and dequeue. */
#include "int_queue.h"
/* Reuse the singly linked list types and operations already covered. */
#include "slist.h"
typedef struct {
    int items[CAPACITY];
    int front;
    int rear;
} LinearQueue;
void initLinear(LinearQueue *queue)
{
    queue->front = 0;
    queue->rear = -1;
}

/* Linear insertion advances rear only
 * Vacated cells before front are not reused. This is the sequential implementation shown before circular queues in the PPT.
 */

bool linearEnqueue(LinearQueue *queue, int value)
{
    if (queue->rear == CAPACITY - 1) {
        return false;
    }
    queue->rear++;
    queue->items[queue->rear] = value;
    return true;
}

/* Linear deletion advances front only
 * Do not shift the remaining items. This makes deletion O(1), but it leaves the earlier positions unusable in this particular version.
 */

bool linearDequeue(LinearQueue *queue, int *value)
{
    if (queue->front > queue->rear) {
        return false;
    }
    *value = queue->items[queue->front];
    queue->front++;
    return true;
}

/* Create several linked queues
 * An array of List containers gives each queue its own head and tail. The nodes remain dynamically allocated, so queues do not compete for fixed partitions in one value array.
 */

/* A named size limit; change it here rather than in every array. */
#define QUEUES 3
typedef struct {
    List queues[QUEUES];
} QueueGroup;
void initGroup(QueueGroup *group)
{
    for (int i = 0; i < QUEUES; i++) {
        group->queues[i].head = NULL;
        group->queues[i].tail = NULL;
    }
}

/* Enqueue into a selected linked queue
 * Check its number, then reuse append. There is no embedded link code in this wrapper.
 */

bool groupEnqueue(QueueGroup *group, int which, int value)
{
    if (which < 0 || which >= QUEUES) {
        return false;
    }
    append(&group->queues[which], value);
    return true;
}

/* Dequeue from a selected linked queue
 * The same removeFront function enforces FIFO after rear insertion.
 */

bool groupDequeue(QueueGroup *group, int which, int *value)
{
    if (which < 0 || which >= QUEUES) {
        return false;
    }
    return removeFront(&group->queues[which], value);
}

/* Peek without deletion
 * Borrow the first value. Empty and invalid queue numbers both report failure in this small interface.
 */

bool groupPeek(const QueueGroup *group, int which, int *value)
{
    if (which < 0 || which >= QUEUES) {
        return false;
    }
    const Node *first = group->queues[which].head;
    if (first == NULL) {
        return false;
    }
    *value = first->value;
    return true;
}

/* Input restricted insertion has one allowed end
 * The interface exposes only rear insertion. It reuses the circular deque state and its initialization function.
 */

bool inputRestrictedInsert(IntQueue *deque, int value)
{
    return enqueue(deque, value);
}

/* Input restricted deletion may choose either end
 * The flag chooses the leaving end. There is deliberately no front-insertion wrapper.
 */

bool inputRestrictedDelete(IntQueue *deque, bool fromFront, int *value)
{
    if (fromFront) {
        return dequeue(deque, value);
    }
    return popRear(deque, value);
}

/* Output restricted insertion may choose either end
 * Choose pushFront or enqueue. Their internal circular-index logic stays in int_queue.h.
 */

bool outputRestrictedInsert(IntQueue *deque, bool atFront, int value)
{
    if (atFront) {
        return pushFront(deque, value);
    }
    return enqueue(deque, value);
}

/* Output restricted deletion has one allowed end
 * Only front deletion is exposed. In C these wrappers express the intended interface; code that directly accesses the underlying deque can bypass it.
 */

bool outputRestrictedDelete(IntQueue *deque, int *value)
{
    return dequeue(deque, value);
}

/* Main logic
 * Fill a linear queue, delete one, and observe that it still rejects a new insertion. Then demonstrate independent linked queues and both restricted deque policies.
 */

int main(void)
{
    LinearQueue linear;
    initLinear(&linear);
    for (int i = 0; i < CAPACITY; i++) {
        bool ok = linearEnqueue(&linear, i);
        if (ok == false) {
            return 1;
        }
    }
    int value;
    linearDequeue(&linear, &value);
    bool ok = linearEnqueue(&linear, 999);
    printf("Linear queue reused a slot: %d\n", ok);
    QueueGroup group;
    initGroup(&group);
    for (int i = 0; i < QUEUES; i++) {
        ok = groupEnqueue(&group, i, 10 + i);
        if (ok == false) {
            return 1;
        }
        ok = groupPeek(&group, i, &value);
        if (ok) {
            printf("Queue %d front: %d\n", i, value);
        }
        groupDequeue(&group, i, &value);
    }
    IntQueue inputRestricted;
    initQueue(&inputRestricted);
    ok = inputRestrictedInsert(&inputRestricted, 10);
    if (ok == false) {
        return 1;
    }
    inputRestrictedDelete(&inputRestricted, false, &value);
    printf("Input restricted rear deletion: %d\n", value);
    IntQueue outputRestricted;
    initQueue(&outputRestricted);
    ok = outputRestrictedInsert(&outputRestricted, true, 20);
    if (ok == false) {
        return 1;
    }
    outputRestrictedDelete(&outputRestricted, &value);
    printf("Output restricted front deletion: %d\n", value);
    return 0;
}
