/* A tree pointer stack for iterative traversals
 * This is the linked stack rule with a Tree pointer as its stored value. The stack owns its cells and borrows tree nodes. Traversals call these functions rather than embedding push and pop logic.
 */

/* Define and push one cell
 * The stack top is the head. Each push adds one cell in O(1). Initialize a TreeStack with {NULL}.
 */

/* Header guard: include these declarations only once in this C file. */
#ifndef COURSE_TREE_STACK_H
/* Remember that this header has already been included. */
#define COURSE_TREE_STACK_H
/* Reuse the linked binary tree type and tree operations. */
#include "tree.h"
typedef struct TreeStackCell {
    const Tree *value;
    struct TreeStackCell *next;
} TreeStackCell;
typedef struct {
    TreeStackCell *top;
} TreeStack;
static inline void pushTree(TreeStack *stack, const Tree *value)
{
    TreeStackCell *cell = allocate(sizeof *cell);
    cell->value = value;
    cell->next = stack->top;
    stack->top = cell;
}

/* Pop releases a cell
 * The tree node remains owned by its tree. Empty pop leaves the output unchanged.
 */

static inline bool popTree(TreeStack *stack, const Tree **value)
{
    if (stack->top == NULL) {
        return false;
    }
    TreeStackCell *old = stack->top;
    *value = old->value;
    stack->top = old->next;
    free(old);
    return true;
}

/* Peek keeps the cell
 * Iterative postorder needs to inspect an unfinished ancestor without removing it yet.
 */

static inline bool peekTree(const TreeStack *stack, const Tree **value)
{
    if (stack->top == NULL) {
        return false;
    }
    *value = stack->top->value;
    return true;
}
#endif /* End of this header guard. */
