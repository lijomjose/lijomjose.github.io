/* Make the rules visible before converting
 * The conversion demo accepts single-letter or single-digit operands and binary + - * / ^, with parentheses and optional spaces. There is no unary minus or implicit multiplication. The numeric evaluators are separate: they accept whitespace-separated finite numbers, including decimals and signed numbers. ^ means exponentiation here, not the C XOR operator.
 */

/* Name the operators and their precedence
 * Return zero for a nonoperator. Exponentiation has the highest precedence and is right associative. The helpers keep these rules out of the conversion loop.
 */

/* Header guard: include these declarations only once in this C file. */
#ifndef COURSE_EXPRESSIONS_H
/* Remember that this header has already been included. */
#define COURSE_EXPRESSIONS_H
/* Reuse the earlier array stack type and its operations. */
#include "int_stack.h"
#include <errno.h>
int precedence(int symbol)
{
    if (symbol == '+' || symbol == '-') {
        return 1;
    }
    if (symbol == '*' || symbol == '/') {
        return 2;
    }
    if (symbol == '^') {
        return 3;
    }
    return 0;
}

/* Append a symbol without overflowing the output
 * length is the number of actual characters, excluding the terminator. Leave room for the terminating null after every append. A failed conversion leaves partial output that the caller must discard.
 */

bool appendSymbol(char output[], size_t capacity,
                  size_t *length, char symbol)
{
    if (*length + 1 >= capacity) {
        return false;
    }
    output[*length] = symbol;
    (*length)++;
    output[*length] = '\0';
    return true;
}

/* Decide whether the waiting operator can leave
 * A higher-precedence top operator is ready before the incoming operator. At equal precedence, pop for left-associative incoming operators, but not for ^. This is why a^b^c becomes abc^^.
 */

bool shouldPop(int top, int incoming)
{
    if (top == '(') {
        return false;
    }
    int waiting = precedence(top);
    int arriving = precedence(incoming);
    if (waiting > arriving) {
        return true;
    }
    return waiting == arriving && incoming != '^';
}

/* Convert infix to postfix using the stack interface
 * expectOperand is a simple grammar check: an operand or ( must appear when true; an operator or ) is allowed when false. Operands go directly to output. Operators wait on the stack. A closing parenthesis empties only its matching opening region. All stack calls remain separate from their checks.
 */

bool infixToPostfix(const char input[], char output[], size_t capacity)
{
    if (capacity == 0) {
        return false;
    }
    output[0] = '\0';
    size_t length = 0;
    IntStack operators;
    initStack(&operators);
    bool expectOperand = true;
    for (size_t i = 0; input[i] != '\0'; i++) {
        unsigned char symbol = (unsigned char)input[i];
        if (isspace(symbol)) {
            continue;
        }
        if (isalnum(symbol)) {
            if (expectOperand == false) {
                return false;
            }
            bool ok = appendSymbol(output, capacity, &length, (char)symbol);
            if (ok == false) {
                return false;
            }
            expectOperand = false;
        } else if (symbol == '(') {
            if (expectOperand == false) {
                return false;
            }
            bool ok = push(&operators, symbol);
            if (ok == false) {
                return false;
            }
        } else if (symbol == ')') {
            if (expectOperand) {
                return false;
            }
            bool matched = false;
            while (operators.top != -1) {
                int waiting;
                pop(&operators, &waiting);
                if (waiting == '(') {
                    matched = true;
                    break;
                }
                bool ok = appendSymbol(output, capacity, &length,
                                       (char)waiting);
                if (ok == false) {
                    return false;
                }
            }
            if (matched == false) {
                return false;
            }
        } else if (precedence(symbol) != 0) {
            if (expectOperand) {
                return false;
            }
            while (operators.top != -1) {
                int waiting;
                peek(&operators, &waiting);
                bool ready = shouldPop(waiting, symbol);
                if (ready == false) {
                    break;
                }
                pop(&operators, &waiting);
                bool ok = appendSymbol(output, capacity, &length,
                                       (char)waiting);
                if (ok == false) {
                    return false;
                }
            }
            bool ok = push(&operators, symbol);
            if (ok == false) {
                return false;
            }
            expectOperand = true;
        } else {
            return false;
        }
    }
    if (expectOperand) {
        return false;
    }
    while (operators.top != -1) {
        int waiting;
        pop(&operators, &waiting);
        if (waiting == '(') {
            return false;
        }
        bool ok = appendSymbol(output, capacity, &length, (char)waiting);
        if (ok == false) {
            return false;
        }
    }
    return true;
}

/* Represent an expression tree with a bounded node pool
 * An operand is a leaf. An operator has left and right child indices. Pool indices let us reuse IntStack without changing it into a pointer stack. -1 means no child. The pool owns its nodes as part of the Expression object, so no per-node free is needed.
 */

typedef struct {
    char symbol;
    int left;
    int right;
} ExpressionNode;
typedef struct {
    ExpressionNode nodes[CAPACITY];
    int count;
    int root;
} Expression;

/* Build a tree from postfix
 * Read left to right. Push an operand's node index. For an operator, pop the right subtree first, then the left. Join them under the new operator and push the result index. End with exactly one tree. Precondition: no whitespace in this single-character postfix string.
 */

bool treeFromPostfix(const char postfix[], Expression *tree)
{
    tree->count = 0;
    tree->root = -1;
    IntStack roots;
    initStack(&roots);
    for (size_t i = 0; postfix[i] != '\0'; i++) {
        if (tree->count == CAPACITY) {
            return false;
        }
        char symbol = postfix[i];
        ExpressionNode node = {symbol, -1, -1};
        if (precedence(symbol) != 0) {
            bool rightFound = pop(&roots, &node.right);
            bool leftFound = pop(&roots, &node.left);
            if (rightFound == false || leftFound == false) {
                return false;
            }
        } else if (isalnum((unsigned char)symbol) == 0) {
            return false;
        }
        int index = tree->count;
        tree->nodes[index] = node;
        tree->count++;
        bool ok = push(&roots, index);
        if (ok == false) {
            return false;
        }
    }
    if (roots.top != 0) {
        return false;
    }
    pop(&roots, &tree->root);
    return true;
}

/* Prefix is preorder
 * Visit the operator before its two subexpressions. This prints an infix-to-prefix conversion after the stack-based infix-to-postfix and tree construction steps.
 */

void printPrefix(const Expression *tree, int index)
{
    if (index == -1) {
        return;
    }
    ExpressionNode node = tree->nodes[index];
    putchar(node.symbol);
    printPrefix(tree, node.left);
    printPrefix(tree, node.right);
}

/* Postfix is postorder
 * Print both operands before the operator. Using the tree avoids a second set of precedence rules.
 */

void printPostfix(const Expression *tree, int index)
{
    if (index == -1) {
        return;
    }
    ExpressionNode node = tree->nodes[index];
    printPostfix(tree, node.left);
    printPostfix(tree, node.right);
    putchar(node.symbol);
}

/* Fully parenthesized infix is inorder with boundaries
 * A plain inorder sequence could lose grouping. Wrap each binary operator subtree in parentheses. A leaf needs no parentheses.
 */

void printInfix(const Expression *tree, int index)
{
    ExpressionNode node = tree->nodes[index];
    if (node.left == -1) {
        putchar(node.symbol);
        return;
    }
    putchar('(');
    printInfix(tree, node.left);
    putchar(node.symbol);
    printInfix(tree, node.right);
    putchar(')');
}

/* Prefix can build the same tree from the other direction
 * Scan right to left. A prefix operator now pops left first, then right. The rest is the same pool and stack model. This gives prefix-to-infix and prefix-to-postfix through the existing traversals.
 */

bool treeFromPrefix(const char prefix[], Expression *tree)
{
    tree->count = 0;
    tree->root = -1;
    IntStack roots;
    initStack(&roots);
    size_t length = strlen(prefix);
    while (length > 0) {
        length--;
        if (tree->count == CAPACITY) {
            return false;
        }
        char symbol = prefix[length];
        ExpressionNode node = {symbol, -1, -1};
        if (precedence(symbol) != 0) {
            bool leftFound = pop(&roots, &node.left);
            bool rightFound = pop(&roots, &node.right);
            if (leftFound == false || rightFound == false) {
                return false;
            }
        } else if (isalnum((unsigned char)symbol) == 0) {
            return false;
        }
        int index = tree->count;
        tree->nodes[index] = node;
        tree->count++;
        bool ok = push(&roots, index);
        if (ok == false) {
            return false;
        }
    }
    if (roots.top != 0) {
        return false;
    }
    pop(&roots, &tree->root);
    return true;
}

/* A numeric stack needs numeric storage
 * The interface is the same as IntStack, but the payload is double. Keep push/pop separate from evaluation. We show this type change explicitly rather than pretend an int stack can hold floating-point values.
 */

typedef struct {
    double items[CAPACITY];
    int count;
} NumberStack;
bool pushNumber(NumberStack *stack, double value)
{
    if (stack->count == CAPACITY) {
        return false;
    }
    stack->items[stack->count] = value;
    stack->count++;
    return true;
}

/* Pop a number
 * Do not use a numeric sentinel for failure. Every finite number, including -1, is legitimate expression data.
 */

bool popNumber(NumberStack *stack, double *value)
{
    if (stack->count == 0) {
        return false;
    }
    stack->count--;
    *value = stack->items[stack->count];
    return true;
}

/* Apply one binary operator
 * Operand order matters for subtraction, division, and exponentiation. Reject division by zero and results that are not finite. pow implements the expression language's ^ operator; C's own ^ does not.
 */

bool applyOperator(char symbol, double left, double right, double *answer)
{
    double result;
    if (symbol == '+') {
        result = left + right;
    } else if (symbol == '-') {
        result = left - right;
    } else if (symbol == '*') {
        result = left * right;
    } else if (symbol == '/') {
        if (right == 0.0) {
            return false;
        }
        result = left / right;
    } else if (symbol == '^') {
        result = pow(left, right);
    } else {
        return false;
    }
    if (isfinite(result) == 0) {
        return false;
    }
    *answer = result;
    return true;
}

/* Tokenize before evaluating
 * Copy tokens into a fixed table so prefix can read them backward. Reject a token that would not fit rather than truncate it. Whitespace is mandatory between separate numeric operands and operators.
 */

bool splitTokens(const char text[], char tokens[][32], int *count)
{
    *count = 0;
    size_t i = 0;
    while (text[i] != '\0') {
        if (isspace((unsigned char)text[i])) {
            i++;
            continue;
        }
        if (*count == CAPACITY) {
            return false;
        }
        int length = 0;
        while (text[i] != '\0' && isspace((unsigned char)text[i]) == 0) {
            if (length == 31) {
                return false;
            }
            tokens[*count][length] = text[i];
            length++;
            i++;
        }
        tokens[*count][length] = '\0';
        (*count)++;
    }
    return *count > 0;
}

/* One evaluator two reading directions
 * For postfix, scan left to right and pop right then left. For prefix, scan right to left and pop left then right. A one-character operator token is processed as an operator; otherwise strtod must consume the complete token. Exactly one value must remain. The output is unchanged on failure.
 */

bool evaluate(const char text[], bool prefix, double *answer)
{
    char tokens[CAPACITY][32];
    int count;
    bool valid = splitTokens(text, tokens, &count);
    if (valid == false) {
        return false;
    }
    NumberStack stack = {{0}, 0};
    for (int step = 0; step < count; step++) {
        int index = step;
        if (prefix) {
            index = count - 1 - step;
        }
        char *token = tokens[index];
        bool isOperator = token[1] == '\0' && precedence(token[0]) != 0;
        double value;
        if (isOperator) {
            double first;
            double second;
            bool gotFirst = popNumber(&stack, &first);
            bool gotSecond = popNumber(&stack, &second);
            if (gotFirst == false || gotSecond == false) {
                return false;
            }
            double left = second;
            double right = first;
            if (prefix) {
                left = first;
                right = second;
            }
            valid = applyOperator(token[0], left, right, &value);
            if (valid == false) {
                return false;
            }
        } else {
            char *end;
            errno = 0;
            value = strtod(token, &end);
            if (end == token || *end != '\0' || errno == ERANGE) {
                return false;
            }
            if (isfinite(value) == 0) {
                return false;
            }
        }
        valid = pushNumber(&stack, value);
        if (valid == false) {
            return false;
        }
    }
    if (stack.count != 1) {
        return false;
    }
    return popNumber(&stack, answer);
}
#endif /* End of this header guard. */
