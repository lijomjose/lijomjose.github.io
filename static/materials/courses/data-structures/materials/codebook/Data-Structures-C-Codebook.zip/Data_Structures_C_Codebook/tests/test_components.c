#include <assert.h>
#define main demo_main
#include "34_graph_connectivity.c"
#undef main

int main(void){
 Graph g;assert(initGraph(&g,7));assert(addUndirected(&g,0,1));assert(addUndirected(&g,1,2));assert(addUndirected(&g,2,0));assert(addUndirected(&g,3,4));
 int labels[CAPACITY],parents[CAPACITY],dist[CAPACITY];int c=graphComponents(&g,labels,parents,dist);assert(c==4);int edges=0;
 for(int i=0;i<7;i++){if(parents[i]!=-1){assert(g.matrix[i][parents[i]]);assert(dist[i]==dist[parents[i]]+1);edges++;}}
 assert(edges==7-c);
 bool m[CAPACITY][CAPACITY];listsToMatrix(&g,m);for(int i=0;i<7;i++)for(int j=0;j<7;j++)assert(m[i][j]==g.matrix[i][j]);destroyGraph(&g);return 0;
}
