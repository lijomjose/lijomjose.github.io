/* Keep the powers that actually exist
 * A term stores coefficient and exponent. We use a circular doubly linked list with a header. Real terms are kept in descending exponent order; equal powers are combined and zero coefficients are removed. Arithmetic examples are small: coefficients and exponent sums must fit int, and exponents are nonnegative.
 */

/* Create an empty polynomial
 * The header is not a constant term. Its coefficient and exponent are ignored. Its links represent an empty ring.
 */

/* Header guard: include these declarations only once in this C file. */
#ifndef COURSE_POLYNOMIAL_H
/* Remember that this header has already been included. */
#define COURSE_POLYNOMIAL_H
/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct PolyTerm {
    int coefficient;
    int exponent;
    struct PolyTerm *previous;
    struct PolyTerm *next;
} PolyTerm;
PolyTerm *newPolynomial(void)
{
    PolyTerm *header = allocate(sizeof *header);
    header->coefficient = 0;
    header->exponent = 0;
    header->next = header;
    header->previous = header;
    return header;
}

/* Link one new term before a known position
 * This is the same four-link idea from the DLL chapter, now with a term payload. The new term is initialized before its neighbors are changed.
 */

void linkTermBefore(PolyTerm *position, int coefficient, int exponent)
{
    PolyTerm *node = allocate(sizeof *node);
    node->coefficient = coefficient;
    node->exponent = exponent;
    node->previous = position->previous;
    node->next = position;
    position->previous->next = node;
    position->previous = node;
}

/* Remove a canceled term
 * Precondition: a real linked term. Repair both directions, then free it. The header must never be passed here.
 */

void unlinkTerm(PolyTerm *term)
{
    term->previous->next = term->next;
    term->next->previous = term->previous;
    free(term);
}

/* Insert a term or combine an existing power
 * Skip zero coefficients. Find the first power no larger than the incoming exponent. Either combine equal powers or insert before that position. Cancellation removes the term entirely.
 */

void addTerm(PolyTerm *header, int coefficient, int exponent)
{
    if (coefficient == 0) {
        return;
    }
    PolyTerm *current = header->next;
    while (current != header && current->exponent > exponent) {
        current = current->next;
    }
    if (current != header && current->exponent == exponent) {
        current->coefficient = current->coefficient + coefficient;
        if (current->coefficient == 0) {
            unlinkTerm(current);
        }
    } else {
        linkTermBefore(current, coefficient, exponent);
    }
}

/* Addition is a merge of two ordered streams
 * Walk two descending term streams. endA and endB mark their ends: NULL for linear lists, or their header for rings. Copy the higher power, or combine equal powers. Append directly to the result header. This one merge serves both DLL representations.
 */

PolyTerm *mergePolynomialStreams(const PolyTerm *a, const PolyTerm *endA,
                                 const PolyTerm *b, const PolyTerm *endB)
{
    PolyTerm *result = newPolynomial();
    while (a != endA || b != endB) {
        int coefficient;
        int exponent;
        if (b == endB || (a != endA && a->exponent > b->exponent)) {
            coefficient = a->coefficient;
            exponent = a->exponent;
            a = a->next;
        } else if (a == endA || b->exponent > a->exponent) {
            coefficient = b->coefficient;
            exponent = b->exponent;
            b = b->next;
        } else {
            coefficient = a->coefficient + b->coefficient;
            exponent = a->exponent;
            a = a->next;
            b = b->next;
        }
        if (coefficient != 0) {
            linkTermBefore(result, coefficient, exponent);
        }
    }
    return result;
}

/* Add two header rings using the shared merge
 * Skip each header and pass it as the ending marker. The result is a new header ring. Inputs remain unchanged.
 */

PolyTerm *addPolynomials(const PolyTerm *first, const PolyTerm *second)
{
    return mergePolynomialStreams(first->next, first,
                                  second->next, second);
}

/* Multiplication makes every pair meet
 * Multiply each pair of terms, then reuse addTerm to combine powers. Explicit end markers let this loop work with linear streams or header rings. This simple method pays for a result-list search for every pair.
 */

PolyTerm *multiplyPolynomialStreams(const PolyTerm *first, const PolyTerm *endA,
                                    const PolyTerm *second, const PolyTerm *endB)
{
    PolyTerm *result = newPolynomial();
    for (const PolyTerm *a = first; a != endA; a = a->next) {
        for (const PolyTerm *b = second; b != endB; b = b->next) {
            int coefficient = a->coefficient * b->coefficient;
            int exponent = a->exponent + b->exponent;
            addTerm(result, coefficient, exponent);
        }
    }
    return result;
}

/* Multiply two header rings with the shared stream routine
 * Skip the headers and pass them as ending markers. The returned polynomial owns a fresh header ring.
 */

PolyTerm *multiplyPolynomials(const PolyTerm *first, const PolyTerm *second)
{
    return multiplyPolynomialStreams(first->next, first,
                                      second->next, second);
}

/* Display without hiding negative terms
 * Print each coefficient with a sign and an explicit power. An empty ring represents the zero polynomial.
 */

void printPolynomial(const PolyTerm *header)
{
    if (header->next == header) {
        puts("0");
        return;
    }
    for (const PolyTerm *p = header->next; p != header; p = p->next) {
        printf("%+d*x^%d ", p->coefficient, p->exponent);
    }
    putchar('\n');
}

/* Destroy the owned ring
 * Remove every real term using the shared unlink operation, then release the header.
 */

void destroyPolynomial(PolyTerm *header)
{
    while (header->next != header) {
        unlinkTerm(header->next);
    }
    free(header);
}
#endif /* End of this header guard. */
