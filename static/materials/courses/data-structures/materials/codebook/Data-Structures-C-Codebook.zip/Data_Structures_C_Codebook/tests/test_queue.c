#include <assert.h>
#include "int_queue.h"
#include "int_stack.h"

int main(void)
{
    IntQueue q; initQueue(&q); int value=999;
    assert(dequeue(&q,&value)==false && value==999);
    for(int round=0;round<100;round++) {
        for(int i=0;i<CAPACITY;i++) assert(enqueue(&q,i));
        assert(enqueue(&q,88)==false);
        for(int i=0;i<CAPACITY;i++) {
            assert(dequeue(&q,&value)); assert(value==i);
        }
    }
    for(int i=0;i<CAPACITY;i++) assert(pushFront(&q,i));
    for(int i=0;i<CAPACITY;i++) {
        assert(popRear(&q,&value)); assert(value==i);
    }
    IntStack s; initStack(&s);
    for(int i=0;i<CAPACITY;i++) assert(push(&s,i));
    assert(push(&s,0)==false);
    for(int i=CAPACITY-1;i>=0;i--) {
        assert(pop(&s,&value)); assert(value==i);
    }
    assert(pop(&s,&value)==false);
    return 0;
}
