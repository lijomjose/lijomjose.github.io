/* Recursive creation search and iterative traversals
 * These variants appear in the Trees PPT. The iterative traversals use tree_stack.h. Tree creation uses explicit missing-node tokens so -1 remains available as an ordinary value.
 */

/* Build from preorder tokens with missing child markers
 * Consume one token per subtree. A missing token means NULL. Otherwise create a root, then its left and right subtrees. On malformed input, release the partial result. The caller starts position=0 and valid=true.
 */

/* Reuse the stack of tree pointers; its push and pop are already covered. */
#include "tree_stack.h"
/* Reuse the expression conversion and evaluation helpers. */
#include "expressions.h"
typedef struct {
    bool present;
    int value;
} TreeToken;
Tree *buildFromTokens(const TreeToken tokens[], int count,
                     int *position, bool *valid)
{
    if (*position >= count) {
        *valid = false;
        return NULL;
    }
    TreeToken token = tokens[*position];
    (*position)++;
    if (token.present == false) {
        return NULL;
    }
    Tree *root = newTreeNode(token.value);
    root->left = buildFromTokens(tokens, count, position, valid);
    if (*valid == false) {
        destroyTree(root);
        return NULL;
    }
    root->right = buildFromTokens(tokens, count, position, valid);
    if (*valid == false) {
        destroyTree(root);
        return NULL;
    }
    return root;
}

/* Search an arbitrary binary tree with fresh local state
 * Check root, then left, then right. A result from one call must not linger in a static flag and affect a later search.
 */

const Tree *binaryTreeSearch(const Tree *root, int key)
{
    if (root == NULL) {
        return NULL;
    }
    if (root->value == key) {
        return root;
    }
    const Tree *found = binaryTreeSearch(root->left, key);
    if (found != NULL) {
        return found;
    }
    return binaryTreeSearch(root->right, key);
}

/* Recursive BST search follows just one child
 * Use this only when BST ordering holds. General binaryTreeSearch may need both subtrees.
 */

const Tree *recursiveBstSearch(const Tree *root, int key)
{
    if (root == NULL || root->value == key) {
        return root;
    }
    if (key < root->value) {
        return recursiveBstSearch(root->left, key);
    }
    return recursiveBstSearch(root->right, key);
}

/* Iterative preorder pushes right before left
 * LIFO reverses insertion order. Push right first so left is the next node popped. Visit the node as soon as it leaves the stack.
 */

void iterativePreorder(const Tree *root)
{
    TreeStack stack = {NULL};
    if (root != NULL) {
        pushTree(&stack, root);
    }
    while (stack.top != NULL) {
        const Tree *current;
        popTree(&stack, &current);
        printf("%d ", current->value);
        if (current->right != NULL) {
            pushTree(&stack, current->right);
        }
        if (current->left != NULL) {
            pushTree(&stack, current->left);
        }
    }
    putchar('\n');
}

/* Iterative inorder saves unfinished ancestors
 * Walk left while saving each ancestor. When no left node remains, pop and visit the waiting ancestor, then enter its right subtree.
 */

void iterativeInorder(const Tree *root)
{
    TreeStack stack = {NULL};
    const Tree *current = root;
    while (current != NULL || stack.top != NULL) {
        while (current != NULL) {
            pushTree(&stack, current);
            current = current->left;
        }
        popTree(&stack, &current);
        printf("%d ", current->value);
        current = current->right;
    }
    putchar('\n');
}

/* Iterative postorder waits until both children finish
 * lastVisited remembers the subtree just completed. At a waiting ancestor, enter its right subtree if it still needs work. Otherwise pop and visit that ancestor. This uses one stack.
 */

void iterativePostorder(const Tree *root)
{
    TreeStack stack = {NULL};
    const Tree *current = root;
    const Tree *lastVisited = NULL;
    while (current != NULL || stack.top != NULL) {
        if (current != NULL) {
            pushTree(&stack, current);
            current = current->left;
        } else {
            const Tree *waiting;
            peekTree(&stack, &waiting);
            if (waiting->right != NULL && lastVisited != waiting->right) {
                current = waiting->right;
            } else {
                popTree(&stack, &waiting);
                printf("%d ", waiting->value);
                lastVisited = waiting;
            }
        }
    }
    putchar('\n');
}

/* Evaluate an expression tree in postorder
 * This small tree evaluator accepts single-digit leaves only. Evaluate left and right first, then reuse applyOperator. For multi-digit numeric input, use the separate token evaluators already provided.
 */

bool evaluateExpressionTree(const Expression *tree, int index, double *answer)
{
    ExpressionNode node = tree->nodes[index];
    if (node.left == -1) {
        if (isdigit((unsigned char)node.symbol) == 0) {
            return false;
        }
        *answer = node.symbol - '0';
        return true;
    }
    double left;
    double right;
    bool leftOK = evaluateExpressionTree(tree, node.left, &left);
    bool rightOK = evaluateExpressionTree(tree, node.right, &right);
    if (leftOK == false || rightOK == false) {
        return false;
    }
    return applyOperator(node.symbol, left, right, answer);
}

/* Main logic
 * Build root 10 with left 30 and right 20 from seven tokens. Both children are leaves. Confirm that two different searches work, run all iterative traversals, then evaluate (5-3)*4+9 as a tree.
 */

int main(void)
{
    TreeToken tokens[] = {{true,10}, {true,30}, {false,0}, {false,0},
                          {true,20}, {false,0}, {false,0}};
    int position = 0;
    bool valid = true;
    Tree *root = buildFromTokens(tokens, 7, &position, &valid);
    if (valid == false || position != 7) {
        destroyTree(root);
        return 1;
    }
    const Tree *first = binaryTreeSearch(root, 30);
    const Tree *second = binaryTreeSearch(root, 20);
    printf("Both searches found: %d %d\n", first != NULL, second != NULL);
    iterativePreorder(root);
    iterativeInorder(root);
    iterativePostorder(root);
    destroyTree(root);
    Tree *bst = NULL;
    bst = bstInsert(bst, 10);
    bst = bstInsert(bst, 20);
    const Tree *found = recursiveBstSearch(bst, 20);
    printf("Recursive BST found: %d\n", found != NULL);
    destroyTree(bst);
    char postfix[CAPACITY];
    bool ok = infixToPostfix("(5-3)*4+9", postfix, sizeof postfix);
    if (ok == false) {
        return 1;
    }
    Expression expression;
    ok = treeFromPostfix(postfix, &expression);
    if (ok == false) {
        return 1;
    }
    double answer;
    ok = evaluateExpressionTree(&expression, expression.root, &answer);
    if (ok) {
        printf("Tree value: %.0f\n", answer);
    }
    return 0;
}
