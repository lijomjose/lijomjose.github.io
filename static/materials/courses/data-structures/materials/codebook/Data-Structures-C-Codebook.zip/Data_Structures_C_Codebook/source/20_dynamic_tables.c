/* Dynamic table main
 * Reuse dynamic_rows.h. The complete main below shows the operation sequence.
 */

/* Main logic
 * Use unequal lengths for a ragged table and equal lengths for a rectangle. Then show a pointer to an actual row array; its step size is one entire row.
 */

/* Reuse the dynamic row allocation and cleanup helpers. */
#include "dynamic_rows.h"
int main(void)
{
    int lengths[] = {2, 0, 4};
    int **ragged = createRows(3, lengths);
    if (ragged == NULL) {
        return 1;
    }
    ragged[0][1] = 7;
    ragged[2][3] = 9;
    printRows(ragged, 3, lengths);
    destroyRows(ragged, 3);
    int widths[] = {3, 3};
    int **rectangle = createRows(2, widths);
    if (rectangle == NULL) {
        return 1;
    }
    rectangle[1][2] = 42;
    printRows(rectangle, 2, widths);
    destroyRows(rectangle, 2);
    int fixed[2][3] = {{1, 2, 3}, {4, 5, 6}};
    int (*rowPointer)[3] = fixed;
    printf("Row pointer reaches: %d\n", *(*(rowPointer + 1) + 2));
    return 0;
}
