/* Header guard: include these declarations only once in this C file. */
#ifndef COURSE_COMMON_H
/* Remember that this header has already been included. */
#define COURSE_COMMON_H
#include <stdio.h> /* printf, putchar and input/output functions */
#include <stdlib.h> /* malloc, calloc, realloc, free and exit */
#include <stdbool.h> /* bool, true and false */
#include <string.h> /* string functions and memory helpers such as memset */
#include <math.h> /* math functions used by expression evaluation */
#include <ctype.h> /* character checks used by expression conversion */
#include <limits.h> /* integer limits used by range checks */
/* A named size limit; change it here rather than in every array. */
#define CAPACITY 128

/* This teaching policy stops the demo if storage cannot be obtained. */
/* static keeps this helper local to each C file that includes it.
 * inline allows inlining; it does not require it. A single-file program
 * can use an ordinary function instead. */
static inline void *allocate(size_t bytes)
{
    void *memory = malloc(bytes);
    if (memory == NULL) {
        fprintf(stderr, "Allocation failed\n");
        exit(EXIT_FAILURE);
    }
    return memory;
}
#endif /* End of this header guard. */
