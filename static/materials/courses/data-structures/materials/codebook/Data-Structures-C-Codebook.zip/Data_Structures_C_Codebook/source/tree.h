/* Shared tree operations
 * We use pointer-linked nodes. An empty tree is NULL. A leaf has two NULL children. Height counts edges: an empty tree has height -1 and a leaf has height 0. Other books count nodes instead; neither convention is useful unless we state it.
 */

/* Create one node
 * The constructor initializes both child links. Tree algorithms can now assume a new node starts as a valid leaf.
 */

/* Header guard: include these declarations only once in this C file. */
#ifndef COURSE_TREE_H
/* Remember that this header has already been included. */
#define COURSE_TREE_H
/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct Tree {
    int value;
    struct Tree *left;
    struct Tree *right;
} Tree;
static inline Tree *newTreeNode(int value)
{
    Tree *node = allocate(sizeof *node);
    node->value = value;
    node->left = NULL;
    node->right = NULL;
    return node;
}

/* Preorder visits the root first
 * An empty subtree contributes no visit. Print the root, then recursively process the complete left subtree and the complete right subtree.
 */

static inline void preorder(const Tree *root)
{
    if (root == NULL) {
        return;
    }
    printf("%d ", root->value);
    preorder(root->left);
    preorder(root->right);
}

/* Inorder visits the root between its subtrees
 * This order is sorted only for a BST. It is still a valid traversal of an arbitrary binary tree, but no sortedness follows.
 */

static inline void inorder(const Tree *root)
{
    if (root == NULL) {
        return;
    }
    inorder(root->left);
    printf("%d ", root->value);
    inorder(root->right);
}

/* Postorder visits the root last
 * Both child subtrees finish before the root is visited. This is the same dependency order needed to free children before their parent.
 */

static inline void postorder(const Tree *root)
{
    if (root == NULL) {
        return;
    }
    postorder(root->left);
    postorder(root->right);
    printf("%d ", root->value);
}

/* Count all nodes
 * Each nonempty subtree contributes its own root plus the counts from its two children. There is no need for a global counter.
 */

static inline int nodeCount(const Tree *root)
{
    if (root == NULL) {
        return 0;
    }
    int left = nodeCount(root->left);
    int right = nodeCount(root->right);
    return 1 + left + right;
}

/* Count leaves
 * A leaf contributes one. A nonleaf contributes the leaves from its children. Test for two missing children, not merely one.
 */

static inline int leafCount(const Tree *root)
{
    if (root == NULL) {
        return 0;
    }
    if (root->left == NULL && root->right == NULL) {
        return 1;
    }
    return leafCount(root->left) + leafCount(root->right);
}

/* Height follows the longer route
 * Compute both subtree heights, choose the larger, then add the edge to that child. The empty result -1 makes a leaf's height 0.
 */

static inline int treeHeight(const Tree *root)
{
    if (root == NULL) {
        return -1;
    }
    int left = treeHeight(root->left);
    int right = treeHeight(root->right);
    int largest = left;
    if (right > largest) {
        largest = right;
    }
    return largest + 1;
}

/* Copy values and structure into new nodes
 * Copying only the root pointer creates an alias, not a second tree. This recursive copy allocates a distinct node for every original node.
 */

static inline Tree *copyTree(const Tree *root)
{
    if (root == NULL) {
        return NULL;
    }
    Tree *copy = newTreeNode(root->value);
    copy->left = copyTree(root->left);
    copy->right = copyTree(root->right);
    return copy;
}

/* Equality checks structure as well as values
 * If one root is NULL, both must be NULL. Otherwise compare the payload and the matching child subtrees. Equal inorder output alone does not prove equal structure.
 */

static inline bool equalTrees(const Tree *first, const Tree *second)
{
    if (first == NULL || second == NULL) {
        return first == second;
    }
    if (first->value != second->value) {
        return false;
    }
    bool sameLeft = equalTrees(first->left, second->left);
    bool sameRight = equalTrees(first->right, second->right);
    return sameLeft && sameRight;
}

/* Mirror swaps the meaning of left and right
 * Swap the two child routes at each node, then mirror those subtrees. This changes an ordinary BST into a reverse-ordered tree, so ordinary BST search would no longer apply.
 */

static inline void mirrorTree(Tree *root)
{
    if (root == NULL) {
        return;
    }
    Tree *temporary = root->left;
    root->left = root->right;
    root->right = temporary;
    mirrorTree(root->left);
    mirrorTree(root->right);
}

/* Destroy children before their parent
 * After freeing a node, its child routes cannot safely be read. Postorder cleanup reads those routes while the parent still exists.
 */

static inline void destroyTree(Tree *root)
{
    if (root == NULL) {
        return;
    }
    destroyTree(root->left);
    destroyTree(root->right);
    free(root);
}

/* BST search chooses one route
 * At each node, equality succeeds; a smaller key goes left and a larger key goes right. Preconditions: the whole tree obeys strict BST ordering.
 */

static inline Tree *bstSearch(Tree *root, int key)
{
    while (root != NULL) {
        if (key == root->value) {
            return root;
        }
        if (key < root->value) {
            root = root->left;
        } else {
            root = root->right;
        }
    }
    return NULL;
}

/* BST insertion returns the new subtree root
 * At an empty route, create a leaf. Otherwise insert into the appropriate child and store the returned route. Duplicate keys are ignored in this implementation.
 */

static inline Tree *bstInsert(Tree *root, int key)
{
    if (root == NULL) {
        return newTreeNode(key);
    }
    if (key < root->value) {
        root->left = bstInsert(root->left, key);
    } else if (key > root->value) {
        root->right = bstInsert(root->right, key);
    }
    return root;
}

/* Minimum and maximum follow an extreme route
 * The minimum has no left child; the maximum has no right child. NULL input gives NULL. These helpers return borrowed nodes.
 */

static inline Tree *bstMinimum(Tree *root)
{
    if (root == NULL) {
        return NULL;
    }
    while (root->left != NULL) {
        root = root->left;
    }
    return root;
}

/* Maximum follows the right route
 * The symmetric operation is shown separately so the direction is easy to see.
 */

static inline Tree *bstMaximum(Tree *root)
{
    if (root == NULL) {
        return NULL;
    }
    while (root->right != NULL) {
        root = root->right;
    }
    return root;
}

/* BST deletion separates three structural cases
 * Search first. With zero or one child, return the remaining child route after freeing the target node. With two children, copy only the successor's value, then delete that successor from the right subtree. The successor has no left child, so that second deletion reduces to a simpler case.
 */

static inline Tree *bstDelete(Tree *root, int key)
{
    if (root == NULL) {
        return NULL;
    }
    if (key < root->value) {
        root->left = bstDelete(root->left, key);
    } else if (key > root->value) {
        root->right = bstDelete(root->right, key);
    } else {
        if (root->left == NULL || root->right == NULL) {
            Tree *replacement = root->left;
            if (replacement == NULL) {
                replacement = root->right;
            }
            free(root);
            return replacement;
        }
        Tree *successor = bstMinimum(root->right);
        root->value = successor->value;
        root->right = bstDelete(root->right, successor->value);
    }
    return root;
}
#endif /* End of this header guard. */
