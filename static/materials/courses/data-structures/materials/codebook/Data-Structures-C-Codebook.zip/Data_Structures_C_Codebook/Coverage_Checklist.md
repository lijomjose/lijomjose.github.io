# Official PPT and syllabus coverage checklist

The implementations are newly written C11. The PPTs supply the required topics and variants, not the source code.
Slide numbers below refer to the files inside Materials.zip. Duplicate slides and the two Module 1 versions are covered together. Basic C syntax is demonstrated within useful implementations rather than by repeating every introductory toy program.

The PPTs call linked lists Module 2 and stacks/queues Module 3. The supplied syllabus reverses those two module numbers. This checklist follows the official PPT filenames.

## Module 1 Introduction and Fundamentals

| Official slides | Required implementation or concept | Source files |
| --- | --- | --- |
| Modified 15-40, 86-104 | Types, branching, loops, functions, pass-by-value, array parameters | Throughout the examples; 01_memory.c, 19_arrays_recursion.c, 21_records.c |
| Modified 42-50 | Array ADT, 1D/2D arrays, matrix maximum | 19_arrays_recursion.c, 38_pointer_matrix_apps.c |
| Modified 51-62 | Linear/binary search and bubble/selection/insertion sort | array_algorithms.h, 03_search_sort.c |
| Modified 63-85 | Addresses, dereferencing, pointer arithmetic, arrays and row pointers | 01_memory.c, dynamic_rows.h, 20_dynamic_tables.c, 38_pointer_matrix_apps.c |
| Modified 105-108 | Factorial, recursive binary search, Hanoi | 02_recursion.c, 19_arrays_recursion.c |
| Modified 109-130 | malloc, calloc, realloc, free, double pointers, arrays of pointers, ragged and rectangular row-pointer tables | course_common.h, 01_memory.c, dynamic_rows.h, 20_dynamic_tables.c |
| Modified 132-142 | String length, concatenation, comparison, substring insertion/deletion | 04_strings.c; concatenation reuses insertion at the current length |
| Modified 143-176 | Structures, embedded arrays, nested structures, arrays of records, structure pointers, returned pointers, self-reference | 21_records.c, 36_recursive_records.c, list and tree node definitions |
| Modified 177-189; original 160-172 | Sparse array/list representation, simple transpose, fast transpose | 05_sparse.c, 22_sparse_linked.c |
| Tutorial 1-3 | Pointer counting/reversal, mark summaries, calloc attendance, row/column changes, recursive record sorting/search/counting | 36_recursive_records.c, 38_pointer_matrix_apps.c |
| Syllabus Module 1 | typedef and enum | 01_memory.c, 21_records.c, 27_duplicate_parentheses.c, 18_red_black.c |

## Module 2 Linked Lists

| Official slides | Required implementation or concept | Source files |
| --- | --- | --- |
| 9-28 | SLL creation, front/rear/position insertion/deletion, search, reverse, display | slist.h, 08_linked_apps.c, 23_more_sll.c |
| 29-30 | Concatenation, count, alternating split, cleanup | 23_more_sll.c, slist.h |
| 33-43 | Linear DLL front/rear/position insertion/deletion, search, both display directions, count, concatenate | 24_linear_dll.c |
| 48-56 | Circular SLL using first+last, first-only, last-only endpoints | circle.h, 10_circular_singly.c, 25_circle_variants.c |
| 63-71 | Singly linked polynomial representation, attach, addition, multiplication, erase, composed operations | 26_more_polynomials.c; sMerge/sMultiply and sAttach/sAddTerm |
| 72-75 | DLL polynomial addition | polynomial.h, 26_more_polynomials.c; addLinearDoubly |
| 76-79 | Header circular polynomial addition | 26_more_polynomials.c; sAddCircular; polynomial.h for circular DLL version |
| Syllabus and tutorial 4-6 | Linked stacks/queues, header lists, recursive chain creation/traversal, circular DLL positional operations, header circular DLL multiplication | 08_linked_apps.c, 09_doubly_circular.c, 37_recursive_lists.c, 11_polynomials.c |

## Module 3 Stacks and Queues

| Official slides | Required implementation or concept | Source files |
| --- | --- | --- |
| 4, 9-15 | Array/linked stack initialization, push, pop, peek, display | int_stack.h, slist.h, 08_linked_apps.c |
| 17-22 | Balanced parentheses | 06_stack_queue_apps.c |
| 23-28 | Duplicate parentheses with invalid-input distinction | 27_duplicate_parentheses.c |
| 29-61 | Infix/postfix/prefix conversion and postfix/prefix evaluation | expressions.h, 12_expressions.c |
| 62-69 | Two stacks, fixed multiple stacks, dynamic sharing/free-list stacks, display | 06_stack_queue_apps.c, 28_multiple_stacks.c |
| 78-81 | Sequential linear array queue | 29_queue_variants.c |
| 82-85 | Array of linked queues, enqueue/dequeue/peek | 29_queue_variants.c |
| 86-93 | Circular array queue | int_queue.h, 06_stack_queue_apps.c |
| 94-100 | Deque and input/output restricted interfaces | int_queue.h, 29_queue_variants.c |
| 102-110 | Sorted/unsorted priorities, min/max policies, peek, empty/full | priority.h, 07_priority_queue.c, 30_priority_variants.c |
| 111 | Heap and balanced-tree priority representations | 31_heap_priority.c, 39_tree_priority.c; the latter reuses avl.h and existing stack/queue functions |

## Module 4 Trees

| Official slides | Required implementation or concept | Source files |
| --- | --- | --- |
| 8-10, 21-29 | General child/sibling representation, binary array/linked representation, recursive creation | 40_array_binary_tree.c, 35_tree_representations.c, tree.h, 32_more_tree_operations.c |
| 31-44 | Recursive and iterative preorder/inorder/postorder | tree.h, tree_stack.h, 32_more_tree_operations.c |
| 46-62 | Level order | tree_queue.h, 13_trees.c |
| 63-69 | General search, copy, total/leaf counts, equality | tree.h, 32_more_tree_operations.c |
| 70-89 | Expression tree construction, traversals, evaluation | expressions.h, 32_more_tree_operations.c |
| 90-112 | Threads, header with two flags, inorder successor/traversal, right-child insertion preserving an old subtree | 33_fully_threaded.c; 15_threaded_tree.c also gives a simpler right-threaded version |
| 117-132 | BST creation/search/insertion/deletion/minimum/maximum; recursive and iterative search | tree.h, 13_trees.c, 32_more_tree_operations.c |
| 139-174 | AVL cached heights, LL/RR/LR/RL rotations, insertion and deletion | avl.h, 16_avl.c |
| 175-183 | Red-black invariants and insertion repair | 18_red_black.c |
| Tutorial 9-11 | Expression evaluation, ordering questions, thread display, balancing updates | 32_more_tree_operations.c, 33_fully_threaded.c, AVL and red-black examples and answered boxes |
| Additional references | Mirror, general binary-tree deletion policy, full red-black deletion | tree.h, 14_binary_delete.c, 18_red_black.c |

## Module 5 Graphs

| Official slides | Required implementation or concept | Source files |
| --- | --- | --- |
| 14-16, 18-25 | Degree, directed/undirected matrix and adjacency lists, edge insertion | 41_array_graph.c, graph.h, 17_graphs.c, 34_graph_connectivity.c |
| 27-32 | List and matrix DFS | 41_array_graph.c, graph.h, 34_graph_connectivity.c |
| 33-38 | List and matrix BFS using reusable enqueue/dequeue | 41_array_graph.c, graph.h, 17_graphs.c |
| 39-41 | Connectivity and connected components of undirected graphs | 34_graph_connectivity.c |
| 42-46 | DFS/BFS parent edges and spanning trees/forests | 34_graph_connectivity.c |
| Tutorial 12 | Directed graph traversals, traversal trees, list-to-matrix conversion and comparison | graph.h, 34_graph_connectivity.c |

## Representation limits

See each example's short contract. Integer arithmetic examples assume results fit their types. Most bounded containers use CAPACITY=128. Symbolic conversion uses single-character operands; numeric evaluators use whitespace-separated numbers. Examples use fixed inputs for tracing except 21_records.c, which reads two records.

The book is a concept and implementation reference. It does not repeat every story-specific input menu or every data-field variant from the tutorial exercises. The corresponding algorithms and representations are mapped above.

## Array representation review

The Trees PPT introduces sequential/array and linked binary-tree representations on slides 21-27. Its traversal programs primarily use linked nodes. The Graphs PPT describes adjacency matrices on slides 18-21, but its complete DFS/BFS listings use linked adjacency lists (slides 23-38).

40_array_binary_tree.c is a separate plain-array binary tree with storage, preorder, inorder, postorder, level order and subtree removal. It uses standard C headers only.

41_array_graph.c explicitly declares int graph[MAX][MAX], with edge insertion, display, DFS, BFS and undirected component counting. BFS reuses the previously covered circular array queue. The graph itself has no linked edge nodes.

Shared header guards, size macros, custom includes and the common allocation helper now have explanatory comments. The book explains which declarations must be retained when combining an example into one C file.
