#include <assert.h>
#define main demo_main
#include "09_doubly_circular.c"
#undef main

void check(DNode *h,int n) {
 DNode *p=h;int count=0;
 do {assert(p->next->previous==p);assert(p->previous->next==p);p=p->next;count++;assert(count<=n+1);}while(p!=h);
 assert(count==n+1);
}
int main(void) {
 DNode *a=createHeader(),*b=createHeader();check(a,0);concatenate(a,b);check(a,0);
 insertBetween(b,b,7);concatenate(a,b);check(a,1);check(b,0);
 insertBetween(a,a->next,5);insertBetween(a->previous,a,9);check(a,3);
 removeKnown(a->next);check(a,2);removeKnown(a->previous);check(a,1);
 removeKnown(a->next);check(a,0);destroyCircular(a);destroyCircular(b);return 0;
}
