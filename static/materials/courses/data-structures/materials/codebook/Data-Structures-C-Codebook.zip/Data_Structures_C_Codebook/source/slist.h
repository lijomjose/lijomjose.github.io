/* One singly linked list many uses
 * This shared library keeps both head and tail. The list owns every node it links. A caller must initialize a List with {NULL,NULL}. Indices are zero based. The tail route makes appending cheap; it does not tell us the predecessor of the tail.
 */

/* Define nodes and the list object
 * A self-referential structure contains a pointer to its own type, not another complete embedded node. The empty invariant is head==NULL and tail==NULL.
 */

/* Header guard: include these declarations only once in this C file. */
#ifndef SLIST_H
/* Remember that this header has already been included. */
#define SLIST_H
/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct Node {
    int value;
    struct Node *next;
} Node;
typedef struct {
    Node *head;
    Node *tail;
} List;

/* Create one detached node
 * allocate centralizes the demo's allocation-failure policy. The new node is initialized completely before we publish a route to it from the list.
 */

static inline Node *newNode(int value)
{
    Node *node = allocate(sizeof *node);
    node->value = value;
    node->next = NULL;
    return node;
}

/* Insert at the head
 * Point the new node to the old first node, then make it the head. If the list was empty, the new node must also become tail. This is the operation later used for stack push.
 */

static inline void prepend(List *list, int value)
{
    Node *node = newNode(value);
    node->next = list->head;
    if (list->head == NULL) {
        list->tail = node;
    }
    list->head = node;
}

/* Insert at the tail
 * If a tail exists, let it point to the new node. Otherwise this is the first node. Finally record the new tail. No traversal is needed because we keep tail.
 */

static inline void append(List *list, int value)
{
    Node *node = newNode(value);
    if (list->tail == NULL) {
        list->head = node;
    } else {
        list->tail->next = node;
    }
    list->tail = node;
}

/* Delete at the head
 * Save the old head, copy its value, advance head, and then free the old node. When the last node leaves, clear tail too. Reading old->next after free would use an object whose lifetime has ended.
 */

static inline bool removeFront(List *list, int *value)
{
    if (list->head == NULL) {
        return false;
    }
    Node *old = list->head;
    *value = old->value;
    list->head = old->next;
    if (list->head == NULL) {
        list->tail = NULL;
    }
    free(old);
    return true;
}

/* Find a node at an index
 * Stop either at the requested position or at NULL. A negative position is invalid. This helper is shared by positional insertion and deletion.
 */

static inline Node *nodeAt(const List *list, int position)
{
    if (position < 0) {
        return NULL;
    }
    Node *current = list->head;
    for (int i = 0; i < position && current != NULL; i++) {
        current = current->next;
    }
    return current;
}

/* Insert after finding the predecessor
 * Index zero reuses prepend. Otherwise find index position-1. Connecting node->next before previous->next keeps the old suffix reachable. Inserting after the tail also updates tail.
 */

static inline bool insertAt(List *list, int position, int value)
{
    if (position < 0) {
        return false;
    }
    if (position == 0) {
        prepend(list, value);
        return true;
    }
    Node *previous = nodeAt(list, position - 1);
    if (previous == NULL) {
        return false;
    }
    Node *node = newNode(value);
    node->next = previous->next;
    previous->next = node;
    if (previous == list->tail) {
        list->tail = node;
    }
    return true;
}

/* Delete after finding the predecessor
 * Index zero reuses removeFront. For another position, bypass the target and update tail if necessary. The predecessor search costs time even though changing the links costs only a few assignments.
 */

static inline bool removeAt(List *list, int position, int *value)
{
    if (position < 0) {
        return false;
    }
    if (position == 0) {
        return removeFront(list, value);
    }
    Node *previous = nodeAt(list, position - 1);
    if (previous == NULL || previous->next == NULL) {
        return false;
    }
    Node *old = previous->next;
    *value = old->value;
    previous->next = old->next;
    if (old == list->tail) {
        list->tail = previous;
    }
    free(old);
    return true;
}

/* Search follows routes rather than computing addresses
 * An array can jump to index i. A singly linked list reaches the ith node by walking through earlier links. Search returns a borrowed pointer; the list still owns the node.
 */

static inline Node *findNode(const List *list, int value)
{
    Node *current = list->head;
    while (current != NULL) {
        if (current->value == value) {
            return current;
        }
        current = current->next;
    }
    return NULL;
}

/* Reverse one link at a time
 * Before changing current->next, save the original next node. previous is the reversed prefix; current begins the untouched suffix. The old head becomes the new tail.
 */

static inline void reverseList(List *list)
{
    Node *previous = NULL;
    Node *current = list->head;
    list->tail = list->head;
    while (current != NULL) {
        Node *next = current->next;
        current->next = previous;
        previous = current;
        current = next;
    }
    list->head = previous;
}

/* Visit each value
 * The cursor borrows links. Moving it does not move head and does not remove nodes.
 */

static inline void printList(const List *list)
{
    const Node *current = list->head;
    while (current != NULL) {
        printf("%d ", current->value);
        current = current->next;
    }
    putchar('\n');
}

/* Release every owned node
 * Cleanup reuses the already explained front deletion. A separate temporary receives discarded values. The list ends in a valid empty state.
 */

static inline void clearList(List *list)
{
    while (list->head != NULL) {
        int discarded;
        removeFront(list, &discarded);
    }
}
#endif /* End of this header guard. */
