/* Visit the tree before trusting a shortcut
 * First build an arbitrary binary tree directly. Then build a separate BST through its insertion function. They share the same node representation but make different ordering promises.
 */

/* Level order uses the already explained queue
 * Enqueue the root, repeatedly remove the oldest waiting node, visit it, and enqueue its existing children. A child is not visited immediately because earlier nodes on the same level still deserve their turn.
 */

/* Reuse the queue of tree pointers; its link operations are already covered. */
#include "tree_queue.h"
void levelOrder(const Tree *root)
{
    if (root == NULL) {
        return;
    }
    TreeQueue queue = {NULL, NULL};
    enqueueTree(&queue, root);
    while (queue.front != NULL) {
        const Tree *current;
        bool ok = dequeueTree(&queue, &current);
        if (ok == false) {
            break;
        }
        printf("%d ", current->value);
        if (current->left != NULL) {
            enqueueTree(&queue, current->left);
        }
        if (current->right != NULL) {
            enqueueTree(&queue, current->right);
        }
    }
    putchar('\n');
}

/* Main logic
 * The first tree has root 10, left child 30 with left child 40, and right child 20. Its inorder is not sorted. After the general operations, build and modify a genuine BST.
 */

int main(void)
{
    Tree *root = newTreeNode(10);
    root->left = newTreeNode(30);
    root->left->left = newTreeNode(40);
    root->right = newTreeNode(20);
    printf("Preorder: ");
    preorder(root);
    printf("\nInorder: ");
    inorder(root);
    printf("\nPostorder: ");
    postorder(root);
    printf("\nLevel order: ");
    levelOrder(root);
    printf("Nodes %d Leaves %d Height %d\n",
           nodeCount(root), leafCount(root), treeHeight(root));
    Tree *copy = copyTree(root);
    printf("Equal copy: %d\n", equalTrees(root, copy));
    mirrorTree(copy);
    printf("Mirrored copy: ");
    levelOrder(copy);
    destroyTree(root);
    destroyTree(copy);
    Tree *bst = NULL;
    int keys[] = {20, 10, 30, 25, 40, 27};
    for (int i = 0; i < 6; i++) {
        bst = bstInsert(bst, keys[i]);
    }
    Tree *found = bstSearch(bst, 27);
    printf("Found 27: %d\n", found != NULL);
    printf("Min %d Max %d\n", bstMinimum(bst)->value,
           bstMaximum(bst)->value);
    bst = bstDelete(bst, 20);
    inorder(bst);
    putchar('\n');
    destroyTree(bst);
    return 0;
}
