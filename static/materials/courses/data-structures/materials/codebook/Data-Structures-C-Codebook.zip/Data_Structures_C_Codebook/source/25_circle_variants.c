/* First only and last only circular lists
 * The PPT shows both endpoint choices. Reuse the tested Circle operations by creating a temporary view. A last-only view derives first in O(1). A first-only view must find last by walking. The view borrows nodes; it does not create another owner.
 */

/* Build a view from the first route
 * Finding last costs O(n). Once found, the existing circle functions can do the actual link update.
 */

/* Reuse the circular singly linked list types and operations. */
#include "circle.h"
Circle viewFromFirst(Node *first)
{
    Circle view = {first, NULL};
    if (first == NULL) {
        return view;
    }
    view.last = first;
    while (view.last->next != first) {
        view.last = view.last->next;
    }
    return view;
}

/* Build a view from the last route
 * In a nonempty ring, last.next is first. No scan is needed.
 */

Circle viewFromLast(Node *last)
{
    Circle view = {NULL, last};
    if (last != NULL) {
        view.first = last->next;
    }
    return view;
}

/* Insert using only a first route
 * Choose front or rear with the flag. After the shared operation changes the view, copy its first route back to the caller.
 */

void insertFirstOnly(Node **first, int value, bool atFront)
{
    Circle view = viewFromFirst(*first);
    circleInsert(&view, value, atFront);
    *first = view.first;
}

/* Delete using only a first route
 * The view pays the predecessor/last discovery cost. The actual empty and singleton cases stay in the previously explained operations.
 */

bool removeFirstOnly(Node **first, bool atFront, int *value)
{
    Circle view = viewFromFirst(*first);
    bool ok;
    if (atFront) {
        ok = circleRemoveFront(&view, value);
    } else {
        ok = circleRemoveRear(&view, value);
    }
    *first = view.first;
    return ok;
}

/* Insert using only a last route
 * Front insertion keeps the old last; rear insertion changes it. The shared circle function handles that distinction.
 */

void insertLastOnly(Node **last, int value, bool atFront)
{
    Circle view = viewFromLast(*last);
    circleInsert(&view, value, atFront);
    *last = view.last;
}

/* Delete using only a last route
 * Front deletion is O(1). Rear deletion still walks for the predecessor. Emptying a singleton clears the caller's last route.
 */

bool removeLastOnly(Node **last, bool atFront, int *value)
{
    Circle view = viewFromLast(*last);
    bool ok;
    if (atFront) {
        ok = circleRemoveFront(&view, value);
    } else {
        ok = circleRemoveRear(&view, value);
    }
    *last = view.last;
    return ok;
}

/* Main logic
 * Run both endpoint variants. The temporary views are for display only. Drain through the matching owner route, not through a stale view.
 */

int main(void)
{
    Node *first = NULL;
    insertFirstOnly(&first, 20, false);
    insertFirstOnly(&first, 10, true);
    Circle view = viewFromFirst(first);
    printCircle(&view);
    int value;
    bool ok = removeFirstOnly(&first, false, &value);
    if (ok == false) {
        return 1;
    }
    while (first != NULL) {
        removeFirstOnly(&first, true, &value);
    }
    Node *last = NULL;
    insertLastOnly(&last, 20, false);
    insertLastOnly(&last, 10, true);
    view = viewFromLast(last);
    printCircle(&view);
    ok = removeLastOnly(&last, false, &value);
    if (ok == false) {
        return 1;
    }
    while (last != NULL) {
        removeLastOnly(&last, true, &value);
    }
    return 0;
}
