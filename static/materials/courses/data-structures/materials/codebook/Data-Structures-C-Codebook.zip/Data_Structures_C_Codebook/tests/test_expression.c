#include <assert.h>
#define main demo_main
#include "12_expressions.c"
#undef main

int main(void)
{
    const char *inputs[]={"a+b*c","a^b^c","a-b-c","(a+b)*c","a/(b-c)","a^b*c"};
    const char *expected[]={"abc*+","abc^^","ab-c-","ab+c*","abc-/","ab^c*"};
    char out[128]; Expression t;
    for(int i=0;i<6;i++) {
        assert(infixToPostfix(inputs[i],out,sizeof out));
        assert(strcmp(out,expected[i])==0);
        assert(treeFromPostfix(out,&t));
    }
    const char *bad[]={"","a+","(a+b","a+b)","ab","a(b)","()","a/**b","-a"};
    for(int i=0;i<9;i++) assert(infixToPostfix(bad[i],out,sizeof out)==false);
    assert(treeFromPostfix("a+",&t)==false);
    assert(treeFromPrefix("+a",&t)==false);
    assert(treeFromPostfix("ab",&t)==false);
    double v=99;
    assert(evaluate("10 3 -",false,&v) && v==7);
    assert(evaluate("- 10 3",true,&v) && v==7);
    assert(evaluate("2 3 2 ^ ^",false,&v) && v==512);
    assert(evaluate("^ 2 ^ 3 2",true,&v) && v==512);
    assert(evaluate("12.5 -2 *",false,&v) && v==-25);
    const char *invalid[]={"","1 +","1 2","1 0 /","abc","nan","1e999","2 3x +"};
    for(int i=0;i<8;i++) { v=99; assert(evaluate(invalid[i],false,&v)==false); assert(v==99); }
    return 0;
}
