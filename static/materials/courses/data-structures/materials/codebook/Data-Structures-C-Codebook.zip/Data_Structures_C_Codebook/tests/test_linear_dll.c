#include <assert.h>
#define main demo_main
#include "24_linear_dll.c"
#undef main

void check(DList *l,int n){DLink *p=l->head,*prev=NULL;int count=0;while(p){assert(p->previous==prev);prev=p;p=p->next;count++;assert(count<=n);}assert(count==n&&prev==l->tail);if(l->head)assert(!l->head->previous);if(l->tail)assert(!l->tail->next);}
int main(void){
 DList a={NULL,NULL},c={NULL,NULL};int v=99;assert(!dRemoveAt(&a,0,&v)&&v==99);assert(!dInsertAt(&a,-1,0));
 for(int i=0;i<100;i++){assert(dInsertAt(&a,i,i));check(&a,i+1);}
 for(int i=99;i>=0;i--){assert(dRemoveAt(&a,i,&v));assert(v==i);check(&a,i);}
 dConcatenate(&a,&c);check(&a,0);dInsertBefore(&c,NULL,1);dConcatenate(&a,&c);check(&a,1);check(&c,0);dClear(&a);dClear(&c);return 0;
}
