#include <assert.h>
#define main demo_main
#include "17_graphs.c"
#undef main

int main(void) {
 Graph g;assert(initGraph(&g,5));assert(addUndirected(&g,-1,2)==false);
 assert(addUndirected(&g,0,1));assert(addUndirected(&g,1,2));assert(addUndirected(&g,2,0));assert(addUndirected(&g,3,4));assert(addUndirected(&g,0,1));
 int arcs=0;for(int i=0;i<5;i++)for(Edge *e=g.neighbors[i];e;e=e->next)arcs++;assert(arcs==8);
 bool visited[CAPACITY]={false};bfsFrom(&g,0,visited);
 assert(visited[0]&&visited[1]&&visited[2]&&!visited[3]&&!visited[4]);
 memset(visited,0,sizeof visited);dfsFrom(&g,3,visited);assert(!visited[0]&&visited[3]&&visited[4]);
 destroyGraph(&g);return 0;
}
