/* Connectivity components and spanning forests
 * The Graphs PPT also covers connectivity, components, and traversal-tree edges. Reuse graph.h and int_queue.h. Component counting below assumes an undirected graph. For directed graphs, reachability alone does not identify strongly connected components.
 */

/* Add a directed edge
 * Validate both endpoints, suppress duplicates, then add one arc. Unlike the undirected helper, do not add the reverse arc.
 */

/* Reuse the earlier graph types and graph operations. */
#include "graph.h"
bool addDirected(Graph *graph, int from, int to)
{
    if (from < 0 || to < 0 || from >= graph->vertexCount
        || to >= graph->vertexCount) {
        return false;
    }
    if (graph->matrix[from][to]) {
        return true;
    }
    addArc(graph, from, to);
    return true;
}

/* Matrix DFS scans one whole row for neighbors
 * The DFS rule is unchanged: mark before recursing. A full matrix-based forest scans Theta(V^2) cells.
 */

void matrixDfsFrom(const Graph *graph, int vertex, bool visited[])
{
    visited[vertex] = true;
    printf("%d ", vertex);
    for (int neighbor = 0; neighbor < graph->vertexCount; neighbor++) {
        if (graph->matrix[vertex][neighbor] && visited[neighbor] == false) {
            matrixDfsFrom(graph, neighbor, visited);
        }
    }
}

/* Record one BFS tree and its component label
 * label=-1 means undiscovered. On first discovery, store the parent and distance as well as the label. A new vertex gets distance[parent]+1 because every edge here counts as one step.
 */

void recordBfs(const Graph *graph, int start, int component,
               int labels[], int parents[], int distances[])
{
    IntQueue queue;
    initQueue(&queue);
    labels[start] = component;
    parents[start] = -1;
    distances[start] = 0;
    enqueue(&queue, start);
    while (queue.count > 0) {
        int vertex;
        dequeue(&queue, &vertex);
        for (const Edge *edge = graph->neighbors[vertex];
             edge != NULL; edge = edge->next) {
            int neighbor = edge->to;
            if (labels[neighbor] == -1) {
                labels[neighbor] = component;
                parents[neighbor] = vertex;
                distances[neighbor] = distances[vertex] + 1;
                bool ok = enqueue(&queue, neighbor);
                if (ok == false) {
                    exit(EXIT_FAILURE);
                }
            }
        }
    }
}

/* Count components by counting new traversal starts
 * Initialize every vertex as undiscovered. Each unvisited start grows exactly one component in an undirected graph. Its recorded parents form a spanning tree for that component.
 */

int graphComponents(const Graph *graph, int labels[],
                     int parents[], int distances[])
{
    for (int i = 0; i < graph->vertexCount; i++) {
        labels[i] = -1;
        parents[i] = -1;
        distances[i] = -1;
    }
    int count = 0;
    for (int vertex = 0; vertex < graph->vertexCount; vertex++) {
        if (labels[vertex] == -1) {
            recordBfs(graph, vertex, count, labels, parents, distances);
            count++;
        }
    }
    return count;
}

/* DFS also records a traversal tree
 * The edge that first discovers a vertex becomes its parent edge. An already visited neighbor does not get a new parent. The root starts with parent=-1.
 */

void recordDfs(const Graph *graph, int vertex, bool visited[], int parents[])
{
    visited[vertex] = true;
    for (const Edge *edge = graph->neighbors[vertex];
         edge != NULL; edge = edge->next) {
        int neighbor = edge->to;
        if (visited[neighbor] == false) {
            parents[neighbor] = vertex;
            recordDfs(graph, neighbor, visited, parents);
        }
    }
}

/* Print tree edges without repeating graph traversal
 * Each nonroot discovered vertex has one parent. These links are the tree edges. Remaining graph edges are nontree edges; an undirected parent edge is stored twice in the adjacency lists but is still one graph edge.
 */

void printForestEdges(const Graph *graph, const int parents[])
{
    for (int vertex = 0; vertex < graph->vertexCount; vertex++) {
        if (parents[vertex] != -1) {
            printf("%d - %d\n", parents[vertex], vertex);
        }
    }
}

/* Count incoming and outgoing directed edges
 * For this adjacency matrix, column vertex counts incoming edges and row vertex counts outgoing edges. In an undirected simple graph, either count is its ordinary degree.
 */

void vertexDegrees(const Graph *graph, int vertex, int *in, int *out)
{
    *in = 0;
    *out = 0;
    for (int other = 0; other < graph->vertexCount; other++) {
        if (graph->matrix[other][vertex]) {
            (*in)++;
        }
        if (graph->matrix[vertex][other]) {
            (*out)++;
        }
    }
}

/* Rebuild a matrix from adjacency lists
 * Clear the destination, then set one cell per stored arc. An undirected graph already has both arc directions. Clearing an input-sized matrix costs Theta(V^2), even when scanning the lists costs only O(V+E).
 */

void listsToMatrix(const Graph *graph, bool matrix[][CAPACITY])
{
    for (int row = 0; row < graph->vertexCount; row++) {
        for (int column = 0; column < graph->vertexCount; column++) {
            matrix[row][column] = false;
        }
    }
    for (int vertex = 0; vertex < graph->vertexCount; vertex++) {
        for (const Edge *edge = graph->neighbors[vertex];
             edge != NULL; edge = edge->next) {
            matrix[vertex][edge->to] = true;
        }
    }
}

/* Main logic
 * A triangle plus an isolated vertex has two components. Record its BFS forest, then a DFS tree from 0. Finally build a separate directed graph to show in-degree and out-degree.
 */

int main(void)
{
    Graph graph;
    bool ok = initGraph(&graph, 4);
    if (ok == false) {
        return 1;
    }
    addUndirected(&graph, 0, 1);
    addUndirected(&graph, 1, 2);
    addUndirected(&graph, 2, 0);
    int labels[CAPACITY];
    int parents[CAPACITY];
    int distances[CAPACITY];
    int components = graphComponents(&graph, labels, parents, distances);
    printf("Components: %d Connected: %d\n", components, components == 1);
    printForestEdges(&graph, parents);
    bool visited[CAPACITY] = {false};
    matrixDfsFrom(&graph, 0, visited);
    putchar('\n');
    for (int i = 0; i < graph.vertexCount; i++) {
        parents[i] = -1;
        visited[i] = false;
    }
    recordDfs(&graph, 0, visited, parents);
    printForestEdges(&graph, parents);
    destroyGraph(&graph);
    Graph directed;
    initGraph(&directed, 3);
    addDirected(&directed, 0, 1);
    addDirected(&directed, 2, 1);
    int in;
    int out;
    vertexDegrees(&directed, 1, &in, &out);
    printf("Vertex 1 in-degree %d out-degree %d\n", in, out);

    bool rebuilt[CAPACITY][CAPACITY];
    listsToMatrix(&directed, rebuilt);
    bool same = true;
    for (int row = 0; row < directed.vertexCount; row++) {
        for (int column = 0; column < directed.vertexCount; column++) {
            if (rebuilt[row][column] != directed.matrix[row][column]) {
                same = false;
            }
        }
    }
    printf("Rebuilt matrix matches: %d\n", same);
    destroyGraph(&directed);
    return 0;
}
