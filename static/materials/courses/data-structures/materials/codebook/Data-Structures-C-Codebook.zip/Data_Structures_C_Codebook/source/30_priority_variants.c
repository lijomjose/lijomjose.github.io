/* Unsorted priorities min max and peek
 * The sorted-array queue is in priority.h. Here we add an unsorted-array version. A flag chooses lowest-number-first or highest-number-first. Ties keep arrival order.
 */

/* Unsorted insertion just appends
 * This version spends O(1) on arrival. It postpones choosing the winner until peek or deletion.
 */

/* Reuse the sorted priority queue already covered. */
#include "priority.h"
bool admitUnsorted(PriorityQueue *queue, Patient patient)
{
    if (queue->count == CAPACITY) {
        return false;
    }
    queue->items[queue->count] = patient;
    queue->count++;
    return true;
}

/* Find the best index under the chosen policy
 * Keep the first occurrence when priorities tie. Return -1 when empty. The scan is O(n).
 */

int bestPatientIndex(const PriorityQueue *queue, bool highestNumberFirst)
{
    if (queue->count == 0) {
        return -1;
    }
    int best = 0;
    for (int i = 1; i < queue->count; i++) {
        bool better = queue->items[i].priority < queue->items[best].priority;
        if (highestNumberFirst) {
            better = queue->items[i].priority > queue->items[best].priority;
        }
        if (better) {
            best = i;
        }
    }
    return best;
}

/* Unsorted peek finds but does not remove
 * Reuse the selection helper. The output remains unchanged if no patient exists.
 */

bool peekUnsorted(const PriorityQueue *queue, bool highestNumberFirst,
                  Patient *patient)
{
    int best = bestPatientIndex(queue, highestNumberFirst);
    if (best == -1) {
        return false;
    }
    *patient = queue->items[best];
    return true;
}

/* Unsorted deletion selects then closes the gap
 * Shift remaining records left. Replacing the removed record with the final item would be cheaper to move, but could disturb arrival order for future equal-priority service.
 */

bool serveUnsorted(PriorityQueue *queue, bool highestNumberFirst,
                   Patient *patient)
{
    int best = bestPatientIndex(queue, highestNumberFirst);
    if (best == -1) {
        return false;
    }
    *patient = queue->items[best];
    for (int i = best; i < queue->count - 1; i++) {
        queue->items[i] = queue->items[i + 1];
    }
    queue->count--;
    return true;
}

/* Sorted peek reads the ready end
 * Only use this helper with a queue maintained by the sorted admit function. Mixing sorted and unsorted operations on one queue would break the representation rule.
 */

bool peekSorted(const PriorityQueue *queue, Patient *patient)
{
    if (queue->count == 0) {
        return false;
    }
    *patient = queue->items[queue->count - 1];
    return true;
}

/* Empty and full are separate questions
 * The same container count works for either array representation.
 */

bool priorityEmpty(const PriorityQueue *queue)
{
    return queue->count == 0;
}

/* Full compares logical count with allocated capacity
 * A full queue may still contain low-priority records. Priority does not create extra storage.
 */

bool priorityFull(const PriorityQueue *queue)
{
    return queue->count == CAPACITY;
}

/* Main logic
 * Use the unsorted version as a max-priority queue. Use a separate sorted queue as a min-priority queue. The direction is explicit rather than hidden in the function name.
 */

int main(void)
{
    PriorityQueue unsorted = {0};
    Patient arrivals[] = {{"A", 2}, {"B", 5}, {"C", 5}};
    for (int i = 0; i < 3; i++) {
        bool ok = admitUnsorted(&unsorted, arrivals[i]);
        if (ok == false) {
            return 1;
        }
    }
    Patient patient;
    bool ok = peekUnsorted(&unsorted, true, &patient);
    if (ok) {
        printf("Max peek: %s\n", patient.name);
    }
    while (priorityEmpty(&unsorted) == false) {
        serveUnsorted(&unsorted, true, &patient);
        puts(patient.name);
    }
    PriorityQueue sorted = {0};
    ok = admit(&sorted, arrivals[0]);
    if (ok == false) {
        return 1;
    }
    ok = peekSorted(&sorted, &patient);
    if (ok) {
        printf("Min sorted peek: %s Full: %d\n",
               patient.name, priorityFull(&sorted));
    }
    return 0;
}
