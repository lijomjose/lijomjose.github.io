/* A stack with a visible top
 * This header is shared by bracket checking and expression processing. top is the index of the last occupied slot. Empty means top=-1. Every mutating operation reports success separately from its output value, so -1 can remain ordinary data.
 */

/* State and initialization
 * The header guard permits repeated inclusion. Static inline functions allow this small teaching library to live entirely in a header without linker conflicts.
 */

/* Header guard: include these declarations only once in this C file. */
#ifndef INT_STACK_H
/* Remember that this header has already been included. */
#define INT_STACK_H
/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct {
    int items[CAPACITY];
    int top;
} IntStack;
static inline void initStack(IntStack *stack)
{
    stack->top = -1;
}

/* Push checks space before moving top
 * The last legal occupied index is CAPACITY-1. Increment top only after ruling out overflow, then write into the newly occupied slot.
 */

static inline bool push(IntStack *stack, int value)
{
    if (stack->top == CAPACITY - 1) {
        return false;
    }
    stack->top++;
    stack->items[stack->top] = value;
    return true;
}

/* Pop reads before releasing the slot
 * A failed pop leaves *value unchanged. On success, copying the old top value happens before decrementing top.
 */

static inline bool pop(IntStack *stack, int *value)
{
    if (stack->top == -1) {
        return false;
    }
    *value = stack->items[stack->top];
    stack->top--;
    return true;
}

/* Peek borrows without removing
 * Peek has the same empty test as pop but does not change top. It supports precedence decisions without prematurely discarding an operator.
 */

static inline bool peek(const IntStack *stack, int *value)
{
    if (stack->top == -1) {
        return false;
    }
    *value = stack->items[stack->top];
    return true;
}

/* Display a stack from top to bottom
 * Visit occupied indices from top down to zero. Printing the stack does not pop it.
 */

static inline void displayStack(const IntStack *stack)
{
    for (int i = stack->top; i >= 0; i--) {
        printf("%d ", stack->items[i]);
    }
    putchar('\n');
}
#endif /* End of this header guard. */
