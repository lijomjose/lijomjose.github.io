/* Rectangular and ragged tables
 * A row-pointer table is an array of pointers, with one separately allocated integer array per row. A rectangle uses equal row lengths. A ragged table allows different lengths. Neither layout is a genuine contiguous int matrix[R][C].
 */

/* Allocate rows with explicit lengths
 * Limit dimensions to small classroom sizes before multiplying byte counts. Zero-length rows are represented by NULL. allocate stops the demo on failure. Initialize every element before reading it.
 */

/* Header guard: include these declarations only once in this C file. */
#ifndef COURSE_DYNAMIC_ROWS_H
/* Remember that this header has already been included. */
#define COURSE_DYNAMIC_ROWS_H
/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
int **createRows(int rows, const int lengths[])
{
    if (rows < 1 || rows > 100) {
        return NULL;
    }
    for (int row = 0; row < rows; row++) {
        if (lengths[row] < 0 || lengths[row] > 1000) {
            return NULL;
        }
    }
    int **table = allocate((size_t)rows * sizeof *table);
    for (int row = 0; row < rows; row++) {
        table[row] = NULL;
        if (lengths[row] > 0) {
            table[row] = allocate((size_t)lengths[row] * sizeof **table);
            for (int column = 0; column < lengths[row]; column++) {
                table[row][column] = 0;
            }
        }
    }
    return table;
}

/* Display each row using its own length
 * The number of columns is not recoverable from int **. We pass row lengths alongside the table.
 */

void printRows(int *const table[], int rows, const int lengths[])
{
    for (int row = 0; row < rows; row++) {
        for (int column = 0; column < lengths[row]; column++) {
            printf("%d ", table[row][column]);
        }
        putchar('\n');
    }
}

/* Free the rows before the row pointer table
 * free(table) alone would release only the pointer array. Every separately allocated row must be released too. free(NULL) is allowed for a zero-length row.
 */

void destroyRows(int **table, int rows)
{
    for (int row = 0; row < rows; row++) {
        free(table[row]);
    }
    free(table);
}
#endif /* End of this header guard. */
