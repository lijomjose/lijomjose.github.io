#include <assert.h>
#define main demo_main
#include "31_heap_priority.c"
#undef main

int main(void){
 srand(92);
 for(int trial=0;trial<100;trial++){
  MinHeap h={0};int priorities[CAPACITY];
  for(int i=0;i<CAPACITY;i++){priorities[i]=rand()%15;Patient p={"patient",priorities[i]};assert(heapInsert(&h,p));}
  Patient p={"overflow",0};assert(!heapInsert(&h,p));
  int previous=-1;unsigned long long lastSequence=0;bool first=true;
  for(int n=CAPACITY;n>0;n--){HeapItem top=h.items[0];assert(top.patient.priority>=previous);if(!first && top.patient.priority==previous)assert(top.sequence>lastSequence);previous=top.patient.priority;lastSequence=top.sequence;first=false;assert(heapRemove(&h,&p));
   for(int i=1;i<h.count;i++)assert(!comesBefore(h.items[i],h.items[(i-1)/2]));
  }
  assert(!heapRemove(&h,&p));
 }
 return 0;
}
