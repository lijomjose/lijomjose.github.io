/* AVL main
 * Reuse avl.h. The complete main below shows the operation sequence.
 */

/* Main logic
 * Build a balanced tree, then delete two keys. Always assign the returned root: a root rotation or root deletion can change it.
 */

/* Reuse the AVL node type and balancing operations already covered. */
#include "avl.h"
int main(void)
{
    AVL *root = NULL;
    int keys[] = {30, 20, 40, 10, 25};
    for (int i = 0; i < 5; i++) {
        root = avlInsert(root, keys[i]);
    }
    root = avlDelete(root, 40);
    printAVL(root);
    putchar('\n');
    root = avlDelete(root, 20);
    printAVL(root);
    putchar('\n');
    destroyAVL(root);
    return 0;
}
