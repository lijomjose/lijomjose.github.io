#include <assert.h>
#define main demo_main
#include "15_threaded_tree.c"
#undef main

int main(void) {
 srand(28);
 for(int trial=0;trial<100;trial++){
  ThreadNode *root=NULL;bool seen[80]={false};
  for(int i=0;i<150;i++){int v=rand()%80;root=threadInsert(root,v);seen[v]=true;}
  ThreadNode *p=threadLeftmost(root);
  for(int i=0;i<80;i++)if(seen[i]){assert(p && p->value==i);p=inorderSuccessor(p);}
  assert(p==NULL);destroyThreaded(root);
 }
 return 0;
}
