/* A queue that reuses vacated slots
 * This circular queue and deque share one representation: front is the first occupied index; count is the number of stored items. The next rear insertion position is (front+count)%CAPACITY. There is no reserved empty slot: count distinguishes empty from full.
 */

/* Initialize an empty queue
 * A single representation supports queues, deques, graph BFS, and tree-level traversal. Keeping this in a reusable header prevents later algorithms from becoming queue implementations in disguise.
 */

/* Header guard: include these declarations only once in this C file. */
#ifndef INT_QUEUE_H
/* Remember that this header has already been included. */
#define INT_QUEUE_H
/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct {
    int items[CAPACITY];
    int front;
    int count;
} IntQueue;
static inline void initQueue(IntQueue *queue)
{
    queue->front = 0;
    queue->count = 0;
}

/* Enter at the rear
 * The computed rear position is currently free when count is below capacity. Modulo wraps the index, not the stored values. A failed insertion leaves the queue unchanged.
 */

static inline bool enqueue(IntQueue *queue, int value)
{
    if (queue->count == CAPACITY) {
        return false;
    }
    int rear = (queue->front + queue->count) % CAPACITY;
    queue->items[rear] = value;
    queue->count++;
    return true;
}

/* Leave at the front
 * Read the oldest item, advance front around the ring, and reduce count. No element moves. Empty queue indices need not return to their original values.
 */

static inline bool dequeue(IntQueue *queue, int *value)
{
    if (queue->count == 0) {
        return false;
    }
    *value = queue->items[queue->front];
    queue->front = (queue->front + 1) % CAPACITY;
    queue->count--;
    return true;
}

/* A deque may also enter at the front
 * Move front backward before storing the new item. Adding CAPACITY before modulo keeps the intermediate value nonnegative in C.
 */

static inline bool pushFront(IntQueue *queue, int value)
{
    if (queue->count == CAPACITY) {
        return false;
    }
    queue->front = (queue->front + CAPACITY - 1) % CAPACITY;
    queue->items[queue->front] = value;
    queue->count++;
    return true;
}

/* A deque may also leave at the rear
 * The last occupied position is one before the next rear insertion position. Removing it does not move front.
 */

static inline bool popRear(IntQueue *queue, int *value)
{
    if (queue->count == 0) {
        return false;
    }
    int rear = (queue->front + queue->count - 1) % CAPACITY;
    *value = queue->items[rear];
    queue->count--;
    return true;
}

/* Peek at the front without moving it
 * Check count before using front. The caller keeps ownership of the queue.
 */

static inline bool peekQueue(const IntQueue *queue, int *value)
{
    if (queue->count == 0) {
        return false;
    }
    *value = queue->items[queue->front];
    return true;
}

/* Display logical queue order rather than physical array order
 * Start at front and print count values, wrapping each index. Unoccupied cells are not part of the queue.
 */

static inline void displayQueue(const IntQueue *queue)
{
    for (int i = 0; i < queue->count; i++) {
        int index = (queue->front + i) % CAPACITY;
        printf("%d ", queue->items[index]);
    }
    putchar('\n');
}
#endif /* End of this header guard. */
