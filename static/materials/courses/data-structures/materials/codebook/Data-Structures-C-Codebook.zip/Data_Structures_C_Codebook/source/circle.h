/* A circle does not require two directions
 * Here first and last identify a circular singly linked list. Empty means both are NULL. Otherwise last.next must equal first. We keep this separate from the doubly linked ring so the two representations do not get mixed up.
 */

/* Define the circle
 * Reuse the Node type and newNode helper. The node still has only one route. Keeping both endpoints does not create a route to the predecessor of last.
 */

/* Header guard: include these declarations only once in this C file. */
#ifndef COURSE_CIRCLE_H
/* Remember that this header has already been included. */
#define COURSE_CIRCLE_H
/* Reuse the singly linked list types and operations already covered. */
#include "slist.h"
typedef struct {
    Node *first;
    Node *last;
} Circle;

/* Insert at either end with one shared helper
 * In an empty circle the new node points to itself. Otherwise connect it after last and before first. For front insertion, first changes; for rear insertion, last changes.
 */

void circleInsert(Circle *circle, int value, bool atFront)
{
    Node *node = newNode(value);
    if (circle->first == NULL) {
        circle->first = node;
        circle->last = node;
        node->next = node;
        return;
    }
    node->next = circle->first;
    circle->last->next = node;
    if (atFront) {
        circle->first = node;
    } else {
        circle->last = node;
    }
}

/* Delete the first and repair the closing link
 * The singleton case empties both routes. Otherwise advance first and point last back to it before freeing the old node.
 */

bool circleRemoveFront(Circle *circle, int *value)
{
    if (circle->first == NULL) {
        return false;
    }
    Node *old = circle->first;
    *value = old->value;
    if (circle->first == circle->last) {
        circle->first = NULL;
        circle->last = NULL;
    } else {
        circle->first = old->next;
        circle->last->next = circle->first;
    }
    free(old);
    return true;
}

/* Delete the last after finding its predecessor
 * Reuse front removal for a singleton. Otherwise walk until previous.next is last. This is the O(n) cost that a last pointer alone cannot remove.
 */

bool circleRemoveRear(Circle *circle, int *value)
{
    if (circle->first == NULL) {
        return false;
    }
    if (circle->first == circle->last) {
        return circleRemoveFront(circle, value);
    }
    Node *previous = circle->first;
    while (previous->next != circle->last) {
        previous = previous->next;
    }
    Node *old = circle->last;
    *value = old->value;
    previous->next = circle->first;
    circle->last = previous;
    free(old);
    return true;
}

/* Visit the first node once before checking for its return
 * The empty case must be handled before a do-while traversal. A nonempty circle visits at least one real node.
 */

void printCircle(const Circle *circle)
{
    if (circle->first == NULL) {
        puts("Empty circle");
        return;
    }
    const Node *current = circle->first;
    do {
        printf("%d ", current->value);
        current = current->next;
    } while (current != circle->first);
    putchar('\n');
}
#endif /* End of this header guard. */
