/* Do not rent a room for every zero
 * A triplet stores row, column, and value for one nonzero entry. Dimensions belong to the Sparse object rather than a fake first data term. This demo supports up to CAPACITY nonzero entries and dimensions up to CAPACITY. Entries are in row-major order, unique, and nonzero.
 */

/* Define the representation
 * count is the number of meaningful triplets. Capacity is physical storage. The distinction is the same one used by an array-backed stack.
 */

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct {
    int row;
    int column;
    int value;
} Term;
typedef struct {
    int rows;
    int columns;
    int count;
    Term terms[CAPACITY];
} Sparse;

/* Convert a rectangular matrix
 * A C parameter with [][3] points to rows of three integers. Scan row first, then column, and store only nonzero cells. This produces the ordering required by later merging algorithms.
 */

Sparse compressMatrix(int rows, const int matrix[][3])
{
    Sparse result = {0};
    if (rows < 0 || rows > CAPACITY / 3) {
        fprintf(stderr, "Matrix too large\n");
        exit(EXIT_FAILURE);
    }
    result.rows = rows;
    result.columns = 3;
    for (int row = 0; row < rows; row++) {
        for (int column = 0; column < 3; column++) {
            if (matrix[row][column] != 0) {
                Term entry = {row, column, matrix[row][column]};
                result.terms[result.count] = entry;
                result.count++;
            }
        }
    }
    return result;
}

/* Simple transpose groups by old column
 * For each old column, scan all entries and copy its members with row and column exchanged. The result is row-major ordered. Precondition: a valid Sparse object with dimensions and count within capacity.
 */

Sparse simpleTranspose(const Sparse *input)
{
    Sparse output = {0};
    output.rows = input->columns;
    output.columns = input->rows;
    for (int column = 0; column < input->columns; column++) {
        for (int i = 0; i < input->count; i++) {
            Term entry = input->terms[i];
            if (entry.column == column) {
                Term moved = {entry.column, entry.row, entry.value};
                output.terms[output.count] = moved;
                output.count++;
            }
        }
    }
    return output;
}

/* Fast transpose reserves each column its own segment
 * Count entries in each old column. Prefix sums tell us where each new row begins. nextPosition then moves inside that reserved segment as entries arrive. No search through the output is needed.
 */

Sparse fastTranspose(const Sparse *input)
{
    Sparse output = {0};
    int columnCount[CAPACITY] = {0};
    int nextPosition[CAPACITY] = {0};
    output.rows = input->columns;
    output.columns = input->rows;
    output.count = input->count;
    for (int i = 0; i < input->count; i++) {
        int column = input->terms[i].column;
        columnCount[column]++;
    }
    for (int column = 1; column < input->columns; column++) {
        nextPosition[column] = nextPosition[column - 1]
                             + columnCount[column - 1];
    }
    for (int i = 0; i < input->count; i++) {
        Term entry = input->terms[i];
        int position = nextPosition[entry.column];
        Term moved = {entry.column, entry.row, entry.value};
        output.terms[position] = moved;
        nextPosition[entry.column]++;
    }
    return output;
}

/* Display only meaningful entries
 * Printing dimensions makes it clear that a zero matrix still has a shape even though count is zero.
 */

void printSparse(const Sparse *matrix)
{
    printf("%d rows %d columns %d terms\n",
           matrix->rows, matrix->columns, matrix->count);
    for (int i = 0; i < matrix->count; i++) {
        Term entry = matrix->terms[i];
        printf("(%d,%d) = %d\n", entry.row, entry.column, entry.value);
    }
}

/* Main logic
 * Construct the same transpose through two algorithms. Later tests compare every output term rather than trusting a plausible-looking printout.
 */

int main(void)
{
    const int matrix[3][3] = {{0, 7, 0}, {0, 0, 9}, {5, 0, 4}};
    Sparse original = compressMatrix(3, matrix);
    Sparse slow = simpleTranspose(&original);
    Sparse fast = fastTranspose(&original);
    printSparse(&original);
    printSparse(&slow);
    printSparse(&fast);
    return 0;
}
