/* A balanced tree priority queue using earlier operations
 * Read the AVL section before this example. The tree stores active priority numbers; each priority has a FIFO queue of record indices. Priorities are 0 through CAPACITY-1, and at most CAPACITY patients may wait overall. Existing stack, queue, and AVL functions do the work.
 */

/* Keep records separate from their service order
 * A free-index stack tracks reusable record slots. Queue entries are indices into records. Equal priorities share one FIFO queue, so their arrival order is preserved.
 */

/* Reuse the sorted priority queue already covered. */
#include "priority.h"
/* Reuse the AVL node type and balancing operations already covered. */
#include "avl.h"
/* Reuse the earlier array stack type and its operations. */
#include "int_stack.h"
/* Reuse the circular array queue: IntQueue, initQueue, enqueue and dequeue. */
#include "int_queue.h"
typedef struct {
    Patient records[CAPACITY];
    IntQueue waiting[CAPACITY];
    IntStack freeSlots;
    AVL *priorities;
} TreePriorityQueue;
void initTreePriority(TreePriorityQueue *queue)
{
    queue->priorities = NULL;
    initStack(&queue->freeSlots);
    for (int i = 0; i < CAPACITY; i++) {
        initQueue(&queue->waiting[i]);
        push(&queue->freeSlots, i);
    }
}

/* Choose the smallest or largest active priority
 * Use one tree path. The caller has already checked that the tree is nonempty.
 */

AVL *selectPriority(AVL *root, bool highestNumberFirst)
{
    if (highestNumberFirst) {
        while (root->right != NULL) {
            root = root->right;
        }
    } else {
        while (root->left != NULL) {
            root = root->left;
        }
    }
    return root;
}

/* Admit a patient and activate its priority if needed
 * Reserve a record slot first. A successful reservation guarantees room in the chosen bucket because the total waiting count is below CAPACITY. Add the priority to the AVL tree only when its bucket was empty.
 */

bool treePriorityInsert(TreePriorityQueue *queue, Patient patient)
{
    int priority = patient.priority;
    if (priority < 0 || priority >= CAPACITY) {
        return false;
    }
    int slot;
    bool available = pop(&queue->freeSlots, &slot);
    if (available == false) {
        return false;
    }
    bool wasEmpty = queue->waiting[priority].count == 0;
    queue->records[slot] = patient;
    bool ok = enqueue(&queue->waiting[priority], slot);
    if (ok == false) {
        fprintf(stderr, "Record pool rule failed\n");
        exit(EXIT_FAILURE);
    }
    if (wasEmpty) {
        queue->priorities = avlInsert(queue->priorities, priority);
    }
    return true;
}

/* Peek uses a tree choice and a FIFO observer
 * Choose a priority, peek its queue index, then copy the patient record. Neither the tree nor the waiting order changes.
 */

bool treePriorityPeek(const TreePriorityQueue *queue, bool highestNumberFirst,
                       Patient *patient)
{
    if (queue->priorities == NULL) {
        return false;
    }
    AVL *best = selectPriority(queue->priorities, highestNumberFirst);
    int slot;
    bool ok = peekQueue(&queue->waiting[best->value], &slot);
    if (ok == false) {
        return false;
    }
    *patient = queue->records[slot];
    return true;
}

/* Serve and release the record slot
 * Remove the oldest record from the selected priority, return its index to freeSlots, then remove that priority from the AVL tree if no patient remains there.
 */

bool treePriorityRemove(TreePriorityQueue *queue, bool highestNumberFirst,
                         Patient *patient)
{
    if (queue->priorities == NULL) {
        return false;
    }
    AVL *best = selectPriority(queue->priorities, highestNumberFirst);
    int priority = best->value;
    int slot;
    bool ok = dequeue(&queue->waiting[priority], &slot);
    if (ok == false) {
        return false;
    }
    *patient = queue->records[slot];
    push(&queue->freeSlots, slot);
    if (queue->waiting[priority].count == 0) {
        queue->priorities = avlDelete(queue->priorities, priority);
    }
    return true;
}

/* Clear by serving until empty
 * Draining removes the allocated AVL nodes through avlDelete. The array queues and record table are embedded storage, so they require no free.
 */

void clearTreePriority(TreePriorityQueue *queue)
{
    while (queue->priorities != NULL) {
        Patient discarded;
        treePriorityRemove(queue, false, &discarded);
    }
}

/* Main logic
 * Use a min-priority policy. B and C tie, so their bucket serves B first. The same remove function with highestNumberFirst=true gives the opposite priority direction.
 */

int main(void)
{
    TreePriorityQueue queue;
    initTreePriority(&queue);
    Patient arrivals[] = {{"A", 3}, {"B", 1}, {"C", 1}};
    for (int i = 0; i < 3; i++) {
        bool ok = treePriorityInsert(&queue, arrivals[i]);
        if (ok == false) {
            return 1;
        }
    }
    Patient patient;
    bool ok = treePriorityPeek(&queue, false, &patient);
    if (ok) {
        printf("Next: %s\n", patient.name);
    }
    while (queue.priorities != NULL) {
        treePriorityRemove(&queue, false, &patient);
        puts(patient.name);
    }
    clearTreePriority(&queue);
    return 0;
}
