/* Pointer and matrix applications from the PPTs
 * These compact examples cover the remaining pointer-array tutorial patterns: count, reverse, student totals, subject averages, attendance, and selected row/column operations. The existing swap and dynamic-row helpers are reused.
 */

/* Count even and odd values through a pointer
 * The integer remainder test works for negative even values too. The two output counts start at zero.
 */

/* Reuse the search and sort functions already covered. */
#include "array_algorithms.h"
/* Reuse the dynamic row allocation and cleanup helpers. */
#include "dynamic_rows.h"
void countParity(const int values[], int count, int *even, int *odd)
{
    *even = 0;
    *odd = 0;
    const int *cursor = values;
    for (int i = 0; i < count; i++) {
        if (*cursor % 2 == 0) {
            (*even)++;
        } else {
            (*odd)++;
        }
        cursor++;
    }
}

/* Reverse an array in place using two routes
 * Handle short arrays before forming the last-element route. Swap the ends, then move both routes inward. The swap function was already explained with sorting.
 */

void reverseArray(int values[], int count)
{
    if (count < 2) {
        return;
    }
    int *left = values;
    int *right = values + count - 1;
    while (left < right) {
        swap(left, right);
        left++;
        right--;
    }
}

/* Compute student totals and subject averages
 * There are three columns. rows is positive and valid. Initialize both result arrays, then let each cell contribute once to its student total and its subject sum. Small mark totals fit int.
 */

void summarizeMarks(const int marks[][3], int rows,
                    int totals[], double averages[])
{
    for (int subject = 0; subject < 3; subject++) {
        averages[subject] = 0;
    }
    for (int student = 0; student < rows; student++) {
        totals[student] = 0;
        for (int subject = 0; subject < 3; subject++) {
            int value = *(*(marks + student) + subject);
            totals[student] = totals[student] + value;
            averages[subject] = averages[subject] + value;
        }
    }
    for (int subject = 0; subject < 3; subject++) {
        averages[subject] = averages[subject] / rows;
    }
}

/* Take the larger value at each matrix position
 * This is the PPT's C(i,j)=max(A(i,j),B(i,j)) operation. Equal dimensions and valid row counts are required. The comparison happens cell by cell, not between complete rows.
 */

void matrixMaximum(const int first[][3], const int second[][3],
                    int result[][3], int rows)
{
    for (int row = 0; row < rows; row++) {
        for (int column = 0; column < 3; column++) {
            int maximum = first[row][column];
            if (second[row][column] > maximum) {
                maximum = second[row][column];
            }
            result[row][column] = maximum;
        }
    }
}

/* Print a selected dynamic row
 * The lengths array says how many values that row contains. Return false for an invalid row number.
 */

bool printSelectedRow(int *const table[], int rows,
                       const int lengths[], int row)
{
    if (row < 0 || row >= rows) {
        return false;
    }
    for (int column = 0; column < lengths[row]; column++) {
        printf("%d ", table[row][column]);
    }
    putchar('\n');
    return true;
}

/* Print a selected column only if it exists in every row
 * Validate the complete column before printing anything. In a ragged table, a column may exist in one row and be missing in another.
 */

bool printSelectedColumn(int *const table[], int rows,
                          const int lengths[], int column)
{
    if (column < 0) {
        return false;
    }
    for (int row = 0; row < rows; row++) {
        if (column >= lengths[row]) {
            return false;
        }
    }
    for (int row = 0; row < rows; row++) {
        printf("%d ", table[row][column]);
    }
    putchar('\n');
    return true;
}

/* Replace a selected row
 * Only the requested row changes. Its length does not change.
 */

bool replaceSelectedRow(int **table, int rows, const int lengths[],
                         int row, int value)
{
    if (row < 0 || row >= rows) {
        return false;
    }
    for (int column = 0; column < lengths[row]; column++) {
        table[row][column] = value;
    }
    return true;
}

/* Attendance uses calloc to start everyone absent
 * Roll numbers in this particular example are 1 through count, while array indices still start at 0. The caller must free the returned status array.
 */

int *createAttendance(int count)
{
    if (count < 1 || count > 1000) {
        return NULL;
    }
    return calloc((size_t)count, sizeof(int));
}

/* Translate a roll number into its array index
 * Check the roll before subtracting one. Repeatedly marking the same roll is harmless.
 */

bool markPresent(int status[], int count, int roll)
{
    if (roll < 1 || roll > count) {
        return false;
    }
    status[roll - 1] = 1;
    return true;
}

/* Main logic
 * Use small inputs to exercise each operation. The matrix code and the dynamic row-table code use different parameter types because their layouts differ.
 */

int main(void)
{
    int values[] = {1, 2, 3, 4};
    int even;
    int odd;
    countParity(values, 4, &even, &odd);
    printf("Even %d Odd %d\n", even, odd);
    reverseArray(values, 4);
    printArray(values, 4);
    const int marks[2][3] = {{80, 70, 90}, {60, 90, 80}};
    int totals[2];
    double averages[3];
    summarizeMarks(marks, 2, totals, averages);
    printf("Totals: %d %d Subject 0 average: %.1f\n",
           totals[0], totals[1], averages[0]);
    const int other[2][3] = {{85, 60, 70}, {90, 50, 95}};
    int maximum[2][3];
    matrixMaximum(marks, other, maximum, 2);
    printf("Maximum at [1][2]: %d\n", maximum[1][2]);
    int lengths[] = {3, 3};
    int **table = createRows(2, lengths);
    if (table == NULL) {
        return 1;
    }
    replaceSelectedRow(table, 2, lengths, 1, 7);
    printSelectedRow(table, 2, lengths, 1);
    printSelectedColumn(table, 2, lengths, 2);
    destroyRows(table, 2);
    int *attendance = createAttendance(4);
    if (attendance == NULL) {
        return 1;
    }
    markPresent(attendance, 4, 2);
    for (int i = 0; i < 4; i++) {
        printf("Roll %d present %d\n", i + 1, attendance[i]);
    }
    free(attendance);
    return 0;
}
