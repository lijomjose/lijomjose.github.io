#include <assert.h>
#define main demo_main
#include "16_avl.c"
#undef main

int validate(AVL *p, long long low, long long high)
{
    if(!p) return 0;
    assert(p->value>low && p->value<high);
    int l=validate(p->left,low,p->value), r=validate(p->right,p->value,high);
    assert(abs(l-r)<=1); int h=1+(l>r?l:r); assert(p->height==h); return h;
}
int main(void)
{
    srand(38);
    for(int trial=0;trial<30;trial++) {
        AVL *root=NULL; bool present[100]={false};
        for(int step=0;step<1000;step++) {
            int v=rand()%100;
            if(rand()%2) { root=avlInsert(root,v); present[v]=true; }
            else { root=avlDelete(root,v); present[v]=false; }
            validate(root,LLONG_MIN,LLONG_MAX);
            for(int key=0;key<100;key++) {
                AVL *p=root;
                while(p && p->value!=key) p=key<p->value?p->left:p->right;
                assert((p!=NULL)==present[key]);
            }
        }
        destroyAVL(root);
    }
    return 0;
}
