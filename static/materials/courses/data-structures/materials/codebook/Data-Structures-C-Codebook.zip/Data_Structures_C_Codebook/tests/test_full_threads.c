#include <assert.h>
#define main demo_main
#include "33_fully_threaded.c"
#undef main

void check(FNode *h,bool expected[],int size){
 FNode *p=fullSuccessor(h);int n=0;
 for(int i=0;i<size;i++)if(expected[i]){assert(p!=h && p->value==i);FNode *next=fullSuccessor(p);if(next!=h && next->leftThread)assert(next->left==p);p=next;n++;}
 assert(p==h);p=fullPredecessor(h);int m=0;
 for(int i=size-1;i>=0;i--)if(expected[i]){assert(p!=h && p->value==i);p=fullPredecessor(p);m++;}
 assert(p==h && n==m);
}
int main(void){
 srand(93);
 FNode *empty=newThreadHeader();assert(fullSuccessor(empty)==empty);assert(fullPredecessor(empty)==empty);destroyFullyThreaded(empty);
 for(int trial=0;trial<80;trial++){
  FNode *h=newThreadHeader();bool seen[100]={false};
  for(int i=0;i<160;i++){int v=rand()%100;fullInsert(h,v);seen[v]=true;check(h,seen,100);}
  destroyFullyThreaded(h);
 }
 FNode *h=newThreadHeader();FNode *nodes[10];bool seen[100]={false};
 for(int i=0;i<10;i++){nodes[i]=fullInsert(h,i*10);seen[i*10]=true;}
 for(int i=0;i<10;i++){insertRightOf(nodes[i],i*10+1);seen[i*10+1]=true;check(h,seen,100);}
 destroyFullyThreaded(h);return 0;
}
