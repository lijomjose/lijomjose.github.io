/* General Tree with First Child and Next Sibling Links
 * A general tree can have more than two children. child reaches the first child; sibling reaches the next child of the same parent. The array binary tree is a separate example at the start of this chapter.
 */

/* Define a first child next sibling node
 * child reaches the first child. sibling reaches the next child of the same parent. The root's sibling is NULL in this example.
 */

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct GeneralNode {
    int value;
    struct GeneralNode *child;
    struct GeneralNode *sibling;
} GeneralNode;
GeneralNode *newGeneralNode(int value)
{
    GeneralNode *node = allocate(sizeof *node);
    node->value = value;
    node->child = NULL;
    node->sibling = NULL;
    return node;
}

/* Append one child
 * The child must be a separate owned tree with sibling=NULL. Walk the existing sibling chain to keep child order.
 */

void appendChild(GeneralNode *parent, GeneralNode *child)
{
    if (parent->child == NULL) {
        parent->child = child;
        return;
    }
    GeneralNode *last = parent->child;
    while (last->sibling != NULL) {
        last = last->sibling;
    }
    last->sibling = child;
}

/* Visit a general tree in preorder
 * Visit the parent, then each child subtree in sibling order. A sibling link is not a right child in the original general-tree meaning.
 */

void generalPreorder(const GeneralNode *root)
{
    if (root == NULL) {
        return;
    }
    printf("%d ", root->value);
    for (const GeneralNode *child = root->child;
         child != NULL; child = child->sibling) {
        generalPreorder(child);
    }
}

/* Release a general tree
 * Save each next sibling before destroying that child subtree. Finally free the parent.
 */

void destroyGeneral(GeneralNode *root)
{
    if (root == NULL) {
        return;
    }
    GeneralNode *child = root->child;
    while (child != NULL) {
        GeneralNode *next = child->sibling;
        destroyGeneral(child);
        child = next;
    }
    free(root);
}

/* Main logic
 * Give root 1 three children. Print the general tree in preorder, then release it. This is a general linked tree, not a binary tree.
 */

int main(void)
{
    GeneralNode *root = newGeneralNode(1);
    GeneralNode *child = newGeneralNode(2);
    appendChild(root, child);
    child = newGeneralNode(3);
    appendChild(root, child);
    child = newGeneralNode(4);
    appendChild(root, child);
    generalPreorder(root);
    putchar('\n');
    destroyGeneral(root);
    return 0;
}
