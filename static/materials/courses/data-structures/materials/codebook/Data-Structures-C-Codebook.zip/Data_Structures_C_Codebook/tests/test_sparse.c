#include <assert.h>
#define main demo_main
#include "05_sparse.c"
#undef main

int main(void)
{
    srand(21);
    for(int trial=0;trial<500;trial++) {
        Sparse a={0}; a.rows=8; a.columns=9;
        for(int i=0;i<8;i++) for(int j=0;j<9;j++) {
            if(rand()%4==0) { Term t={i,j,1+rand()%9}; a.terms[a.count++]=t; }
        }
        Sparse slow=simpleTranspose(&a),fast=fastTranspose(&a);
        assert(slow.count==fast.count);
        for(int i=0;i<fast.count;i++) {
            assert(slow.terms[i].row==fast.terms[i].row);
            assert(slow.terms[i].column==fast.terms[i].column);
            assert(slow.terms[i].value==fast.terms[i].value);
        }
        Sparse twice=fastTranspose(&fast);
        for(int i=0;i<a.count;i++) {
            assert(a.terms[i].row==twice.terms[i].row);
            assert(a.terms[i].column==twice.terms[i].column);
            assert(a.terms[i].value==twice.terms[i].value);
        }
    }
    return 0;
}
