/* Polynomial main
 * Reuse polynomial.h. The complete main below shows the operation sequence.
 */

/* Main logic
 * Build 3x^2+2 and -3x^2+4x. Addition should cancel the squared terms. Multiplication should combine its repeated x^2 power through addTerm.
 */

/* Reuse the polynomial types and operations already covered. */
#include "polynomial.h"
int main(void)
{
    PolyTerm *first = newPolynomial();
    PolyTerm *second = newPolynomial();
    addTerm(first, 3, 2);
    addTerm(first, 2, 0);
    addTerm(second, -3, 2);
    addTerm(second, 4, 1);
    PolyTerm *sum = addPolynomials(first, second);
    PolyTerm *product = multiplyPolynomials(first, second);
    printPolynomial(sum);
    printPolynomial(product);
    destroyPolynomial(first);
    destroyPolynomial(second);
    destroyPolynomial(sum);
    destroyPolynomial(product);
    return 0;
}
