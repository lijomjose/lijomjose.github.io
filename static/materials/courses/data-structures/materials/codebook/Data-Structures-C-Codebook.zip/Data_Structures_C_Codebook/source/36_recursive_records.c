/* Recursive sorting searching and record checks
 * The tutorial PPT applies recursion to student records. The linking and sorting ideas stay the same when the stored value becomes a structure. Use small records so their totals fit int. No structure comparison with == is used.
 */

/* Group fields and calculate derived totals
 * Each record owns three marks. The name points to a fixed string in this demo. Recalculate total and average after changing marks.
 */

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct {
    int roll;
    const char *name;
    int marks[3];
    int total;
    double average;
} Record;
void updateRecord(Record *record)
{
    record->total = 0;
    for (int i = 0; i < 3; i++) {
        record->total = record->total + record->marks[i];
    }
    record->average = record->total / 3.0;
}

/* Swap complete records through pointers
 * Moving only the roll number would attach the wrong name and marks to it. Move the complete structure.
 */

void swapRecords(Record *first, Record *second)
{
    Record temporary = *first;
    *first = *second;
    *second = temporary;
}

/* Recursive bubble sort finishes one suffix position
 * Perform one ordinary bubble pass, then recurse on count-1. If no swap happens, the entire array is sorted. This replaces the outer loop with recursion; it does not reduce the worst-case comparison count.
 */

void recursiveRecordBubble(Record records[], int count)
{
    if (count < 2) {
        return;
    }
    bool changed = false;
    for (int i = 0; i < count - 1; i++) {
        if ((records + i)->roll > (records + i + 1)->roll) {
            swapRecords(records + i, records + i + 1);
            changed = true;
        }
    }
    if (changed) {
        recursiveRecordBubble(records, count - 1);
    }
}

/* Recursive binary search uses sorted roll numbers
 * Do this before sorting by average. Once a different field determines order, binary search by roll no longer has its required ordering.
 */

int recursiveRecordSearch(const Record records[], int low, int high, int roll)
{
    if (low > high) {
        return -1;
    }
    int middle = low + (high - low) / 2;
    if (records[middle].roll == roll) {
        return middle;
    }
    if (roll < records[middle].roll) {
        return recursiveRecordSearch(records, low, middle - 1, roll);
    }
    return recursiveRecordSearch(records, middle + 1, high, roll);
}

/* Recursive insertion sort orders averages from high to low
 * First sort the shorter prefix, then insert the final saved record into that sorted prefix. Shift lower averages right. Equal averages do not cross.
 */

void recursiveRecordInsertion(Record records[], int count)
{
    if (count < 2) {
        return;
    }
    recursiveRecordInsertion(records, count - 1);
    Record key = records[count - 1];
    int left = count - 2;
    while (left >= 0 && records[left].average < key.average) {
        records[left + 1] = records[left];
        left--;
    }
    records[left + 1] = key;
}

/* Recursively count records passing every subject
 * A student passes only if all three marks are at least 40. Add one or zero to the answer from the shorter suffix.
 */

int countPassed(const Record records[], int count)
{
    if (count == 0) {
        return 0;
    }
    bool passed = true;
    for (int i = 0; i < 3; i++) {
        if (records[0].marks[i] < 40) {
            passed = false;
        }
    }
    int rest = countPassed(records + 1, count - 1);
    if (passed) {
        return rest + 1;
    }
    return rest;
}

/* Main logic
 * Update totals, sort by roll, search by roll, then sort by average. The search result is used before the second sort changes positions.
 */

int main(void)
{
    Record records[] = {{3,"C",{70,80,90},0,0},
                        {1,"A",{30,90,90},0,0},
                        {2,"B",{95,85,90},0,0}};
    for (int i = 0; i < 3; i++) {
        updateRecord(&records[i]);
    }
    recursiveRecordBubble(records, 3);
    int index = recursiveRecordSearch(records, 0, 2, 2);
    printf("Roll 2 index: %d Passed all subjects: %d\n",
           index, countPassed(records, 3));
    recursiveRecordInsertion(records, 3);
    for (int i = 0; i < 3; i++) {
        printf("%s roll %d average %.2f\n",
               records[i].name, records[i].roll, records[i].average);
    }
    return 0;
}
