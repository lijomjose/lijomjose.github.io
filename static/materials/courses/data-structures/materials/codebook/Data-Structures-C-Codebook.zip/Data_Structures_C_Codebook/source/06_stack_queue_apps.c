/* Use the doors without rebuilding them
 * We now consume the interfaces. Queue applications call enqueue and dequeue. Stack applications call push and pop. Those operations were already explained; embedding their implementation inside every new algorithm would make both ideas harder to see.
 */

/* Bracket types must agree
 * When a closing bracket arrives, the most recent unmatched opener must match it. Matching counts alone cannot distinguish ([)] from ([]). Ignore nonbracket characters.
 */

/* Reuse the earlier array stack type and its operations. */
#include "int_stack.h"
/* Reuse the circular array queue: IntQueue, initQueue, enqueue and dequeue. */
#include "int_queue.h"
bool matchingPair(int open, int close)
{
    if (open == '(' && close == ')') {
        return true;
    }
    if (open == '[' && close == ']') {
        return true;
    }
    if (open == '{' && close == '}') {
        return true;
    }
    return false;
}

/* Validation uses a stack of unfinished openings
 * Push openings. On a closing bracket, reject an empty stack or mismatched type. The final empty test catches extra openings. Stack overflow is also reported as rejection in this bounded demo.
 */

bool bracketsBalanced(const char text[])
{
    IntStack stack;
    initStack(&stack);
    for (int i = 0; text[i] != '\0'; i++) {
        char ch = text[i];
        if (ch == '(' || ch == '[' || ch == '{') {
            bool stored = push(&stack, ch);
            if (stored == false) {
                return false;
            }
        } else if (ch == ')' || ch == ']' || ch == '}') {
            int opening;
            bool found = pop(&stack, &opening);
            if (found == false) {
                return false;
            }
            bool matches = matchingPair(opening, ch);
            if (matches == false) {
                return false;
            }
        }
    }
    return stack.top == -1;
}

/* Two stacks can share the same array
 * The left stack grows from -1 upward and the right stack from CAPACITY downward. The common overflow condition is that their tops are adjacent. Unlike a fixed half-and-half partition, either stack can borrow all free slots.
 */

typedef struct {
    int items[CAPACITY];
    int leftTop;
    int rightTop;
} TwoStacks;
void initTwoStacks(TwoStacks *stacks)
{
    stacks->leftTop = -1;
    stacks->rightTop = CAPACITY;
}

/* A shared push chooses its growth direction
 * Validate which stack is requested, then check the shared free region. Labels 0 and 1 identify left and right.
 */

bool sharedPush(TwoStacks *stacks, int which, int value)
{
    if (which != 0 && which != 1) {
        return false;
    }
    if (stacks->leftTop + 1 == stacks->rightTop) {
        return false;
    }
    if (which == 0) {
        stacks->leftTop++;
        stacks->items[stacks->leftTop] = value;
    } else {
        stacks->rightTop--;
        stacks->items[stacks->rightTop] = value;
    }
    return true;
}

/* A shared pop checks the selected empty boundary
 * The right stack becomes emptier by increasing its top. This is a useful reminder that top describes a logical role; it need not always increase on push.
 */

bool sharedPop(TwoStacks *stacks, int which, int *value)
{
    if (which == 0) {
        if (stacks->leftTop == -1) {
            return false;
        }
        *value = stacks->items[stacks->leftTop];
        stacks->leftTop--;
    } else if (which == 1) {
        if (stacks->rightTop == CAPACITY) {
            return false;
        }
        *value = stacks->items[stacks->rightTop];
        stacks->rightTop++;
    } else {
        return false;
    }
    return true;
}

/* Main logic
 * Demonstrate LIFO validation, FIFO service, deque access, and shared storage. Each call visibly precedes its status check.
 */

int main(void)
{
    printf("Balanced: %d\n", bracketsBalanced("{[a+(b*c)]}"));
    printf("Crossed: %d\n", bracketsBalanced("([)]"));
    IntQueue queue;
    initQueue(&queue);
    bool ok = enqueue(&queue, 10);
    if (ok == false) {
        return 1;
    }
    ok = enqueue(&queue, 20);
    if (ok == false) {
        return 1;
    }
    int value;
    ok = dequeue(&queue, &value);
    if (ok) {
        printf("First served: %d\n", value);
    }
    ok = pushFront(&queue, 5);
    if (ok == false) {
        return 1;
    }
    ok = popRear(&queue, &value);
    if (ok) {
        printf("Rear removed: %d\n", value);
    }
    TwoStacks stacks;
    initTwoStacks(&stacks);
    ok = sharedPush(&stacks, 0, 40);
    if (ok == false) {
        return 1;
    }
    ok = sharedPush(&stacks, 1, 90);
    if (ok == false) {
        return 1;
    }
    ok = sharedPop(&stacks, 1, &value);
    if (ok) {
        printf("Right stack: %d\n", value);
    }
    return 0;
}
