/* Threads on both sides with a header
 * This matches the two-thread-flag representation in the official PPT. A missing left child threads to the inorder predecessor. A missing right child threads to the successor. The header is the boundary marker and owns the real root through left.
 */

/* Create the header
 * An empty header has a left thread to itself. Its right link points to itself and is tagged as a child link by this convention. For a nonempty tree, header.left becomes the root and leftThread becomes false.
 */

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct FNode {
    int value;
    struct FNode *left;
    struct FNode *right;
    bool leftThread;
    bool rightThread;
} FNode;
FNode *newThreadHeader(void)
{
    FNode *header = allocate(sizeof *header);
    header->value = 0;
    header->left = header;
    header->right = header;
    header->leftThread = true;
    header->rightThread = false;
    return header;
}

/* Create one threaded leaf
 * Its left and right routes initially represent predecessor and successor, not children.
 */

FNode *newFullyThreaded(int value, FNode *predecessor, FNode *successor)
{
    FNode *node = allocate(sizeof *node);
    node->value = value;
    node->left = predecessor;
    node->right = successor;
    node->leftThread = true;
    node->rightThread = true;
    return node;
}

/* Find the inorder successor
 * Follow a right thread directly. With a real right child, enter it and follow only real left children. Applied to the header, this finds the first node or returns the header if empty.
 */

FNode *fullSuccessor(FNode *node)
{
    FNode *next = node->right;
    if (node->rightThread == false) {
        while (next->leftThread == false) {
            next = next->left;
        }
    }
    return next;
}

/* Find the inorder predecessor
 * The same rule works backward: use a left thread or the rightmost node of a real left subtree.
 */

FNode *fullPredecessor(FNode *node)
{
    FNode *previous = node->left;
    if (node->leftThread == false) {
        while (previous->rightThread == false) {
            previous = previous->right;
        }
    }
    return previous;
}

/* Insert a new key where a search reaches a thread
 * Use BST comparisons to locate a missing child. A left insertion inherits the parent's predecessor and threads right to the parent. A right insertion inherits the successor and threads left to the parent. Duplicate keys return the existing node.
 */

FNode *fullInsert(FNode *header, int value)
{
    if (header->leftThread) {
        FNode *node = newFullyThreaded(value, header, header);
        header->left = node;
        header->leftThread = false;
        return node;
    }
    FNode *current = header->left;
    while (true) {
        if (value == current->value) {
            return current;
        }
        if (value < current->value) {
            if (current->leftThread) {
                FNode *node = newFullyThreaded(value, current->left, current);
                current->left = node;
                current->leftThread = false;
                return node;
            }
            current = current->left;
        } else {
            if (current->rightThread) {
                FNode *node = newFullyThreaded(value, current, current->right);
                current->right = node;
                current->rightThread = false;
                return node;
            }
            current = current->right;
        }
    }
}

/* Insert as a right child even when a subtree exists
 * This is the special threaded insertion shown in the PPT. The new node inherits the old right subtree. If that subtree exists, its leftmost node's predecessor thread must now point to the new node. The caller must choose a value that preserves ordering if this is a BST.
 */

FNode *insertRightOf(FNode *parent, int value)
{
    FNode *node = newFullyThreaded(value, parent, parent->right);
    if (parent->rightThread == false) {
        node->rightThread = false;
        FNode *oldSuccessor = parent->right;
        while (oldSuccessor->leftThread == false) {
            oldSuccessor = oldSuccessor->left;
        }
        oldSuccessor->left = node;
    }
    parent->right = node;
    parent->rightThread = false;
    return node;
}

/* Traverse forward or backward without a stack
 * Start at the header and ask for successor or predecessor. Stop when the header returns. Never print it as a data node.
 */

void printFullyThreaded(FNode *header, bool backward)
{
    FNode *current = header;
    while (true) {
        if (backward) {
            current = fullPredecessor(current);
        } else {
            current = fullSuccessor(current);
        }
        if (current == header) {
            break;
        }
        printf("%d ", current->value);
    }
    putchar('\n');
}

/* Cleanup computes the next route before freeing
 * Use inorder successors to free every real node once, then free the header. Do not treat threads as ordinary recursive child routes.
 */

void destroyFullyThreaded(FNode *header)
{
    FNode *current = fullSuccessor(header);
    while (current != header) {
        FNode *next = fullSuccessor(current);
        free(current);
        current = next;
    }
    free(header);
}

/* Display all predecessor and successor threads
 * Walk real nodes in inorder. Print only links tagged as threads. A boundary thread prints HEADER instead of the header's unused value.
 */

void displayThreads(FNode *header)
{
    FNode *current = fullSuccessor(header);
    while (current != header) {
        if (current->leftThread) {
            printf("%d left thread -> ", current->value);
            if (current->left == header) {
                puts("HEADER");
            } else {
                printf("%d\n", current->left->value);
            }
        }
        if (current->rightThread) {
            printf("%d right thread -> ", current->value);
            if (current->right == header) {
                puts("HEADER");
            } else {
                printf("%d\n", current->right->value);
            }
        }
        current = fullSuccessor(current);
    }
}

/* Main logic
 * Build 20,10,30,25. Insert 22 between 20 and its old right subtree. The predecessor thread at 25 must change from 20 to 22. Verify both traversal directions.
 */

int main(void)
{
    FNode *header = newThreadHeader();
    FNode *twenty = fullInsert(header, 20);
    fullInsert(header, 10);
    fullInsert(header, 30);
    fullInsert(header, 25);
    insertRightOf(twenty, 22);
    printFullyThreaded(header, false);
    printFullyThreaded(header, true);
    displayThreads(header);
    destroyFullyThreaded(header);
    return 0;
}
