# The Dragon Scroll of Data Structures

Lijo M. Jose | CES 2101 and CES 2111

The PDF is the complete reference. The HTML edition has clickable chapter navigation; the Markdown edition is editable plain text. Every function is preceded by a short explanation, with answered reasoning questions and small traces.

## Build one example

Keep all files in source/ together. Each numbered .c file is a separate program with its own main. Do not link every .c file into a single executable.

```sh
cd source
gcc -std=c11 -Wall -Wextra -Wpedantic 03_search_sort.c -lm -o demo
./demo
```

Use GCC or a C11-compatible compiler. Windows users can use a GCC-based C project and add the relevant .c file and its headers. There is no dependence on graphics libraries or nonstandard console headers.

21_records.c reads two single-word-name records. Example input:

```text
Caitlyn 1 80 90
Rose 2 95 88
```

Other main functions use fixed small examples. Change those values to explore cases. Header functions are shared by the demos; a header is not a standalone executable. These small demos keep implementations in headers to make each example build with one command.

## Files

- The_Dragon_Scroll_of_Data_Structures.pdf: complete codebook with clickable contents.
- The_Dragon_Scroll_of_Data_Structures.html: readable browser edition.
- The_Dragon_Scroll_of_Data_Structures.md: editable text edition.
- The_Dragon_Scroll_of_Data_Structures.tex: typesetting source for the PDF.
- Coverage_Checklist.md: official slide-to-code and syllabus mapping.
- source/: 41 runnable C examples and 15 shared headers.
- tests/: independent developer verification harnesses; these are not the student-facing coding style.
- Verification.md: validation scope and limits.
- Example_Output.txt: output from all 41 demo programs.

## Start with the simple array versions

- source/40_array_binary_tree.c: an ordinary array binary tree; no custom headers.
- source/41_array_graph.c: int graph[MAX][MAX]; BFS reuses int_queue.h from the queue chapter.
- source/35_tree_representations.c: the separate first-child/next-sibling general tree.

course_common.h is a convenience header supplied here, not a C language requirement. If putting an example into one C file, copy the declarations/functions it needs above the new code. Do not paste another main. Header guards prevent duplicate inclusion; the new code comments explain them.

The PDF cover uses assets/panda_ink.png. To rebuild the PDF from the packaged TeX, run pdflatex twice from this folder with a suitable LaTeX installation.

## Source index

| File | Topic |
| --- | --- |
| 01_memory.c | Directions are not the destination |
| 02_recursion.c | A smaller problem must actually be smaller |
| 03_search_sort.c | Searching and sorting main |
| 04_strings.c | The terminator is part of the storage bill |
| 05_sparse.c | Do not rent a room for every zero |
| 06_stack_queue_apps.c | Use the doors without rebuilding them |
| 07_priority_queue.c | Priority queue main |
| 08_linked_apps.c | A stack and queue are now small wrappers |
| 09_doubly_circular.c | More links buy different shortcuts |
| 10_circular_singly.c | Circular singly linked list main |
| 11_polynomials.c | Polynomial main |
| 12_expressions.c | Expression main |
| 13_trees.c | Visit the tree before trusting a shortcut |
| 14_binary_delete.c | Deletion without a search ordering rule |
| 15_threaded_tree.c | Use an unused route to remember the next visit |
| 16_avl.c | AVL main |
| 17_graphs.c | Graph traversal main |
| 18_red_black.c | Track the color removed from the old position |
| 19_arrays_recursion.c | Array operations and the recursive versions |
| 20_dynamic_tables.c | Dynamic table main |
| 21_records.c | Structures arrays of structures and returned pointers |
| 22_sparse_linked.c | Sparse matrices as a linked list |
| 23_more_sll.c | Count concatenate split and remove the rear |
| 24_linear_dll.c | A linear doubly linked list |
| 25_circle_variants.c | First only and last only circular lists |
| 26_more_polynomials.c | Singly linked circular and linear DLL polynomials |
| 27_duplicate_parentheses.c | Detect duplicate parentheses |
| 28_multiple_stacks.c | Several stacks inside one array |
| 29_queue_variants.c | Linear queues multiple queues and restricted deques |
| 30_priority_variants.c | Unsorted priorities min max and peek |
| 31_heap_priority.c | A heap as another priority queue representation |
| 32_more_tree_operations.c | Recursive creation search and iterative traversals |
| 33_fully_threaded.c | Threads on both sides with a header |
| 34_graph_connectivity.c | Connectivity components and spanning forests |
| 35_tree_representations.c | General Tree with First Child and Next Sibling Links |
| 36_recursive_records.c | Recursive sorting searching and record checks |
| 37_recursive_lists.c | Recursive creation and traversal of a chain |
| 38_pointer_matrix_apps.c | Pointer and matrix applications from the PPTs |
| 39_tree_priority.c | A balanced tree priority queue using earlier operations |
| 40_array_binary_tree.c | Array Binary Tree: Storage and Traversals |
| 41_array_graph.c | Adjacency Matrix Graph: Array Only DFS and BFS |
| array_algorithms.h | Same result different bills |
| avl.h | A BST that notices when one side grows too tall |
| circle.h | A circle does not require two directions |
| dynamic_rows.h | Rectangular and ragged tables |
| expressions.h | Make the rules visible before converting |
| graph.h | Keep traversal separate from queue mechanics |
| int_queue.h | A queue that reuses vacated slots |
| int_stack.h | A stack with a visible top |
| polynomial.h | Keep the powers that actually exist |
| priority.h | Urgency changes the leaving order |
| slist.h | One singly linked list many uses |
| tree.h | Shared tree operations |
| tree_queue.h | Reuse the queue rule with a different payload |
| tree_stack.h | A tree pointer stack for iterative traversals |
