/* Urgency changes the leaving order
 * A hospital queue cannot always serve by arrival time alone. Here a smaller priority number means greater urgency. Equal-priority patients keep arrival order. We use a sorted array so removal is cheap; that choice makes insertion more expensive.
 */

/* Store a patient record
 * The name points to a string literal in these demos, so this queue does not own or free the name. The most urgent patient is kept at the highest occupied index.
 */

/* Header guard: include these declarations only once in this C file. */
#ifndef COURSE_PRIORITY_H
/* Remember that this header has already been included. */
#define COURSE_PRIORITY_H
/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct {
    const char *name;
    int priority;
} Patient;
typedef struct {
    Patient items[CAPACITY];
    int count;
} PriorityQueue;

/* Insert while preserving the removal order
 * Shift more urgent existing patients right. Shift equal-priority patients too, so the older patient remains farther right and leaves first. Store the new record in the gap.
 */

bool admit(PriorityQueue *queue, Patient patient)
{
    if (queue->count == CAPACITY) {
        return false;
    }
    int i = queue->count - 1;
    while (i >= 0 && queue->items[i].priority <= patient.priority) {
        queue->items[i + 1] = queue->items[i];
        i--;
    }
    queue->items[i + 1] = patient;
    queue->count++;
    return true;
}

/* Serve from the ready end
 * The most urgent, oldest eligible patient is already at count-1. Copy the record and reduce count. The queue does not have to scan for a winner at service time.
 */

bool serve(PriorityQueue *queue, Patient *patient)
{
    if (queue->count == 0) {
        return false;
    }
    queue->count--;
    *patient = queue->items[queue->count];
    return true;
}
#endif /* End of this header guard. */
