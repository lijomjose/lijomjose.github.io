#include <assert.h>
#define main demo_main
#include "10_circular_singly.c"
#undef main

int main(void) {
 Circle c={NULL,NULL};int v=99;assert(circleRemoveRear(&c,&v)==false && v==99);
 for(int i=0;i<40;i++) {circleInsert(&c,i,false);assert(c.last->next==c.first);}
 for(int i=39;i>=0;i--) {assert(circleRemoveRear(&c,&v));assert(v==i);if(c.first)assert(c.last->next==c.first);}
 assert(!c.first && !c.last);
 for(int i=0;i<40;i++)circleInsert(&c,i,true);
 for(int i=39;i>=0;i--){assert(circleRemoveFront(&c,&v));assert(v==i);}
 return 0;
}
