/* Directions are not the destination
 * We want a function to change a caller-owned integer, then a caller-owned pointer. These are different requests. The first needs int *. The second needs int **. C still copies every argument value, including addresses.
 */

/* Change the object
 * damage receives a copied address. Following that address with * reaches the original health. Assigning health = NULL would only change the local route.
 */

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
void damage(int *health, int amount)
{
    *health = *health - amount;
}

/* Change the route
 * createInventory receives the address of the caller's pointer. It allocates count integers with calloc so the initial integer values are zero. The caller must supply count from 1 to 1000. We check that range before calculating a size.
 */

bool createInventory(int **inventory, int count)
{
    if (count < 1 || count > 1000) {
        return false;
    }
    int *memory = calloc((size_t)count, sizeof *memory);
    if (memory == NULL) {
        return false;
    }
    *inventory = memory;
    return true;
}

/* Grow without losing the old route
 * realloc may move the block. Store its result in a temporary pointer. If it fails, the original allocation remains owned by the caller. Newly added positions are not initialized by realloc.
 */

bool resizeInventory(int **inventory, int count)
{
    if (count < 1 || count > 1000) {
        return false;
    }
    int *replacement = realloc(*inventory,
                              (size_t)count * sizeof **inventory);
    if (replacement == NULL) {
        return false;
    }
    *inventory = replacement;
    return true;
}

/* Main logic
 * First change the health object. Then create three slots, fill them through pointer arithmetic, resize to five, initialize the added slots, and release the allocation exactly once. The array of pointers stores two routes, not two copied integers. typedef gives a type another name; enum gives named integer choices.
 */

typedef enum { KNIGHT, MAGE } Role;
typedef struct {
    const char *name;
    Role role;
    int health;
} Hero;

int main(void)
{
    Hero hero = {"Caitlyn", KNIGHT, 100};
    damage(&hero.health, 20);
    printf("Health: %d\n", hero.health);
    int *inventory = NULL;
    bool created = createInventory(&inventory, 3);
    if (created == false) {
        return EXIT_FAILURE;
    }
    for (int i = 0; i < 3; i++) {
        *(inventory + i) = (i + 1) * 10;
    }
    bool resized = resizeInventory(&inventory, 5);
    if (resized == false) {
        free(inventory);
        return EXIT_FAILURE;
    }
    inventory[3] = 40;
    inventory[4] = 50;
    int *routes[2] = {&inventory[0], &inventory[4]};
    printf("First: %d Last: %d\n", *routes[0], *routes[1]);
    free(inventory);
    inventory = NULL;
    return 0;
}
