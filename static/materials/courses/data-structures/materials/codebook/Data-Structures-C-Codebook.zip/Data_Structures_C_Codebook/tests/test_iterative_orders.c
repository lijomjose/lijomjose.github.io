#include <assert.h>
#define main demo_main
#include "32_more_tree_operations.c"
#undef main

int main(void){
 srand(95);
 for(int trial=0;trial<80;trial++){
  Tree *r=NULL;for(int i=0;i<80;i++)r=bstInsert(r,rand()%500);
  preorder(r);putchar('\n');iterativePreorder(r);inorder(r);putchar('\n');iterativeInorder(r);postorder(r);putchar('\n');iterativePostorder(r);destroyTree(r);
 }
 const TreeToken invalid[]={{true,1},{false,0}};int pos=0;bool valid=true;Tree *r=buildFromTokens(invalid,2,&pos,&valid);assert(!valid&&r==NULL);
 return 0;
}
