/* Expression main
 * Reuse expressions.h. The complete main below shows the operation sequence.
 */

/* Main logic
 * Convert infix, build its tree, and print three orders. Then evaluate a decimal postfix expression and its prefix equivalent. This separates symbolic conversion from numeric token parsing; a student can learn one without guessing the other's input format.
 */

/* Reuse the expression conversion and evaluation helpers. */
#include "expressions.h"
int main(void)
{
    char postfix[CAPACITY];
    bool ok = infixToPostfix("a+b*c^d^e", postfix, sizeof postfix);
    if (ok == false) {
        puts("Invalid infix expression");
        return 1;
    }
    printf("Postfix: %s\n", postfix);
    Expression tree;
    ok = treeFromPostfix(postfix, &tree);
    if (ok == false) {
        return 1;
    }
    printf("Prefix: ");
    printPrefix(&tree, tree.root);
    putchar('\n');
    printf("Infix: ");
    printInfix(&tree, tree.root);
    putchar('\n');
    ok = treeFromPrefix("+a*bc", &tree);
    if (ok == false) {
        return 1;
    }
    printf("Prefix converted to postfix: ");
    printPostfix(&tree, tree.root);
    putchar('\n');
    double answer;
    ok = evaluate("12.5 2 3 * +", false, &answer);
    if (ok) {
        printf("Postfix value: %.2f\n", answer);
    }
    ok = evaluate("+ 12.5 * 2 3", true, &answer);
    if (ok) {
        printf("Prefix value: %.2f\n", answer);
    }
    return 0;
}
