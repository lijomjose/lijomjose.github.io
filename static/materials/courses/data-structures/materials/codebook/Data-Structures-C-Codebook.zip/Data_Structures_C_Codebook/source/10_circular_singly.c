/* Circular singly linked list main
 * Reuse circle.h. The complete main below shows the operation sequence.
 */

/* Main logic
 * Build a three-node ring, remove the rear once, then drain from the front. Never pass a circular list to clearList: that helper expects a NULL-terminated chain.
 */

/* Reuse the circular singly linked list types and operations. */
#include "circle.h"
int main(void)
{
    Circle circle = {NULL, NULL};
    circleInsert(&circle, 20, false);
    circleInsert(&circle, 10, true);
    circleInsert(&circle, 30, false);
    printCircle(&circle);
    int value;
    bool ok = circleRemoveRear(&circle, &value);
    if (ok) {
        printf("Rear: %d\n", value);
    }
    while (circle.first != NULL) {
        circleRemoveFront(&circle, &value);
    }
    printCircle(&circle);
    return 0;
}
