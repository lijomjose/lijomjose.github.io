#include <assert.h>
#define main demo_main
#include "25_circle_variants.c"
#undef main

int main(void){
 Node *f=NULL,*l=NULL;int v;
 for(int i=0;i<80;i++){insertFirstOnly(&f,i,false);insertLastOnly(&l,i,false);}
 for(int i=79;i>=0;i--){assert(removeFirstOnly(&f,false,&v)&&v==i);assert(removeLastOnly(&l,false,&v)&&v==i);}
 assert(!f&&!l);assert(!removeFirstOnly(&f,true,&v));assert(!removeLastOnly(&l,true,&v));
 for(int i=0;i<80;i++){insertFirstOnly(&f,i,true);insertLastOnly(&l,i,true);}
 for(int i=79;i>=0;i--){assert(removeFirstOnly(&f,true,&v)&&v==i);assert(removeLastOnly(&l,true,&v)&&v==i);}
 return 0;
}
