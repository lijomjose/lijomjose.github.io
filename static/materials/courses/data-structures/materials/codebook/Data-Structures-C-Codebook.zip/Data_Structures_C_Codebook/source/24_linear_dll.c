/* A linear doubly linked list
 * The PPT uses a NULL-terminated DLL as well as circular lists. We keep head and tail. One insert-before helper handles both ends and the middle; one remove-known helper handles every deletion.
 */

/* Define a linear DLL
 * Both endpoints are NULL when empty. A real first node has previous=NULL; a real last node has next=NULL.
 */

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct DLink {
    int value;
    struct DLink *previous;
    struct DLink *next;
} DLink;
typedef struct {
    DLink *head;
    DLink *tail;
} DList;

/* Find a position
 * A negative or missing position returns NULL. Search costs O(n); already knowing a node is different from having to find it.
 */

DLink *dNodeAt(const DList *list, int index)
{
    if (index < 0) {
        return NULL;
    }
    DLink *current = list->head;
    for (int i = 0; i < index && current != NULL; i++) {
        current = current->next;
    }
    return current;
}

/* Insert before a known node or at the rear
 * position=NULL means append. Otherwise position must belong to this list. Link both directions, updating head or tail when a neighbor is absent.
 */

void dInsertBefore(DList *list, DLink *position, int value)
{
    DLink *left = list->tail;
    if (position != NULL) {
        left = position->previous;
    }
    DLink *node = allocate(sizeof *node);
    node->value = value;
    node->previous = left;
    node->next = position;
    if (left == NULL) {
        list->head = node;
    } else {
        left->next = node;
    }
    if (position == NULL) {
        list->tail = node;
    } else {
        position->previous = node;
    }
}

/* Insert at an index using the same helper
 * Index zero means front. At another index, find its predecessor. Inserting just after the current last node is allowed.
 */

bool dInsertAt(DList *list, int index, int value)
{
    if (index < 0) {
        return false;
    }
    if (index == 0) {
        dInsertBefore(list, list->head, value);
        return true;
    }
    DLink *previous = dNodeAt(list, index - 1);
    if (previous == NULL) {
        return false;
    }
    dInsertBefore(list, previous->next, value);
    return true;
}

/* Remove one known real node
 * Before calling: node belongs to this list. Repair each neighbor or endpoint before freeing the node. The singleton case naturally clears both endpoints.
 */

void dRemoveKnown(DList *list, DLink *node, int *value)
{
    *value = node->value;
    if (node->previous == NULL) {
        list->head = node->next;
    } else {
        node->previous->next = node->next;
    }
    if (node->next == NULL) {
        list->tail = node->previous;
    } else {
        node->next->previous = node->previous;
    }
    free(node);
}

/* Delete at an index after locating the node
 * The search pays O(n). The actual unlink pays O(1). Front or rear deletion can call dRemoveKnown directly when that endpoint is non-NULL.
 */

bool dRemoveAt(DList *list, int index, int *value)
{
    DLink *node = dNodeAt(list, index);
    if (node == NULL) {
        return false;
    }
    dRemoveKnown(list, node, value);
    return true;
}

/* Search a value
 * Follow next until a match or NULL. Return a borrowed route.
 */

DLink *dFind(const DList *list, int value)
{
    DLink *current = list->head;
    while (current != NULL) {
        if (current->value == value) {
            return current;
        }
        current = current->next;
    }
    return NULL;
}

/* Display forward or backward
 * Choose the starting endpoint once, then follow the corresponding link. No reversal of the actual list is needed.
 */

void dDisplay(const DList *list, bool backward)
{
    const DLink *current = list->head;
    if (backward) {
        current = list->tail;
    }
    while (current != NULL) {
        printf("%d ", current->value);
        if (backward) {
            current = current->previous;
        } else {
            current = current->next;
        }
    }
    putchar('\n');
}

/* Count real nodes
 * A linear DLL still needs a walk to count unless its container stores and maintains a count field.
 */

int dCount(const DList *list)
{
    int count = 0;
    for (const DLink *p = list->head; p != NULL; p = p->next) {
        count++;
    }
    return count;
}

/* Concatenate and transfer ownership
 * Before calling: distinct disjoint lists. Join first.tail to second.head in both directions, then empty the second container.
 */

void dConcatenate(DList *first, DList *second)
{
    if (second->head == NULL) {
        return;
    }
    if (first->tail == NULL) {
        first->head = second->head;
    } else {
        first->tail->next = second->head;
        second->head->previous = first->tail;
    }
    first->tail = second->tail;
    second->head = NULL;
    second->tail = NULL;
}

/* Cleanup reuses known node deletion
 * Delete the current head until empty. Both endpoints finish NULL.
 */

void dClear(DList *list)
{
    while (list->head != NULL) {
        int discarded;
        dRemoveKnown(list, list->head, &discarded);
    }
}

/* Main logic
 * Exercise front, rear, and middle insertion, both display directions, search, positional deletion, rear deletion, counting, and concatenation.
 */

int main(void)
{
    DList first = {NULL, NULL};
    DList second = {NULL, NULL};
    dInsertBefore(&first, NULL, 20);
    dInsertBefore(&first, first.head, 10);
    bool ok = dInsertAt(&first, 1, 15);
    if (ok == false) {
        return 1;
    }
    dDisplay(&first, false);
    dDisplay(&first, true);
    DLink *found = dFind(&first, 15);
    printf("Found: %d\n", found != NULL);
    int value;
    ok = dRemoveAt(&first, 1, &value);
    if (ok == false) {
        return 1;
    }
    dRemoveKnown(&first, first.tail, &value);
    dInsertBefore(&second, NULL, 30);
    dConcatenate(&first, &second);
    printf("Count: %d\n", dCount(&first));
    dDisplay(&first, false);
    dClear(&first);
    dClear(&second);
    return 0;
}
