/* More links buy different shortcuts
 * A doubly linked node has a previous route as well as a next route. A circular list replaces the NULL ending with a route back to the start. We use a circular doubly linked list with a permanent header, so an empty list has header.next==header and header.prev==header.
 */

/* Create the header
 * The header carries no user value. It gives the first and last real nodes a valid neighbor even at the boundaries. Return a separately allocated header so its lifetime outlasts this function.
 */

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct DNode {
    int value;
    struct DNode *previous;
    struct DNode *next;
} DNode;
DNode *createHeader(void)
{
    DNode *header = allocate(sizeof *header);
    header->value = 0;
    header->previous = header;
    header->next = header;
    return header;
}

/* Insert between known neighbors
 * Precondition: left and right are adjacent nodes in the same list. Fill both routes of the new node, then make both neighbors acknowledge it. One direction alone is not a valid doubly linked insertion.
 */

void insertBetween(DNode *left, DNode *right, int value)
{
    DNode *node = allocate(sizeof *node);
    node->value = value;
    node->previous = left;
    node->next = right;
    left->next = node;
    right->previous = node;
}

/* Remove a known real node
 * Precondition: node belongs to this list and is not the header. Its two neighbors can bypass it in O(1), including when it is the only real node. Searching for the node is a separate cost.
 */

void removeKnown(DNode *node)
{
    DNode *left = node->previous;
    DNode *right = node->next;
    left->next = right;
    right->previous = left;
    free(node);
}

/* Traverse until the header returns
 * Do not test current!=NULL in a circular list: there is no NULL ending. Stop before processing the header again.
 */

void printCircular(const DNode *header)
{
    const DNode *current = header->next;
    while (current != header) {
        printf("%d ", current->value);
        current = current->next;
    }
    putchar('\n');
}

/* Walk backward through previous
 * The last real node is header.previous. The same stopping rule works in reverse.
 */

void printBackward(const DNode *header)
{
    const DNode *current = header->previous;
    while (current != header) {
        printf("%d ", current->value);
        current = current->previous;
    }
    putchar('\n');
}

/* Concatenate by transferring ownership
 * Precondition: distinct valid headers. Attach the second list's real nodes after the first list's tail, then reconnect to the first header. Reset the second header to an empty ring. We do not copy nodes.
 */

void concatenate(DNode *first, DNode *second)
{
    if (second->next == second) {
        return;
    }
    DNode *aLast = first->previous;
    DNode *bFirst = second->next;
    DNode *bLast = second->previous;
    aLast->next = bFirst;
    bFirst->previous = aLast;
    bLast->next = first;
    first->previous = bLast;
    second->next = second;
    second->previous = second;
}

/* Destroy nodes before destroying the header
 * Repeatedly remove the first real node. Only after the ring is empty do we free its header.
 */

void destroyCircular(DNode *header)
{
    while (header->next != header) {
        removeKnown(header->next);
    }
    free(header);
}

/* Insert at a position in the header ring
 * Find the position, then reuse insertBetween. Position equal to length means append before the header. Larger or negative positions fail.
 */

bool circularDInsertAt(DNode *header, int position, int value)
{
    if (position < 0) {
        return false;
    }
    DNode *current = header->next;
    int index = 0;
    while (index < position && current != header) {
        current = current->next;
        index++;
    }
    if (index != position) {
        return false;
    }
    insertBetween(current->previous, current, value);
    return true;
}

/* Delete at a position in the header ring
 * The header is an ending marker, never a deletable user node. Once the real target is found, reuse removeKnown.
 */

bool circularDRemoveAt(DNode *header, int position, int *value)
{
    if (position < 0) {
        return false;
    }
    DNode *current = header->next;
    for (int i = 0; i < position && current != header; i++) {
        current = current->next;
    }
    if (current == header) {
        return false;
    }
    *value = current->value;
    removeKnown(current);
    return true;
}

/* Main logic
 * Insert at front by choosing header and header.next. Insert at rear by choosing header.previous and header. The same helper handles both ends and the empty case.
 */

int main(void)
{
    DNode *first = createHeader();
    DNode *second = createHeader();
    insertBetween(first, first->next, 20);
    insertBetween(first, first->next, 10);
    insertBetween(first->previous, first, 30);
    printCircular(first);
    printBackward(first);
    removeKnown(first->previous);
    insertBetween(second->previous, second, 40);
    concatenate(first, second);
    printCircular(first);
    destroyCircular(first);
    destroyCircular(second);
    return 0;
}
