/* A heap as another priority queue representation
 * The PPT names heaps as an alternative. This min-heap serves smaller priority numbers first. Arrival sequence breaks ties, so equal priorities remain FIFO. The heap array is complete in shape but is not fully sorted.
 */

/* Store priority and arrival order
 * The sequence counter is assumed not to overflow during a demo. Its job is tie handling; it is not a tree index.
 */

/* Reuse the sorted priority queue already covered. */
#include "priority.h"
typedef struct {
    Patient patient;
    unsigned long long sequence;
} HeapItem;
typedef struct {
    HeapItem items[CAPACITY];
    int count;
    unsigned long long nextSequence;
} MinHeap;

/* Define which item should come earlier
 * Compare priority first and sequence second. The heap code can now ask one clear question instead of repeating a long comparison.
 */

bool comesBefore(HeapItem first, HeapItem second)
{
    if (first.patient.priority != second.patient.priority) {
        return first.patient.priority < second.patient.priority;
    }
    return first.sequence < second.sequence;
}

/* Swap complete heap records
 * Moving a patient without its sequence would lose the tie-breaking information.
 */

void swapHeapItems(HeapItem *first, HeapItem *second)
{
    HeapItem temporary = *first;
    *first = *second;
    *second = temporary;
}

/* Insert at the end then move upward
 * Append in the next complete-tree slot. Swap with the parent while the child should come earlier. Only one ancestor path can need repair.
 */

bool heapInsert(MinHeap *heap, Patient patient)
{
    if (heap->count == CAPACITY) {
        return false;
    }
    int index = heap->count;
    HeapItem item = {patient, heap->nextSequence};
    heap->nextSequence++;
    heap->items[index] = item;
    heap->count++;
    while (index > 0) {
        int parent = (index - 1) / 2;
        bool earlier = comesBefore(heap->items[index], heap->items[parent]);
        if (earlier == false) {
            break;
        }
        swapHeapItems(&heap->items[index], &heap->items[parent]);
        index = parent;
    }
    return true;
}

/* Peek at the root
 * The best item is at index 0. No search is needed.
 */

bool heapPeek(const MinHeap *heap, Patient *patient)
{
    if (heap->count == 0) {
        return false;
    }
    *patient = heap->items[0].patient;
    return true;
}

/* Remove the root then move the replacement downward
 * Move the last record to the root to preserve the complete shape. Repeatedly swap it with the earlier of its children until the parent rule holds.
 */

bool heapRemove(MinHeap *heap, Patient *patient)
{
    if (heap->count == 0) {
        return false;
    }
    *patient = heap->items[0].patient;
    heap->count--;
    if (heap->count == 0) {
        return true;
    }
    heap->items[0] = heap->items[heap->count];
    int index = 0;
    while (true) {
        int best = index;
        int left = 2 * index + 1;
        int right = left + 1;
        if (left < heap->count) {
            bool earlier = comesBefore(heap->items[left], heap->items[best]);
            if (earlier) {
                best = left;
            }
        }
        if (right < heap->count) {
            bool earlier = comesBefore(heap->items[right], heap->items[best]);
            if (earlier) {
                best = right;
            }
        }
        if (best == index) {
            break;
        }
        swapHeapItems(&heap->items[index], &heap->items[best]);
        index = best;
    }
    return true;
}

/* Main logic
 * Initialize count and sequence to zero. The service order is B,C,A: B and C tie on priority, so their sequence decides.
 */

int main(void)
{
    MinHeap heap = {0};
    Patient arrivals[] = {{"A", 3}, {"B", 1}, {"C", 1}};
    for (int i = 0; i < 3; i++) {
        bool ok = heapInsert(&heap, arrivals[i]);
        if (ok == false) {
            return 1;
        }
    }
    Patient patient;
    bool ok = heapPeek(&heap, &patient);
    if (ok) {
        printf("Next: %s\n", patient.name);
    }
    while (heap.count > 0) {
        heapRemove(&heap, &patient);
        puts(patient.name);
    }
    return 0;
}
