#include <assert.h>
#define main demo_main
#include "04_strings.c"
#undef main

int main(void) {
 char s[8]="abc";
 assert(insertText(s,sizeof s,1,"XY")); assert(strcmp(s,"aXYbc")==0);
 assert(deleteText(s,1,2)); assert(strcmp(s,"abc")==0);
 assert(insertText(s,sizeof s,3,"defg")); assert(strcmp(s,"abcdefg")==0);
 assert(insertText(s,sizeof s,0,"x")==false); assert(strcmp(s,"abcdefg")==0);
 assert(deleteText(s,7,0)); assert(deleteText(s,7,1)==false);
 assert(deleteText(s,0,7)); assert(s[0]=='\0');
 assert(compareText("abc","abd")<0); assert(compareText("abc","ab")>0);
 return 0;
}
