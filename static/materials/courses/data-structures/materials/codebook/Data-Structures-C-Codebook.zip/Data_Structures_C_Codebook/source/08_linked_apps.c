/* A stack and queue are now small wrappers
 * We have paid for the link logic once. The wrappers below state the access rule. These are intentionally small: reusable functions should make the next topic easier to read.
 */

/* Stack push uses the head
 * No separate top pointer is needed because list.head already has that role.
 */

/* Reuse the singly linked list types and operations already covered. */
#include "slist.h"
void linkedPush(List *stack, int value)
{
    prepend(stack, value);
}

/* Stack pop uses the same head
 * The bool result distinguishes empty from a stored value such as -1.
 */

bool linkedPop(List *stack, int *value)
{
    return removeFront(stack, value);
}

/* Queue insertion uses the tail
 * The oldest node stays at head. Newly arriving nodes go behind every waiting node.
 */

void linkedEnqueue(List *queue, int value)
{
    append(queue, value);
}

/* Queue deletion uses the head
 * Exactly the same removal operation serves a different access policy because insertion happens at the other end.
 */

bool linkedDequeue(List *queue, int *value)
{
    return removeFront(queue, value);
}

/* Merge sorted lists without creating replacement nodes
 * Precondition: two disjoint ascending lists and an empty destination. A local dummy node gives us a stable place to attach the first result node. Move the smaller head into the result until one input is empty, then attach the rest. The original list objects are reset so ownership is not duplicated.
 */

void mergeLists(List *first, List *second, List *result)
{
    Node dummy = {0, NULL};
    Node *last = &dummy;
    Node *a = first->head;
    Node *b = second->head;
    while (a != NULL && b != NULL) {
        if (a->value <= b->value) {
            last->next = a;
            a = a->next;
        } else {
            last->next = b;
            b = b->next;
        }
        last = last->next;
    }
    if (a != NULL) {
        last->next = a;
    } else {
        last->next = b;
    }
    while (last->next != NULL) {
        last = last->next;
    }
    result->head = dummy.next;
    if (result->head == NULL) {
        result->tail = NULL;
    } else {
        result->tail = last;
    }
    first->head = NULL;
    first->tail = NULL;
    second->head = NULL;
    second->tail = NULL;
}

/* Peek at the head of a linked stack or queue
 * Both selected representations remove at head. One observer can read that value without changing links.
 */

bool peekListFront(const List *list, int *value)
{
    if (list->head == NULL) {
        return false;
    }
    *value = list->head->value;
    return true;
}

/* Main logic
 * First use positional operations and reversal. Then put the same values into a stack and queue and compare the first value removed. Finally merge two sorted lists, print, and clear all owners.
 */

int main(void)
{
    List list = {NULL, NULL};
    append(&list, 10);
    append(&list, 30);
    bool ok = insertAt(&list, 1, 20);
    if (ok == false) {
        return 1;
    }
    reverseList(&list);
    printList(&list);
    int value;
    ok = removeAt(&list, 1, &value);
    if (ok) {
        printf("Removed: %d\n", value);
    }
    Node *found = findNode(&list, 10);
    printf("Found 10: %d\n", found != NULL);
    clearList(&list);
    List stack = {NULL, NULL};
    List queue = {NULL, NULL};
    for (int i = 1; i <= 3; i++) {
        linkedPush(&stack, i);
        linkedEnqueue(&queue, i);
    }
    ok = linkedPop(&stack, &value);
    if (ok) {
        printf("Stack gives: %d\n", value);
    }
    ok = linkedDequeue(&queue, &value);
    if (ok) {
        printf("Queue gives: %d\n", value);
    }
    clearList(&stack);
    clearList(&queue);
    List first = {NULL, NULL};
    List second = {NULL, NULL};
    List result = {NULL, NULL};
    append(&first, 1);
    append(&first, 4);
    append(&second, 2);
    append(&second, 3);
    mergeLists(&first, &second, &result);
    printList(&result);
    clearList(&result);
    return 0;
}
