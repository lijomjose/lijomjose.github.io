/* Graph traversal main
 * Reuse graph.h. The complete main below shows the operation sequence.
 */

/* Main logic
 * Vertices 0 through 3 form one component, and 4 and 5 form another. Run full list traversals, then a matrix traversal from 0 to show that one start does not cover the second component.
 */

/* Reuse the earlier graph types and graph operations. */
#include "graph.h"
int main(void)
{
    Graph graph;
    bool ok = initGraph(&graph, 6);
    if (ok == false) {
        return 1;
    }
    int edges[][2] = {{0,1}, {0,2}, {1,3}, {2,3}, {4,5}};
    for (int i = 0; i < 5; i++) {
        ok = addUndirected(&graph, edges[i][0], edges[i][1]);
        if (ok == false) {
            destroyGraph(&graph);
            return 1;
        }
    }
    printf("DFS forest: ");
    dfsAll(&graph);
    printf("BFS forest: ");
    bfsAll(&graph);
    bool visited[CAPACITY] = {false};
    printf("Matrix BFS from 0: ");
    matrixBfsFrom(&graph, 0, visited);
    putchar('\n');
    destroyGraph(&graph);
    return 0;
}
