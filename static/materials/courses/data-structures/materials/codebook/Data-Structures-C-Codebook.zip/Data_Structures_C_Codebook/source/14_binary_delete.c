/* Deletion without a search ordering rule
 * In an arbitrary binary tree, replacing a target with its inorder successor need not have any special benefit. One common policy is to copy the deepest rightmost node's value into the target, then remove that deepest node. This preserves a complete shape if the tree was complete. It is a policy, not the definition of all binary-tree deletion.
 */

/* Find target and deepest node by breadth first order
 * Queue cells carry node and parent routes. A bounded helper queue is local to this demonstration. Precondition: at most CAPACITY nodes; overflow returns false without changing the tree. We locate everything before performing mutation. Duplicate policy: delete the first level-order match.
 */

/* Reuse the linked binary tree type and tree operations. */
#include "tree.h"
typedef struct {
    Tree *node;
    Tree *parent;
} Visit;
typedef struct {
    Visit items[CAPACITY];
    int count;
    int next;
} VisitQueue;
bool enqueueVisit(VisitQueue *queue, Tree *node, Tree *parent)
{
    if (queue->count == CAPACITY) {
        return false;
    }
    Visit visit = {node, parent};
    queue->items[queue->count] = visit;
    queue->count++;
    return true;
}

/* Dequeue the next recorded visit
 * This queue never reuses cells within one traversal, so its capacity bounds the total tree size. We state that choice instead of calling it a general circular queue.
 */

bool dequeueVisit(VisitQueue *queue, Visit *visit)
{
    if (queue->next == queue->count) {
        return false;
    }
    *visit = queue->items[queue->next];
    queue->next++;
    return true;
}

/* Apply the deepest rightmost replacement policy
 * The last BFS visit is deepest rightmost. It must be a leaf: a child would be visited later. Copy its value into the target, disconnect its parent link, and free it. If the tree has one node, set the caller's root to NULL.
 */

bool deleteBinary(Tree **root, int key)
{
    if (*root == NULL) {
        return false;
    }
    VisitQueue queue = {0};
    bool ok = enqueueVisit(&queue, *root, NULL);
    if (ok == false) {
        return false;
    }
    Tree *target = NULL;
    Visit deepest = {*root, NULL};
    while (queue.next < queue.count) {
        Visit visit;
        dequeueVisit(&queue, &visit);
        deepest = visit;
        if (target == NULL && visit.node->value == key) {
            target = visit.node;
        }
        if (visit.node->left != NULL) {
            ok = enqueueVisit(&queue, visit.node->left, visit.node);
            if (ok == false) {
                return false;
            }
        }
        if (visit.node->right != NULL) {
            ok = enqueueVisit(&queue, visit.node->right, visit.node);
            if (ok == false) {
                return false;
            }
        }
    }
    if (target == NULL) {
        return false;
    }
    target->value = deepest.node->value;
    if (deepest.parent == NULL) {
        *root = NULL;
    } else if (deepest.parent->left == deepest.node) {
        deepest.parent->left = NULL;
    } else {
        deepest.parent->right = NULL;
    }
    free(deepest.node);
    return true;
}

/* Main logic
 * Build 10 with children 30 and 20, then delete 10. The root object stays but receives value 20; its former right leaf is removed.
 */

int main(void)
{
    Tree *root = newTreeNode(10);
    root->left = newTreeNode(30);
    root->right = newTreeNode(20);
    bool deleted = deleteBinary(&root, 10);
    printf("Deleted: %d\n", deleted);
    preorder(root);
    putchar('\n');
    destroyTree(root);
    return 0;
}
