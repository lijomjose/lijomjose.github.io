#include <assert.h>
#define main demo_main
#include "26_more_polynomials.c"
#undef main

long long evalS(const STerm *p,const STerm *end,int x){long long sum=0;for(;p!=end;p=p->next){long long power=1;for(int i=0;i<p->exponent;i++)power*=x;sum+=p->coefficient*power;}return sum;}
long long evalD(const PolyTerm *p,int x){long long sum=0;for(;p;p=p->next){long long power=1;for(int i=0;i<p->exponent;i++)power*=x;sum+=p->coefficient*power;if(p->next)assert(p->next->previous==p);}return sum;}
int main(void){
 srand(94);
 for(int trial=0;trial<150;trial++){
  SPolynomial a={NULL,NULL},c={NULL,NULL};PolyTerm *d=newPolynomial(),*e=newPolynomial();
  for(int i=0;i<15;i++){int coef=rand()%7-3,exp=rand()%5;sAddTerm(&a,coef,exp);addTerm(d,coef,exp);coef=rand()%7-3;exp=rand()%5;sAddTerm(&c,coef,exp);addTerm(e,coef,exp);}
  SPolynomial sum=sAdd(&a,&c),product=sMultiply(a.head,NULL,c.head,NULL);
  d=detachPolynomialHeader(d);e=detachPolynomialHeader(e);PolyTerm *ds=addLinearDoubly(d,e),*dp=multiplyLinearDoubly(d,e);
  for(int x=-2;x<=2;x++){long long av=evalS(a.head,NULL,x),cv=evalS(c.head,NULL,x);assert(evalS(sum.head,NULL,x)==av+cv);assert(evalS(product.head,NULL,x)==av*cv);assert(evalD(ds,x)==av+cv);assert(evalD(dp,x)==av*cv);}
  STerm *ah=sMakeCircular(&a),*ch=sMakeCircular(&c),*sh=sAddCircular(ah,ch);SPolynomial cp=sMultiply(ah->next,ah,ch->next,ch);
  for(int x=-2;x<=2;x++){long long av=evalS(ah->next,ah,x),cv=evalS(ch->next,ch,x);assert(evalS(sh->next,sh,x)==av+cv);assert(evalS(cp.head,NULL,x)==av*cv);}
  sClear(sum.head,NULL);sClear(product.head,NULL);sClear(cp.head,NULL);sClear(ah->next,ah);sClear(ch->next,ch);sClear(sh->next,sh);free(ah);free(ch);free(sh);clearLinearDoubly(d);clearLinearDoubly(e);clearLinearDoubly(ds);clearLinearDoubly(dp);
 }
 return 0;
}
