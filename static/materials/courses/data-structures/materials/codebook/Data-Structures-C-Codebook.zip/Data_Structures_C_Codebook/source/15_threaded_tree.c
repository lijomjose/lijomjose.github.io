/* Use an unused route to remember the next visit
 * This is a right-threaded BST. A missing right child may instead point to the inorder successor. rightIsThread tells us which meaning the pointer has. Left links are ordinary child links.
 */

/* Create a leaf with a successor thread
 * A new leaf has no left child. Its right link is a thread, possibly NULL when there is no successor.
 */

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct ThreadNode {
    int value;
    struct ThreadNode *left;
    struct ThreadNode *right;
    bool rightIsThread;
} ThreadNode;
ThreadNode *newThreadNode(int value, ThreadNode *successor)
{
    ThreadNode *node = allocate(sizeof *node);
    node->value = value;
    node->left = NULL;
    node->right = successor;
    node->rightIsThread = true;
    return node;
}

/* Insert without confusing a thread with a child
 * Go left normally. Go right only when the link is a real child. A new left child threads to its parent. A new right child inherits the parent's old successor thread; the parent's right link becomes a real child.
 */

ThreadNode *threadInsert(ThreadNode *root, int value)
{
    if (root == NULL) {
        return newThreadNode(value, NULL);
    }
    ThreadNode *current = root;
    while (true) {
        if (value == current->value) {
            return root;
        }
        if (value < current->value) {
            if (current->left == NULL) {
                current->left = newThreadNode(value, current);
                return root;
            }
            current = current->left;
        } else {
            if (current->rightIsThread) {
                ThreadNode *node = newThreadNode(value, current->right);
                current->right = node;
                current->rightIsThread = false;
                return root;
            }
            current = current->right;
        }
    }
}

/* Find the leftmost real node
 * Left links never carry threads in this representation. An empty input has no leftmost node.
 */

ThreadNode *threadLeftmost(ThreadNode *root)
{
    if (root == NULL) {
        return NULL;
    }
    while (root->left != NULL) {
        root = root->left;
    }
    return root;
}

/* Find the next inorder node
 * Follow a thread directly. Otherwise, enter the real right subtree and walk to its leftmost node. No parent route or explicit stack is needed.
 */

ThreadNode *inorderSuccessor(ThreadNode *node)
{
    if (node->rightIsThread) {
        return node->right;
    }
    return threadLeftmost(node->right);
}

/* Traverse by successor routes
 * Visit the leftmost node, then repeatedly ask for its successor. Each node is printed once.
 */

void threadedInorder(ThreadNode *root)
{
    ThreadNode *current = threadLeftmost(root);
    while (current != NULL) {
        printf("%d ", current->value);
        current = inorderSuccessor(current);
    }
    putchar('\n');
}

/* Cleanup follows children only
 * A thread can point to an ancestor. Recursing through it would revisit nodes and could double-free them. Recurse right only when rightIsThread is false.
 */

void destroyThreaded(ThreadNode *root)
{
    if (root == NULL) {
        return;
    }
    destroyThreaded(root->left);
    if (root->rightIsThread == false) {
        destroyThreaded(root->right);
    }
    free(root);
}

/* Main logic
 * Insert five keys, traverse without recursion, and clean up through real children. Insertion order determines shape because this is not a balanced tree.
 */

int main(void)
{
    ThreadNode *root = NULL;
    int keys[] = {20, 10, 30, 15, 25};
    for (int i = 0; i < 5; i++) {
        root = threadInsert(root, keys[i]);
    }
    threadedInorder(root);
    destroyThreaded(root);
    return 0;
}
