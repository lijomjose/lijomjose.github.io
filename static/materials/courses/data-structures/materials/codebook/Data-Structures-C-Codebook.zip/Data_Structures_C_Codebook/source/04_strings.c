/* The terminator is part of the storage bill
 * These bounded string operations avoid library string-processing functions inside their algorithms. Preconditions: inputs are valid null-terminated strings; source and destination do not overlap. A capacity includes room for the final null character.
 */

/* Find the finish line
 * Count characters until the null character. This count excludes the terminator itself. The caller must supply a properly terminated string.
 */

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
size_t textLength(const char text[])
{
    size_t length = 0;
    while (text[length] != '\0') {
        length++;
    }
    return length;
}

/* Compare meanings not pointer addresses
 * Advance through equal characters. At the first difference, compare unsigned character values. Return a negative, zero, or positive result. Comparing the pointers themselves would compare routes rather than the text.
 */

int compareText(const char first[], const char second[])
{
    size_t i = 0;
    while (first[i] != '\0' && first[i] == second[i]) {
        i++;
    }
    return (unsigned char)first[i] - (unsigned char)second[i];
}

/* Insertion opens a gap from the right
 * Validate position and capacity before changing anything. Move the terminator too. Copy backward so an unread character is not overwritten. The position may equal the current length, which makes this operation concatenation.
 */

bool insertText(char text[], size_t capacity,
                size_t position, const char addition[])
{
    size_t length = textLength(text);
    size_t extra = textLength(addition);
    if (position > length || length >= capacity) {
        return false;
    }
    if (extra > capacity - length - 1) {
        return false;
    }
    size_t i = length + 1;
    while (i > position) {
        i--;
        text[i + extra] = text[i];
    }
    for (i = 0; i < extra; i++) {
        text[position + i] = addition[i];
    }
    return true;
}

/* Deletion closes the gap from the left
 * Require the entire requested range to exist. Shift its suffix, including the terminator, left over the removed characters. This time forward copying is safe.
 */

bool deleteText(char text[], size_t position, size_t count)
{
    size_t length = textLength(text);
    if (position > length || count > length - position) {
        return false;
    }
    size_t i = position;
    while (i <= length - count) {
        text[i] = text[i + count];
        i++;
    }
    return true;
}

/* Main logic
 * Build a title through insertion, append at the current length, and delete a substring. Operation results are stored before they are checked. This keeps mutation and branching visibly separate.
 */

int main(void)
{
    char title[80] = "Sensei";
    bool ok = insertText(title, sizeof title, 0, "Rogue ");
    if (ok == false) {
        return 1;
    }
    size_t end = textLength(title);
    ok = insertText(title, sizeof title, end, " returns");
    if (ok == false) {
        return 1;
    }
    puts(title);
    ok = deleteText(title, 0, 6);
    if (ok == false) {
        return 1;
    }
    puts(title);
    printf("Comparison: %d\n", compareText(title, "Sensei returns"));
    return 0;
}
