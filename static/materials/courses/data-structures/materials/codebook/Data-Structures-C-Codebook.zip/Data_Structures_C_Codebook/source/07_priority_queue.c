/* Priority queue main
 * Reuse priority.h. The complete main below shows the operation sequence.
 */

/* Main logic
 * Create an empty queue with count zero. Admit three patients, including a priority tie, then serve until empty. The expected order is Rose, Maria, Bruce.
 */

/* Reuse the sorted priority queue already covered. */
#include "priority.h"
int main(void)
{
    PriorityQueue queue = {0};
    Patient arrivals[] = {{"Bruce", 3}, {"Rose", 1}, {"Maria", 1}};
    for (int i = 0; i < 3; i++) {
        bool ok = admit(&queue, arrivals[i]);
        if (ok == false) {
            return 1;
        }
    }
    while (queue.count > 0) {
        Patient patient;
        bool ok = serve(&queue, &patient);
        if (ok) {
            printf("%s priority %d\n", patient.name, patient.priority);
        }
    }
    return 0;
}
