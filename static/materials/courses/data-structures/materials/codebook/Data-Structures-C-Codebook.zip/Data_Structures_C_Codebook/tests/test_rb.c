#include <assert.h>
#define main demo_main
#include "18_red_black.c"
#undef main

int validate(RB *p, long long low, long long high)
{
    if(p==NIL) return 1;
    assert(p->value>low && p->value<high);
    if(p->left!=NIL) assert(p->left->parent==p);
    if(p->right!=NIL) assert(p->right->parent==p);
    if(p->color==RED) assert(p->left->color==BLACK && p->right->color==BLACK);
    int l=validate(p->left,low,p->value), r=validate(p->right,p->value,high);
    assert(l==r); return l+(p->color==BLACK);
}
int main(void)
{
    srand(67); initRB();
    for(int trial=0;trial<40;trial++) {
        RB *root=NIL; bool present[100]={false};
        for(int step=0;step<1500;step++) {
            int v=rand()%100;
            if(rand()%2) { rbInsert(&root,v); present[v]=true; }
            else { bool gone=rbDelete(&root,v); assert(gone==present[v]); present[v]=false; }
            assert(NIL->color==BLACK);
            if(root!=NIL) assert(root->color==BLACK && root->parent==NIL);
            validate(root,LLONG_MIN,LLONG_MAX);
            for(int key=0;key<100;key++) assert((rbSearch(root,key)!=NIL)==present[key]);
        }
        for(int key=0;key<100;key++) rbDelete(&root,key);
        assert(root==NIL);
    }
    return 0;
}
