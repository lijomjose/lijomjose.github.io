#!/usr/bin/env sh
set -eu
cd "$(dirname "$0")/source"
mkdir -p ../bin
for file in [0-9][0-9]_*.c; do
    name="${file%.c}"
    gcc -std=c11 -Wall -Wextra -Wpedantic -Werror "$file" -lm -o "../bin/$name"
done
