/* Array Binary Tree: Storage and Traversals
 * An ordinary array can represent a binary tree without nodes or child pointers. Start here for the simplest storage model. The linked version follows separately.
 */

/* Use two ordinary arrays
 * tree stores the values. occupied says whether a position contains a node. These are standard C headers; this example does not need course_common.h. TREE_SIZE is a named limit, not the number of nodes currently stored.
 */

#include <stdio.h>
#include <stdbool.h>
/* A named size limit; change it here rather than in every array. */
#define TREE_SIZE 31

/* Check a position before reading it
 * Check the bounds first. Only then read occupied[index]. Keeping this in one helper avoids repeating the same checks in every traversal.
 */

bool hasArrayNode(const bool occupied[], int index)
{
    if (index < 0 || index >= TREE_SIZE) {
        return false;
    }
    return occupied[index];
}

/* Store a node only below an existing parent
 * Index 0 is the root. At any other index, the parent must already exist. Storing at an occupied position replaces its value; it does not move its children.
 */

bool storeArrayNode(int tree[], bool occupied[], int index, int value)
{
    if (index < 0 || index >= TREE_SIZE) {
        return false;
    }
    if (index > 0) {
        int parent = (index - 1) / 2;
        bool parentExists = hasArrayNode(occupied, parent);
        if (parentExists == false) {
            return false;
        }
    }
    tree[index] = value;
    occupied[index] = true;
    return true;
}

/* Array Binary Tree Preorder
 * The rule is still root, left, right. Only the way we reach a child changes: calculate its index instead of following a pointer.
 */

void arrayPreorder(const int tree[], const bool occupied[], int index)
{
    bool exists = hasArrayNode(occupied, index);
    if (exists == false) {
        return;
    }
    int left = 2 * index + 1;
    int right = 2 * index + 2;
    printf("%d ", tree[index]);
    arrayPreorder(tree, occupied, left);
    arrayPreorder(tree, occupied, right);
}

/* Array Binary Tree Inorder
 * Visit left, root, right. Inorder is sorted only when the stored tree follows the BST rule; using an array does not make a tree a BST.
 */

void arrayInorder(const int tree[], const bool occupied[], int index)
{
    bool exists = hasArrayNode(occupied, index);
    if (exists == false) {
        return;
    }
    int left = 2 * index + 1;
    int right = 2 * index + 2;
    arrayInorder(tree, occupied, left);
    printf("%d ", tree[index]);
    arrayInorder(tree, occupied, right);
}

/* Array Binary Tree Postorder
 * Visit left, right, root. Compare just the position of printf with the previous two traversals.
 */

void arrayPostorder(const int tree[], const bool occupied[], int index)
{
    bool exists = hasArrayNode(occupied, index);
    if (exists == false) {
        return;
    }
    int left = 2 * index + 1;
    int right = 2 * index + 2;
    arrayPostorder(tree, occupied, left);
    arrayPostorder(tree, occupied, right);
    printf("%d ", tree[index]);
}

/* Array Binary Tree Level Order
 * Increasing array positions already follow level order. Skip the unused slots. No queue is needed for this representation.
 */

void arrayLevelOrder(const int tree[], const bool occupied[])
{
    for (int index = 0; index < TREE_SIZE; index++) {
        if (occupied[index] == true) {
            printf("%d ", tree[index]);
        }
    }
}

/* Remove a whole array subtree
 * Clear the children before the parent. We only change occupancy flags; the integer left in a cleared slot is ignored. This removes the entire chosen subtree, not one BST key.
 */

void clearArraySubtree(bool occupied[], int index)
{
    bool exists = hasArrayNode(occupied, index);
    if (exists == false) {
        return;
    }
    int left = 2 * index + 1;
    int right = 2 * index + 2;
    clearArraySubtree(occupied, left);
    clearArraySubtree(occupied, right);
    occupied[index] = false;
}

/* Main logic
 * Store 10 at the root, 20 and 30 below it, then 0 and 50 below 20. The values are deliberately not in BST order. Try each traversal, then remove the subtree at index 1.
 */

int main(void)
{
    int tree[TREE_SIZE] = {0};
    bool occupied[TREE_SIZE] = {false};
    int positions[] = {0, 1, 2, 3, 4};
    int values[] = {10, 20, 30, 0, 50};
    for (int i = 0; i < 5; i++) {
        bool stored = storeArrayNode(tree, occupied, positions[i], values[i]);
        if (stored == false) {
            printf("Cannot store this node.\n");
            return 1;
        }
    }
    printf("Preorder: ");
    arrayPreorder(tree, occupied, 0);
    printf("\nInorder: ");
    arrayInorder(tree, occupied, 0);
    printf("\nPostorder: ");
    arrayPostorder(tree, occupied, 0);
    printf("\nLevel order: ");
    arrayLevelOrder(tree, occupied);
    clearArraySubtree(occupied, 1);
    printf("\nAfter removing subtree at index 1: ");
    arrayLevelOrder(tree, occupied);
    putchar('\n');
    return 0;
}
