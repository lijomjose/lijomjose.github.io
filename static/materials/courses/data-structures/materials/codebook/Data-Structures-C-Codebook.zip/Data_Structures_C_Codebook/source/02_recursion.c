/* A smaller problem must actually be smaller
 * A recursive call is an unfinished promise. The caller waits while a smaller instance is solved. A base case closes the promise. Here we use Euclid's algorithm, a recursively processed array, and Hanoi to see three different recurrences.
 */

/* Euclid reduces the remainder
 * For nonnegative a and b, gcd(a,b) = gcd(b,a%b). When b is zero, a is the answer. Each call has its own a and b.
 */

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
int gcd(int a, int b)
{
    if (b == 0) {
        return a;
    }
    int remainder = a % b;
    return gcd(b, remainder);
}

/* An array as one item plus the rest
 * The empty suffix contributes zero. Otherwise, add the current element to the sum of the shorter suffix. Preconditions: count is nonnegative and the mathematical sum fits int.
 */

int recursiveSum(const int values[], int count)
{
    if (count == 0) {
        return 0;
    }
    int rest = recursiveSum(values + 1, count - 1);
    return values[0] + rest;
}

/* Hanoi must clear the larger disk first
 * Move n-1 disks to the spare peg, move the largest disk to the destination, and move the waiting n-1 disks onto it. A count of zero means there is nothing to move.
 */

void hanoi(int count, char from, char spare, char to)
{
    if (count == 0) {
        return;
    }
    hanoi(count - 1, from, to, spare);
    printf("Disk %d: %c to %c\n", count, from, to);
    hanoi(count - 1, spare, from, to);
}

/* Main logic
 * Fixed small inputs keep attention on the calls. Predict the Hanoi order before running the file. The two recursive calls are sequential, so maximum active depth is linear even though total moves are exponential.
 */

int main(void)
{
    int values[] = {4, 7, 2};
    printf("GCD: %d\n", gcd(48, 18));
    printf("Sum: %d\n", recursiveSum(values, 3));
    hanoi(3, 'A', 'B', 'C');
    return 0;
}
