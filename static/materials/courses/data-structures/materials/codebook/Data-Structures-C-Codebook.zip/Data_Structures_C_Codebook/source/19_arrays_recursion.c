/* Array operations and the recursive versions
 * These are the extra array and recursion implementations in the first PPT. Logical count and allocated capacity are different. Small arithmetic examples assume the result fits its stated type.
 */

/* Create a bounded array
 * Start empty. Its values become meaningful only as we insert them. This one-dimensional ADT uses int values and a fixed maximum capacity.
 */

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
typedef struct {
    int values[CAPACITY];
    int count;
} Array;
void initArray(Array *array)
{
    array->count = 0;
}

/* Retrieve an existing element
 * Return a status separately from the stored integer. An invalid index leaves the output unchanged.
 */

bool arrayGet(const Array *array, int index, int *value)
{
    if (index < 0 || index >= array->count) {
        return false;
    }
    *value = array->values[index];
    return true;
}

/* Replace an existing element
 * Store changes a value, not the logical length. Valid occupied indices end at count-1.
 */

bool arrayStore(Array *array, int index, int value)
{
    if (index < 0 || index >= array->count) {
        return false;
    }
    array->values[index] = value;
    return true;
}

/* Insert after opening a gap
 * Insertion also allows index=count. Shift right from the end so unread values survive.
 */

bool arrayInsert(Array *array, int index, int value)
{
    if (index < 0 || index > array->count
        || array->count == CAPACITY) {
        return false;
    }
    for (int i = array->count; i > index; i--) {
        array->values[i] = array->values[i - 1];
    }
    array->values[index] = value;
    array->count++;
    return true;
}

/* Delete and close the gap
 * Copy the removed value before shifting. Logical length decreases; physical capacity stays the same.
 */

bool arrayDelete(Array *array, int index, int *value)
{
    if (index < 0 || index >= array->count) {
        return false;
    }
    *value = array->values[index];
    for (int i = index; i < array->count - 1; i++) {
        array->values[i] = array->values[i + 1];
    }
    array->count--;
    return true;
}

/* Factorial must give one for zero
 * For input 0 through 20, the result fits unsigned long long on a C implementation with at least 64 bits for that type. The recursive helper assumes that range has already been checked.
 */

unsigned long long factorial(int n)
{
    if (n == 0) {
        return 1;
    }
    unsigned long long smaller = factorial(n - 1);
    return (unsigned long long)n * smaller;
}

/* Binary search can recurse on the smaller interval
 * Assume ascending input. Empty interval means low>high. Unlike iterative binary search, these calls use O(log n) extra call space in the worst case.
 */

int recursiveBinarySearch(const int values[], int low, int high, int key)
{
    if (low > high) {
        return -1;
    }
    int middle = low + (high - low) / 2;
    if (values[middle] == key) {
        return middle;
    }
    if (key < values[middle]) {
        return recursiveBinarySearch(values, low, middle - 1, key);
    }
    return recursiveBinarySearch(values, middle + 1, high, key);
}

/* Pass a real two dimensional array
 * The column width is part of the parameter type. Read only rows 0 through rows-1; the caller supplies a valid row count. The sum must fit int.
 */

int sumMatrix(const int matrix[][3], int rows)
{
    int sum = 0;
    for (int row = 0; row < rows; row++) {
        for (int column = 0; column < 3; column++) {
            sum = sum + matrix[row][column];
        }
    }
    return sum;
}

/* Main logic
 * Create, insert, replace, retrieve, and delete before showing the two recursive examples. The matrix has two genuine three-integer rows.
 */

int main(void)
{
    Array array;
    initArray(&array);
    bool ok = arrayInsert(&array, 0, 10);
    if (ok == false) {
        return 1;
    }
    ok = arrayInsert(&array, 1, 30);
    if (ok == false) {
        return 1;
    }
    ok = arrayInsert(&array, 1, 20);
    if (ok == false) {
        return 1;
    }
    ok = arrayStore(&array, 1, 25);
    if (ok == false) {
        return 1;
    }
    int value;
    ok = arrayGet(&array, 1, &value);
    if (ok) {
        printf("Retrieved: %d\n", value);
    }
    ok = arrayDelete(&array, 1, &value);
    if (ok) {
        printf("Deleted: %d\n", value);
    }
    int sorted[] = {10, 20, 30, 40};
    int index = recursiveBinarySearch(sorted, 0, 3, 30);
    printf("Recursive search: %d\n", index);
    printf("0! = %llu, 5! = %llu\n", factorial(0), factorial(5));
    const int matrix[2][3] = {{1, 2, 3}, {4, 5, 6}};
    printf("Matrix sum: %d\n", sumMatrix(matrix, 2));
    return 0;
}
