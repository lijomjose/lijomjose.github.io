/* Detect duplicate parentheses
 * Here duplicate means a matched pair with no operator belonging directly to that pair. Examples: (a) and ((a+b)) contain duplicate parentheses; (a+b) does not. Invalid input is a separate result. We reuse the expression converter to validate the grammar first.
 */

/* Validate then track operators inside each pair
 * Push only opening parentheses and operators. At a closing parenthesis, pop operators until its opening marker. Zero popped operators means the pair adds no operation of its own.
 */

/* Reuse the expression conversion and evaluation helpers. */
#include "expressions.h"
typedef enum { INVALID_EXPRESSION, NO_DUPLICATE, DUPLICATE_FOUND } DuplicateResult;
DuplicateResult duplicateParentheses(const char text[])
{
    char postfix[CAPACITY];
    bool valid = infixToPostfix(text, postfix, sizeof postfix);
    if (valid == false) {
        return INVALID_EXPRESSION;
    }
    IntStack stack;
    initStack(&stack);
    bool duplicate = false;
    for (size_t i = 0; text[i] != '\0'; i++) {
        char symbol = text[i];
        if (symbol == '(' || precedence(symbol) != 0) {
            bool ok = push(&stack, symbol);
            if (ok == false) {
                return INVALID_EXPRESSION;
            }
        } else if (symbol == ')') {
            int operatorCount = 0;
            int item;
            pop(&stack, &item);
            while (item != '(') {
                operatorCount++;
                pop(&stack, &item);
            }
            if (operatorCount == 0) {
                duplicate = true;
            }
        }
    }
    if (duplicate) {
        return DUPLICATE_FOUND;
    }
    return NO_DUPLICATE;
}

/* Main logic
 * The enum values are 0 for invalid, 1 for no duplicate, and 2 for duplicate found. Print labels rather than making students infer what an unexplained number means.
 */

int main(void)
{
    const char *tests[] = {"(a+b)", "((a+b))", "(a)", "(a+b"};
    for (int i = 0; i < 4; i++) {
        DuplicateResult result = duplicateParentheses(tests[i]);
        printf("%s: ", tests[i]);
        if (result == INVALID_EXPRESSION) {
            puts("invalid");
        } else if (result == DUPLICATE_FOUND) {
            puts("duplicate pair");
        } else {
            puts("no duplicate pair");
        }
    }
    return 0;
}
