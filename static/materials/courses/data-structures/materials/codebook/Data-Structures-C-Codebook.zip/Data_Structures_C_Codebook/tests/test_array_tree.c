#include <assert.h>
#define main array_tree_demo_main
#include "40_array_binary_tree.c"
#undef main

int main(void)
{
    int tree[TREE_SIZE] = {0};
    bool occupied[TREE_SIZE] = {false};
    assert(hasArrayNode(occupied, -1) == false);
    assert(hasArrayNode(occupied, TREE_SIZE) == false);
    assert(storeArrayNode(tree, occupied, 1, 22) == false);
    assert(storeArrayNode(tree, occupied, 0, 0));
    assert(occupied[0] && tree[0] == 0);
    assert(storeArrayNode(tree, occupied, -1, 88) == false);
    assert(storeArrayNode(tree, occupied, TREE_SIZE, 88) == false);
    assert(storeArrayNode(tree, occupied, 2, -1));
    assert(storeArrayNode(tree, occupied, 6, 6));
    assert(storeArrayNode(tree, occupied, 14, 14));
    assert(storeArrayNode(tree, occupied, 30, 30));
    assert(storeArrayNode(tree, occupied, 62, 62) == false);
    assert(storeArrayNode(tree, occupied, 1, 1));
    assert(storeArrayNode(tree, occupied, 3, 3));
    clearArraySubtree(occupied, 2);
    assert(occupied[0] && occupied[1] && occupied[3]);
    assert(!occupied[2] && !occupied[6] && !occupied[14] && !occupied[30]);
    assert(storeArrayNode(tree, occupied, 6, 99) == false);
    clearArraySubtree(occupied, -1);
    clearArraySubtree(occupied, TREE_SIZE);
    clearArraySubtree(occupied, 0);
    for (int i = 0; i < TREE_SIZE; i++) {
        assert(occupied[i] == false);
    }
    assert(storeArrayNode(tree, occupied, 0, -17));
    return 0;
}
