/* Adjacency Matrix Graph: Array Only DFS and BFS
 * This version stores the graph in a plain two-dimensional int array. Study it before the adjacency-list version. Indices start at 0; vertexCount stays between 0 and MAX.
 */

/* Store only the adjacency matrix
 * graph[u][v] is 1 when an edge goes from u to v, and 0 otherwise. No linked edge nodes are created. MAX limits this graph to 10 vertices; int_queue.h reuses the earlier circular array queue for BFS.
 */

#include <stdio.h>
#include <stdbool.h>
/* Reuse the circular array queue: IntQueue, initQueue, enqueue and dequeue. */
#include "int_queue.h"
/* A named size limit; change it here rather than in every array. */
#define MAX 10

/* Check a vertex number
 * An active graph may have fewer vertices than the array can hold. Check against vertexCount, not just the physical capacity. A caller supplies a count from 0 to MAX.
 */

bool validMatrixVertex(int vertex, int vertexCount)
{
    if (vertex < 0 || vertex >= vertexCount) {
        return false;
    }
    return true;
}

/* Add a directed or undirected edge
 * Check both endpoints before using them as indices. A directed edge sets one cell. An undirected edge also sets the reverse cell. Repeating the same edge simply writes 1 again.
 */

bool addMatrixEdge(int graph[][MAX], int vertexCount,
                   int from, int to, bool directed)
{
    bool fromIsValid = validMatrixVertex(from, vertexCount);
    bool toIsValid = validMatrixVertex(to, vertexCount);
    if (fromIsValid == false || toIsValid == false) {
        return false;
    }
    graph[from][to] = 1;
    if (directed == false) {
        graph[to][from] = 1;
    }
    return true;
}

/* Display the active matrix
 * Print only the rows and columns belonging to actual vertices. Reading one row tells us all outgoing neighbors of that vertex.
 */

void displayMatrix(int graph[][MAX], int vertexCount)
{
    for (int row = 0; row < vertexCount; row++) {
        for (int column = 0; column < vertexCount; column++) {
            printf("%d ", graph[row][column]);
        }
        putchar('\n');
    }
}

/* Matrix Only Depth First Search
 * Mark and print this vertex. Scan its row for an edge to an unvisited neighbor, then recurse. The start vertex must be valid. DFS uses the call stack; it does not use a queue.
 */

void matrixOnlyDFS(int graph[][MAX], int vertexCount,
                   int vertex, bool visited[])
{
    visited[vertex] = true;
    printf("%d ", vertex);
    for (int neighbor = 0; neighbor < vertexCount; neighbor++) {
        if (graph[vertex][neighbor] == 0) {
            continue;
        }
        if (visited[neighbor] == false) {
            matrixOnlyDFS(graph, vertexCount, neighbor, visited);
        }
    }
}

/* Matrix Only Breadth First Search
 * Reuse initQueue, enqueue and dequeue from the queue section. Mark a vertex before enqueueing it. Each vertex enters at most once; the earlier queue holds 128 items and this graph has at most 10 vertices. The start must be valid.
 */

void matrixOnlyBFS(int graph[][MAX], int vertexCount,
                   int start, bool visited[])
{
    IntQueue queue;
    initQueue(&queue);
    visited[start] = true;
    enqueue(&queue, start);
    while (queue.count > 0) {
        int vertex;
        dequeue(&queue, &vertex);
        printf("%d ", vertex);
        for (int neighbor = 0; neighbor < vertexCount; neighbor++) {
            if (graph[vertex][neighbor] == 0) {
                continue;
            }
            if (visited[neighbor] == false) {
                visited[neighbor] = true;
                enqueue(&queue, neighbor);
            }
        }
    }
}

/* Visit every component with the same DFS
 * A start at 0 cannot reach a disconnected component. Start DFS again at each still-unvisited vertex. For an undirected graph, the number of new starts is the number of connected components.
 */

int matrixOnlyComponents(int graph[][MAX], int vertexCount)
{
    bool visited[MAX] = {false};
    int components = 0;
    for (int vertex = 0; vertex < vertexCount; vertex++) {
        if (visited[vertex] == false) {
            components++;
            matrixOnlyDFS(graph, vertexCount, vertex, visited);
        }
    }
    return components;
}

/* Main logic
 * Zero initialization means no edges. Vertices 0 to 3 form a cycle; 4 and 5 form another component. Reset visited before switching from DFS to BFS. false requests undirected edges; use true for directed edges.
 */

int main(void)
{
    int graph[MAX][MAX] = {0};
    int vertexCount = 6;
    int edges[][2] = {{0, 1}, {0, 2}, {1, 3}, {2, 3}, {4, 5}};
    for (int i = 0; i < 5; i++) {
        int from = edges[i][0];
        int to = edges[i][1];
        bool added = addMatrixEdge(graph, vertexCount, from, to, false);
        if (added == false) {
            printf("Invalid vertex.\n");
            return 1;
        }
    }
    printf("Adjacency matrix:\n");
    displayMatrix(graph, vertexCount);
    bool visited[MAX] = {false};
    printf("DFS from 0: ");
    matrixOnlyDFS(graph, vertexCount, 0, visited);
    for (int i = 0; i < vertexCount; i++) {
        visited[i] = false;
    }
    printf("\nBFS from 0: ");
    matrixOnlyBFS(graph, vertexCount, 0, visited);
    printf("\nDFS across all components: ");
    int components = matrixOnlyComponents(graph, vertexCount);
    printf("\nConnected components: %d\n", components);
    return 0;
}
