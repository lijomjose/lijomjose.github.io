/* Several stacks inside one array
 * The PPT includes fixed partitions and discusses dynamic sharing. Both are shown here. Stack numbers are 0 through STACKS-1. Failed operations leave the output unchanged.
 */

/* Initialize fixed partitions
 * Each stack owns a separate index interval [start,limit). top is the last occupied index, initially start-1. Division may give slightly different partition sizes.
 */

/* Our shared C headers, CAPACITY and allocate helper; explained before Chapter 1. */
#include "course_common.h"
/* A named size limit; change it here rather than in every array. */
#define STACKS 3
typedef struct {
    int items[CAPACITY];
    int top[STACKS];
    int start[STACKS];
    int limit[STACKS];
} FixedStacks;
void initFixed(FixedStacks *stacks)
{
    for (int i = 0; i < STACKS; i++) {
        stacks->start[i] = i * CAPACITY / STACKS;
        stacks->limit[i] = (i + 1) * CAPACITY / STACKS;
        stacks->top[i] = stacks->start[i] - 1;
    }
}

/* Push into the selected fixed partition
 * Check the stack number and that partition's exclusive boundary. A different partition's free cells are unavailable here.
 */

bool fixedPush(FixedStacks *stacks, int which, int value)
{
    if (which < 0 || which >= STACKS) {
        return false;
    }
    if (stacks->top[which] + 1 == stacks->limit[which]) {
        return false;
    }
    stacks->top[which]++;
    stacks->items[stacks->top[which]] = value;
    return true;
}

/* Pop within the selected partition
 * The lower boundary, not -1 in every partition, identifies that stack's empty state.
 */

bool fixedPop(FixedStacks *stacks, int which, int *value)
{
    if (which < 0 || which >= STACKS) {
        return false;
    }
    if (stacks->top[which] < stacks->start[which]) {
        return false;
    }
    *value = stacks->items[stacks->top[which]];
    stacks->top[which]--;
    return true;
}

/* Initialize a shared free list for dynamic stacks
 * Every free slot links to the next free slot through next. Each top is an index or -1. A used slot's next entry links to the previous item in its stack. The same array has different roles depending on slot ownership.
 */

typedef struct {
    int items[CAPACITY];
    int next[CAPACITY];
    int top[STACKS];
    int freeHead;
} SharedStacks;
void initShared(SharedStacks *stacks)
{
    for (int i = 0; i < STACKS; i++) {
        stacks->top[i] = -1;
    }
    for (int i = 0; i < CAPACITY - 1; i++) {
        stacks->next[i] = i + 1;
    }
    stacks->next[CAPACITY - 1] = -1;
    stacks->freeHead = 0;
}

/* Push takes one slot from the free list
 * Remove the first free slot, link it to the selected stack's old top, then make it the new top. Any stack can use any free slot.
 */

bool dynamicPush(SharedStacks *stacks, int which, int value)
{
    if (which < 0 || which >= STACKS || stacks->freeHead == -1) {
        return false;
    }
    int slot = stacks->freeHead;
    stacks->freeHead = stacks->next[slot];
    stacks->next[slot] = stacks->top[which];
    stacks->top[which] = slot;
    stacks->items[slot] = value;
    return true;
}

/* Pop returns its slot to the free list
 * Unlink the top slot from its stack, copy the value, then attach that slot at the front of the free list. No allocated heap node is involved.
 */

bool dynamicPop(SharedStacks *stacks, int which, int *value)
{
    if (which < 0 || which >= STACKS) {
        return false;
    }
    int slot = stacks->top[which];
    if (slot == -1) {
        return false;
    }
    *value = stacks->items[slot];
    stacks->top[which] = stacks->next[slot];
    stacks->next[slot] = stacks->freeHead;
    stacks->freeHead = slot;
    return true;
}

/* Display one fixed partition
 * The empty boundary belongs to that partition. Do not print cells belonging to another stack.
 */

void displayFixed(const FixedStacks *stacks, int which)
{
    if (which < 0 || which >= STACKS) {
        return;
    }
    for (int i = stacks->top[which]; i >= stacks->start[which]; i--) {
        printf("%d ", stacks->items[i]);
    }
    putchar('\n');
}

/* Display a dynamically shared stack
 * Its items need not occupy adjacent array cells. Follow next indices from top instead of scanning a physical interval.
 */

void displayShared(const SharedStacks *stacks, int which)
{
    if (which < 0 || which >= STACKS) {
        return;
    }
    int index = stacks->top[which];
    while (index != -1) {
        printf("%d ", stacks->items[index]);
        index = stacks->next[index];
    }
    putchar('\n');
}

/* Main logic
 * Put one value in each stack and pop from each. The earlier two-ended implementation is simpler for exactly two stacks; this free-list version supports k stacks.
 */

int main(void)
{
    FixedStacks fixed;
    SharedStacks shared;
    initFixed(&fixed);
    initShared(&shared);
    for (int i = 0; i < STACKS; i++) {
        bool ok = fixedPush(&fixed, i, i + 10);
        if (ok == false) {
            return 1;
        }
        ok = dynamicPush(&shared, i, i + 20);
        if (ok == false) {
            return 1;
        }
    }
    for (int i = 0; i < STACKS; i++) {
        int value;
        bool ok = fixedPop(&fixed, i, &value);
        if (ok) {
            printf("Fixed stack %d: %d\n", i, value);
        }
        ok = dynamicPop(&shared, i, &value);
        if (ok) {
            printf("Shared stack %d: %d\n", i, value);
        }
    }
    return 0;
}
