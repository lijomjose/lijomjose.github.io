#include <assert.h>
#define main demo_main
#include "08_linked_apps.c"
#undef main

void check(List *list, int expected[], int n)
{
    Node *p=list->head; Node *last=NULL;
    for(int i=0;i<n;i++) { assert(p); assert(p->value==expected[i]); last=p; p=p->next; }
    assert(p==NULL); assert(list->tail==last);
}
int main(void)
{
    List list={NULL,NULL}; int v=123;
    assert(removeFront(&list,&v)==false && v==123);
    assert(insertAt(&list,-1,9)==false);
    assert(insertAt(&list,1,9)==false);
    assert(insertAt(&list,0,9));
    assert(removeAt(&list,0,&v) && v==9);
    assert(list.head==NULL && list.tail==NULL);
    for(int i=0;i<80;i++) append(&list,i);
    reverseList(&list); int expected[80];
    for(int i=0;i<80;i++) expected[i]=79-i;
    check(&list,expected,80);
    for(int i=79;i>=0;i--) { assert(removeAt(&list,i,&v)); assert(v==79-i); }
    check(&list,expected,0);
    List a={NULL,NULL},b={NULL,NULL},r={NULL,NULL};
    for(int i=0;i<20;i++) { append(&a,2*i); append(&b,2*i+1); }
    mergeLists(&a,&b,&r);
    for(int i=0;i<40;i++) expected[i]=i;
    check(&r,expected,40); check(&a,expected,0); check(&b,expected,0);
    clearList(&r);
    return 0;
}
