#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>
#define CAP 5
static int data[CAP];
static int front = -1;
static int rear = -1;
bool isEmpty(void) { return front == -1; }
bool isFull(void) { return !isEmpty() && (rear+1)%CAP == front; }
bool insertFront(int value) {
    if (isFull()) {
        return false;
    }
    if (isEmpty()) {
        front = 0;
        rear = 0;
    } else {
        front = (front + CAP - 1) % CAP;
    }
    data[front] = value;
    return true;
}
bool insertRear(int value) {
    if (isFull()) {
        return false;
    }
    if (isEmpty()) {
        front = 0;
        rear = 0;
    } else {
        rear = (rear + 1) % CAP;
    }
    data[rear] = value;
    return true;
}
int deleteFront(void) {
    if (isEmpty()) {
        printf("Queue is empty!\n");
        exit(1);
    }
    int removedValue = data[front];
    if (front == rear) {
        front = -1;
        rear = -1;
    } else {
        front = (front + 1) % CAP;
    }
    return removedValue;
}
int deleteRear(void) {
    if (isEmpty()) {
        printf("Queue is empty!\n");
        exit(1);
    }
    int removedValue = data[rear];
    if (front == rear) {
        front = -1;
        rear = -1;
    } else {
        rear = (rear + CAP - 1) % CAP;
    }
    return removedValue;
}
int getFront(void) {
    if (isEmpty()) {
        printf("Queue is empty!\n");
        exit(1);
    }
    int value = data[front];
    return value;
}
int getRear(void) {
    if (isEmpty()) {
        printf("Queue is empty!\n");
        exit(1);
    }
    int value = data[rear];
    return value;
}
void trace(const char *op) {
    printf("%-18s front=%2d rear=%2d pending:",op,front,rear);
    if(!isEmpty()) {int i=front;while(1){printf(" %d",data[i]);if(i==rear)break;i=(i+1)%CAP;}}
    puts("");
}
int main(void) {
    insertRear(10);
    insertRear(20);
    int value = deleteFront();
    printf("Removed: %d\n", value);
    value = deleteFront();
    printf("Removed: %d\n", value);
    value = deleteFront(); // Empty: exit(1)
    printf("Main continues\n"); // Never reached
    return 0;
}
