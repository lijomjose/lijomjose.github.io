#include <stdio.h>
#include <stdbool.h>
#include <assert.h>
#include <stdlib.h>
#define QUEUE_COUNT 3
typedef struct Node {
    int value;
    struct Node *next;
} Node;
typedef struct {
    Node *front;
    Node *rear;
} Queue;
static Queue queues[QUEUE_COUNT] = {{0}};
bool enqueue(Queue *q, int value) {
    Node *newNode = malloc(sizeof(Node));
    if (newNode == NULL) {
        return false;
    }
    newNode->value = value;
    newNode->next = NULL;

    if (q->rear == NULL) {
        q->front = newNode;  // First node in an empty queue
    } else {
        q->rear->next = newNode;
    }
    q->rear = newNode;
    return true;
}
bool dequeue(Queue *q, int *removedValue) {
    if (q->front == NULL) {
        return false;
    }
    Node *oldFront = q->front;
    *removedValue = oldFront->value;
    q->front = oldFront->next;

    if (q->front == NULL) {
        q->rear = NULL;  // The last node has left
    }
    free(oldFront);
    return true;
}
bool peek(const Queue *q, int *frontValue) {
    if (q->front == NULL) {
        return false;
    }
    *frontValue = q->front->value;
    return true;
}
void trace(const char *op) {
    puts(op);
    for(int k=0;k<QUEUE_COUNT;++k) {
        printf("Q%d:",k);
        for(Node *n=queues[k].front;n;n=n->next) printf(" %d",n->value);
        printf("  front=%s rear=%s\n",queues[k].front?"node":"NULL",queues[k].rear?"node":"NULL");
    }
}
int main(void) {
    int x;
    assert(enqueue(&queues[0],10));
    assert(enqueue(&queues[0],20));
    assert(enqueue(&queues[0],30));
    assert(enqueue(&queues[1],100));
    assert(enqueue(&queues[1],200));
    trace("independent arrivals");
    assert(dequeue(&queues[0],&x)&&x==10);
    trace("Q0 removes 10");
    assert(dequeue(&queues[1],&x)&&x==100);
    trace("Q1 removes 100");
    assert(peek(&queues[0],&x)&&x==20);
    for(int k=0;k<QUEUE_COUNT;++k) while(dequeue(&queues[k],&x)) {}
    for(int k=0;k<QUEUE_COUNT;++k) assert(!queues[k].front&&!queues[k].rear);
    trace("all queues empty");
}
