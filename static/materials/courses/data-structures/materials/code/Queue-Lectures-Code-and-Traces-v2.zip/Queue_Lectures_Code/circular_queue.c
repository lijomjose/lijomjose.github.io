#include <stdio.h>
#include <stdbool.h>
#include <assert.h>
#define CAP 5
static int data[CAP];
static int front = -1;
static int rear = -1;
/* front: first item; rear: last item; all CAP cells are usable */
bool isEmpty(void) { return front == -1; }
bool isFull(void) { return !isEmpty() && (rear + 1) % CAP == front; }
bool enqueue(int value) {
    if (isFull()) {
        return false;
    }
    if (isEmpty()) {
        front = 0;
        rear = 0;
    } else {
        rear = (rear + 1) % CAP;
    }
    data[rear] = value;
    return true;
}
bool dequeue(int *removedValue) {
    if (isEmpty()) {
        return false;
    }
    *removedValue = data[front];
    if (front == rear) {
        front = -1;
        rear = -1;
    } else {
        front = (front + 1) % CAP;
    }
    return true;
}
bool peek(int *frontValue) {
    if (isEmpty()) {
        return false;
    }
    *frontValue = data[front];
    return true;
}
void trace(const char *operation) {
    printf("%-18s front=%2d rear=%2d pending:", operation, front, rear);
    if (!isEmpty()) {
        int position = front;
        while (1) {
            printf(" %d", data[position]);
            if (position == rear) {
                break;
            }
            position = (position + 1) % CAP;
        }
    }
    puts("");
}
int main(void) {
    int value;
    trace("start");
    for (int item = 10; item <= 50; item = item + 10) {
        assert(enqueue(item));
        trace("enqueue");
    }
    assert(isFull() && !enqueue(99));
    trace("full: reject 99");
    assert(dequeue(&value) && value == 10);
    trace("dequeue 10");
    assert(dequeue(&value) && value == 20);
    trace("dequeue 20");
    assert(enqueue(60));
    trace("enqueue 60 wraps");
    assert(enqueue(70));
    trace("enqueue 70");
    assert(peek(&value) && value == 30 && isFull());
    trace("peek returns 30");
    for (int item = 30; item <= 70; item = item + 10) {
        assert(dequeue(&value) && value == item);
        trace("dequeue");
    }
    assert(front == -1 && rear == -1);
    assert(isEmpty() && !dequeue(&value));
    trace("empty");
    assert(enqueue(80));
    assert(peek(&value) && value == 80);
    assert(dequeue(&value) && value == 80);
    assert(isEmpty());
}
