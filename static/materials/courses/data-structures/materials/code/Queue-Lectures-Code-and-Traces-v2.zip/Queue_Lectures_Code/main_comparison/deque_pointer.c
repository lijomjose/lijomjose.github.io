#include <stdio.h>
#include <stdbool.h>
#include <assert.h>
#define CAP 5
static int data[CAP];
static int front = -1;
static int rear = -1;
bool isEmpty(void) { return front == -1; }
bool isFull(void) { return !isEmpty() && (rear+1)%CAP == front; }
bool insertFront(int value) {
    if (isFull()) {
        return false;
    }
    if (isEmpty()) {
        front = 0;
        rear = 0;
    } else {
        front = (front + CAP - 1) % CAP;
    }
    data[front] = value;
    return true;
}
bool insertRear(int value) {
    if (isFull()) {
        return false;
    }
    if (isEmpty()) {
        front = 0;
        rear = 0;
    } else {
        rear = (rear + 1) % CAP;
    }
    data[rear] = value;
    return true;
}
bool deleteFront(int *removedValue) {
    if (isEmpty()) {
        return false;
    }
    *removedValue = data[front];
    if (front == rear) {
        front = -1;
        rear = -1;
    } else {
        front = (front + 1) % CAP;
    }
    return true;
}
bool deleteRear(int *removedValue) {
    if (isEmpty()) {
        return false;
    }
    *removedValue = data[rear];
    if (front == rear) {
        front = -1;
        rear = -1;
    } else {
        rear = (rear + CAP - 1) % CAP;
    }
    return true;
}
bool getFront(int *value) {
    if (isEmpty()) {
        return false;
    }
    *value = data[front];
    return true;
}
bool getRear(int *value) {
    if (isEmpty()) {
        return false;
    }
    *value = data[rear];
    return true;
}
void trace(const char *op) {
    printf("%-18s front=%2d rear=%2d pending:",op,front,rear);
    if(!isEmpty()) {int i=front;while(1){printf(" %d",data[i]);if(i==rear)break;i=(i+1)%CAP;}}
    puts("");
}
int main(void) {
    insertRear(10);
    insertRear(20);
    int value;
    while (deleteFront(&value)) {
        printf("Removed: %d\n", value);
    }
    printf("Queue empty. Main continues\n");
    return 0;
}
