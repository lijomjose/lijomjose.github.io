#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>
#define CAP 8
static int data[CAP];
static int size = 0;
/* Integer value is the priority. Larger values have higher priority. */
bool isEmpty(void){return size==0;}
bool isFull(void){return size==CAP;}
bool enqueue(int value) {
    if (isFull()) {
        return false;
    }
    data[size] = value;
    size = size + 1;
    return true;
}
int maxIndex(void) {
    int maximumPosition = 0;
    for (int i = 1; i < size; i = i + 1) {
        if (data[i] > data[maximumPosition]) {
            maximumPosition = i;
        }
    }
    return maximumPosition;
}
int peekMax(void) {
    if (isEmpty()) {
        printf("Queue is empty!\n");
        exit(1);
    }
    int maximumPosition = maxIndex();
    int maximumValue = data[maximumPosition];
    return maximumValue;
}
int dequeueMax(void) {
    if (isEmpty()) {
        printf("Queue is empty!\n");
        exit(1);
    }
    int maximumPosition = maxIndex();
    int removedValue = data[maximumPosition];
    // Close the gap left by the removed item.
    for (int i = maximumPosition; i < size - 1; i = i + 1) {
        data[i] = data[i + 1];
    }
    size = size - 1;
    return removedValue;
}
void trace(const char *op){printf("%-20s size=%d storage:",op,size);for(int i=0;i<size;++i)printf(" %d",data[i]);puts("");}
int main(int argc, char **argv) {
    (void)argv;
    if (argc > 1) { dequeueMax(); }
    assert(enqueue(4));
    assert(enqueue(2));
    assert(enqueue(5));
    assert(enqueue(3));
    assert(peekMax() == 5);
    int value5 = dequeueMax();
    assert(value5 == 5);
    printf("Removed: %d\n", value5);
    int value4 = dequeueMax();
    assert(value4 == 4);
    printf("Removed: %d\n", value4);
    int value3 = dequeueMax();
    assert(value3 == 3);
    printf("Removed: %d\n", value3);
    int value2 = dequeueMax();
    assert(value2 == 2);
    printf("Removed: %d\n", value2);
    return 0;
}
