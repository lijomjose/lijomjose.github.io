#include <stdio.h>
#include <stdbool.h>
#include <assert.h>
#include <stdlib.h>
#define QUEUE_COUNT 3
typedef struct Node {
    int value;
    struct Node *next;
} Node;
typedef struct {
    Node *front;
    Node *rear;
} Queue;
static Queue queues[QUEUE_COUNT] = {{0}};
bool enqueue(Queue *q, int value) {
    Node *newNode = malloc(sizeof(Node));
    if (newNode == NULL) {
        return false;
    }
    newNode->value = value;
    newNode->next = NULL;

    if (q->rear == NULL) {
        q->front = newNode;  // First node in an empty queue
    } else {
        q->rear->next = newNode;
    }
    q->rear = newNode;
    return true;
}
int dequeue(Queue *q) {
    if (q->front == NULL) {
        printf("Queue is empty!\n");
        exit(1);
    }
    Node *oldFront = q->front;
    int removedValue = oldFront->value;
    q->front = oldFront->next;

    if (q->front == NULL) {
        q->rear = NULL;  // The last node has left
    }
    free(oldFront);
    return removedValue;
}
int peek(const Queue *q) {
    if (q->front == NULL) {
        printf("Queue is empty!\n");
        exit(1);
    }
    int frontValue = q->front->value;
    return frontValue;
}
void trace(const char *op) {
    puts(op);
    for(int k=0;k<QUEUE_COUNT;++k) {
        printf("Q%d:",k);
        for(Node *n=queues[k].front;n;n=n->next) printf(" %d",n->value);
        printf("  front=%s rear=%s\n",queues[k].front?"node":"NULL",queues[k].rear?"node":"NULL");
    }
}
int main(int argc, char **argv) {
    (void)argv;
    if (argc > 1) { dequeue(&queues[0]); }
    assert(enqueue(&queues[0], 10));
    assert(enqueue(&queues[0], 20));
    assert(enqueue(&queues[1], 100));
    assert(peek(&queues[0]) == 10);
    printf("Removed: %d\n", dequeue(&queues[0]));
    printf("Removed: %d\n", dequeue(&queues[0]));
    printf("Queue 1 removed: %d\n", dequeue(&queues[1]));
    assert(queues[0].front == NULL && queues[0].rear == NULL);
    return 0;
}
