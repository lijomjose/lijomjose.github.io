# Queue lectures 2 and 3: C code and traces

Official source: Module 3 Stacks and queues.pptx in Materials.zip, slides 71-111.
Lecture 2 covers linked queues, linear arrays, multiple linked queues and circular arrays (slides 71-93).
Lecture 3 covers deques, restricted deques, applications and priority queues (slides 94-111).

Each C file is standalone and includes a main function that runs a trace with checks. Compile one at a time:

```sh
gcc -std=c11 -Wall -Wextra -Werror -pedantic circular_queue.c -o circular_queue
./circular_queue
```

The matching .trace.txt files contain the actual output. Keep assertions enabled when running these teaching drivers.

- linked_queues.c: front/rear pointers, enqueue, dequeue, peek, three independent queues and node cleanup.
- linear_queue.c: last-item rear convention, unused-cell limitation, reset after final dequeue.
- circular_queue.c: front names next item, rear names next free slot; one unused cell distinguishes full and empty.
- deque.c: first/last-item indexes, -1 empty state, all CAP cells usable, insertion/deletion and reading at both ends. Restricted deques expose only the corresponding subset of these operations.
- priority_unsorted.c: append, scan maximum, read maximum and stable left shift after deletion.
- priority_sorted.c: ascending insertion, maximum removal from the end, read maximum.

Code uses bool success and an output parameter so failure cannot be confused with a legitimate integer value. The linked multiple queues use an array of Queue structs instead of the official parallel front/rear arrays. Priority examples use integers as priorities; a real alert record would also contain its payload. For tied priorities, strict > in the unsorted scan and >= in sorted insertion preserve the intended arrival order when entire records are moved.

Native editable diagrams in the decks show logical contents. Dim cells hold stale values outside the queue. Priority diagrams show five display cells although the runnable priority code has capacity eight.
