#include <stdio.h>
#include <stdbool.h>
#include <assert.h>
#define CAP 8
static int data[CAP];
static int size = 0;
/* Ascending storage; maximum leaves at size-1. New equal priority goes before older equals. */
bool enqueue(int value) {
    if (size == CAP) {
        return false;
    }
    int position = size;
    // Move larger or equal values one cell right.
    while (position > 0 && data[position - 1] >= value) {
        data[position] = data[position - 1];
        position = position - 1;
    }
    data[position] = value;
    size = size + 1;
    return true;
}
bool peekMax(int *maximumValue) {
    if (size == 0) {
        return false;
    }
    *maximumValue = data[size - 1];
    return true;
}
bool dequeueMax(int *removedValue) {
    if (size == 0) {
        return false;
    }
    *removedValue = data[size - 1];
    size = size - 1;
    return true;
}
void trace(const char *op){printf("%-20s size=%d sorted:",op,size);for(int i=0;i<size;++i)printf(" %d",data[i]);puts("");}
int main(void){
    int x;
    assert(enqueue(4));
    trace("enqueue 4");
    assert(enqueue(2));
    trace("enqueue 2");
    assert(enqueue(5));
    trace("enqueue 5");
    assert(enqueue(3));
    trace("enqueue 3");
    assert(peekMax(&x)&&x==5);
    assert(dequeueMax(&x)&&x==5);
    trace("dequeueMax 5");
    assert(dequeueMax(&x)&&x==4);
    assert(dequeueMax(&x)&&x==3);
    assert(dequeueMax(&x)&&x==2);
    assert(!dequeueMax(&x));
}
