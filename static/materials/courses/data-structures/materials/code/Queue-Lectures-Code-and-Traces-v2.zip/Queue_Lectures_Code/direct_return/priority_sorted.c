#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>
#define CAP 8
static int data[CAP];
static int size = 0;
/* Ascending storage; maximum leaves at size-1. New equal priority goes before older equals. */
bool enqueue(int value) {
    if (size == CAP) {
        return false;
    }
    int position = size;
    // Move larger or equal values one cell right.
    while (position > 0 && data[position - 1] >= value) {
        data[position] = data[position - 1];
        position = position - 1;
    }
    data[position] = value;
    size = size + 1;
    return true;
}
int peekMax(void) {
    if (size == 0) {
        printf("Queue is empty!\n");
        exit(1);
    }
    int maximumValue = data[size - 1];
    return maximumValue;
}
int dequeueMax(void) {
    if (size == 0) {
        printf("Queue is empty!\n");
        exit(1);
    }
    int removedValue = data[size - 1];
    size = size - 1;
    return removedValue;
}
void trace(const char *op){printf("%-20s size=%d sorted:",op,size);for(int i=0;i<size;++i)printf(" %d",data[i]);puts("");}
int main(int argc, char **argv) {
    (void)argv;
    if (argc > 1) { dequeueMax(); }
    assert(enqueue(4));
    assert(enqueue(2));
    assert(enqueue(5));
    assert(enqueue(3));
    assert(peekMax() == 5);
    int value5 = dequeueMax();
    assert(value5 == 5);
    printf("Removed: %d\n", value5);
    int value4 = dequeueMax();
    assert(value4 == 4);
    printf("Removed: %d\n", value4);
    int value3 = dequeueMax();
    assert(value3 == 3);
    printf("Removed: %d\n", value3);
    int value2 = dequeueMax();
    assert(value2 == 2);
    printf("Removed: %d\n", value2);
    return 0;
}
