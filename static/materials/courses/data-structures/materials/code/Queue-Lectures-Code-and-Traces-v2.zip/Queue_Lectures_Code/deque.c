#include <stdio.h>
#include <stdbool.h>
#include <assert.h>
#define CAP 5
static int data[CAP];
static int front = -1;
static int rear = -1;
bool isEmpty(void) { return front == -1; }
bool isFull(void) { return !isEmpty() && (rear+1)%CAP == front; }
bool insertFront(int value) {
    if (isFull()) {
        return false;
    }
    if (isEmpty()) {
        front = 0;
        rear = 0;
    } else {
        front = (front + CAP - 1) % CAP;
    }
    data[front] = value;
    return true;
}
bool insertRear(int value) {
    if (isFull()) {
        return false;
    }
    if (isEmpty()) {
        front = 0;
        rear = 0;
    } else {
        rear = (rear + 1) % CAP;
    }
    data[rear] = value;
    return true;
}
bool deleteFront(int *removedValue) {
    if (isEmpty()) {
        return false;
    }
    *removedValue = data[front];
    if (front == rear) {
        front = -1;
        rear = -1;
    } else {
        front = (front + 1) % CAP;
    }
    return true;
}
bool deleteRear(int *removedValue) {
    if (isEmpty()) {
        return false;
    }
    *removedValue = data[rear];
    if (front == rear) {
        front = -1;
        rear = -1;
    } else {
        rear = (rear + CAP - 1) % CAP;
    }
    return true;
}
bool getFront(int *value) {
    if (isEmpty()) {
        return false;
    }
    *value = data[front];
    return true;
}
bool getRear(int *value) {
    if (isEmpty()) {
        return false;
    }
    *value = data[rear];
    return true;
}
void trace(const char *op) {
    printf("%-18s front=%2d rear=%2d pending:",op,front,rear);
    if(!isEmpty()) {int i=front;while(1){printf(" %d",data[i]);if(i==rear)break;i=(i+1)%CAP;}}
    puts("");
}
int main(void) {
    int x;
    assert(insertFront(10));
    trace("insertFront 10");
    assert(insertRear(20));
    trace("insertRear 20");
    assert(insertFront(5));
    trace("insertFront 5");
    assert(insertRear(30));
    trace("insertRear 30");
    assert(deleteRear(&x)&&x==30);
    trace("deleteRear 30");
    assert(deleteFront(&x)&&x==5);
    trace("deleteFront 5");
    assert(getFront(&x)&&x==10 && getRear(&x)&&x==20);
    assert(deleteFront(&x)&&x==10);
    assert(deleteRear(&x)&&x==20);
    assert(isEmpty() && !deleteFront(&x));
    trace("last departure");
    for(int i=0;i<CAP;++i) assert(insertRear(i));
    assert(isFull()&&!insertFront(99));
}
