#include <stdio.h>
#include <stdbool.h>
#include <assert.h>
#define CAP 8
static int data[CAP];
static int size = 0;
/* Integer value is the priority. Larger values have higher priority. */
bool isEmpty(void){return size==0;}
bool isFull(void){return size==CAP;}
bool enqueue(int value) {
    if (isFull()) {
        return false;
    }
    data[size] = value;
    size = size + 1;
    return true;
}
int maxIndex(void) {
    int maximumPosition = 0;
    for (int i = 1; i < size; i = i + 1) {
        if (data[i] > data[maximumPosition]) {
            maximumPosition = i;
        }
    }
    return maximumPosition;
}
bool peekMax(int *maximumValue) {
    if (isEmpty()) {
        return false;
    }
    int maximumPosition = maxIndex();
    *maximumValue = data[maximumPosition];
    return true;
}
bool dequeueMax(int *removedValue) {
    if (isEmpty()) {
        return false;
    }
    int maximumPosition = maxIndex();
    *removedValue = data[maximumPosition];
    // Close the gap left by the removed item.
    for (int i = maximumPosition; i < size - 1; i = i + 1) {
        data[i] = data[i + 1];
    }
    size = size - 1;
    return true;
}
void trace(const char *op){printf("%-20s size=%d storage:",op,size);for(int i=0;i<size;++i)printf(" %d",data[i]);puts("");}
int main(void){
    int x;
    assert(enqueue(4)&&enqueue(2)&&enqueue(5)&&enqueue(3));
    trace("arrivals 4 2 5 3");
    assert(peekMax(&x)&&x==5);
    trace("peekMax returns 5");
    assert(dequeueMax(&x)&&x==5);
    trace("dequeueMax 5");
    assert(dequeueMax(&x)&&x==4);
    trace("dequeueMax 4");
    assert(dequeueMax(&x)&&x==3);
    assert(dequeueMax(&x)&&x==2);
    assert(isEmpty()&&!dequeueMax(&x));
}
