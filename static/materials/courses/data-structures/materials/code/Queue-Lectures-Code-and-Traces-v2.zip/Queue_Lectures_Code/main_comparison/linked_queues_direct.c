#include <stdio.h>
#include <stdbool.h>
#include <assert.h>
#include <stdlib.h>
#define QUEUE_COUNT 3
typedef struct Node {
    int value;
    struct Node *next;
} Node;
typedef struct {
    Node *front;
    Node *rear;
} Queue;
static Queue queues[QUEUE_COUNT] = {{0}};
bool enqueue(Queue *q, int value) {
    Node *newNode = malloc(sizeof(Node));
    if (newNode == NULL) {
        return false;
    }
    newNode->value = value;
    newNode->next = NULL;

    if (q->rear == NULL) {
        q->front = newNode;  // First node in an empty queue
    } else {
        q->rear->next = newNode;
    }
    q->rear = newNode;
    return true;
}
int dequeue(Queue *q) {
    if (q->front == NULL) {
        printf("Queue is empty!\n");
        exit(1);
    }
    Node *oldFront = q->front;
    int removedValue = oldFront->value;
    q->front = oldFront->next;

    if (q->front == NULL) {
        q->rear = NULL;  // The last node has left
    }
    free(oldFront);
    return removedValue;
}
int peek(const Queue *q) {
    if (q->front == NULL) {
        printf("Queue is empty!\n");
        exit(1);
    }
    int frontValue = q->front->value;
    return frontValue;
}
void trace(const char *op) {
    puts(op);
    for(int k=0;k<QUEUE_COUNT;++k) {
        printf("Q%d:",k);
        for(Node *n=queues[k].front;n;n=n->next) printf(" %d",n->value);
        printf("  front=%s rear=%s\n",queues[k].front?"node":"NULL",queues[k].rear?"node":"NULL");
    }
}
int main(void) {
    Queue mission = {NULL, NULL};
    enqueue(&mission, 10);
    enqueue(&mission, 20);
    int value = dequeue(&mission);
    printf("Removed: %d\n", value);
    value = dequeue(&mission);
    printf("Removed: %d\n", value);
    value = dequeue(&mission); // Empty: exit(1)
    printf("Main continues\n"); // Never reached
    return 0;
}
