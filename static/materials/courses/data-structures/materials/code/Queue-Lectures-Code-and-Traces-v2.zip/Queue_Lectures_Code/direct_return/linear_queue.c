#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <assert.h>
#define CAP 5
static int data[CAP];
static int front = -1;
static int rear = -1;
bool isEmpty(void) { return front == -1; }
bool isFull(void) { return rear == CAP - 1; }
bool enqueue(int value) {
    if (isFull()) {
        return false;
    }
    if (isEmpty()) {
        front = 0;
    }
    rear = rear + 1;
    data[rear] = value;
    return true;
}
int dequeue(void) {
    if (isEmpty()) {
        printf("Queue is empty!\n");
        exit(1);
    }
    int removedValue = data[front];
    if (front == rear) {
        front = -1;
        rear = -1;
    } else {
        front = front + 1;
    }
    return removedValue;
}
int peek(void) {
    if (isEmpty()) {
        printf("Queue is empty!\n");
        exit(1);
    }
    int frontValue = data[front];
    return frontValue;
}
void trace(const char *op) {
    printf("%-18s front=%2d rear=%2d pending:", op, front, rear);
    if (!isEmpty()) for (int i=front;i<=rear;++i) printf(" %d",data[i]);
    puts("");
}
int main(int argc, char **argv) {
    (void)argv;
    if (argc > 1) { dequeue(); }
    assert(enqueue(10));
    assert(enqueue(20));
    assert(enqueue(30));
    assert(peek() == 10);
    int value10 = dequeue();
    assert(value10 == 10);
    printf("Removed: %d\n", value10);
    int value20 = dequeue();
    assert(value20 == 20);
    printf("Removed: %d\n", value20);
    int value30 = dequeue();
    assert(value30 == 30);
    printf("Removed: %d\n", value30);
    return 0;
}
