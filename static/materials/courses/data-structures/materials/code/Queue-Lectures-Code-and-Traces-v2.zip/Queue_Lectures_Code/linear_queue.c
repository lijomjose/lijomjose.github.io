#include <stdio.h>
#include <stdbool.h>
#include <assert.h>
#define CAP 5
static int data[CAP];
static int front = -1;
static int rear = -1;
bool isEmpty(void) { return front == -1; }
bool isFull(void) { return rear == CAP - 1; }
bool enqueue(int value) {
    if (isFull()) {
        return false;
    }
    if (isEmpty()) {
        front = 0;
    }
    rear = rear + 1;
    data[rear] = value;
    return true;
}
bool dequeue(int *removedValue) {
    if (isEmpty()) {
        return false;
    }
    *removedValue = data[front];
    if (front == rear) {
        front = -1;
        rear = -1;
    } else {
        front = front + 1;
    }
    return true;
}
bool peek(int *frontValue) {
    if (isEmpty()) {
        return false;
    }
    *frontValue = data[front];
    return true;
}
void trace(const char *op) {
    printf("%-18s front=%2d rear=%2d pending:", op, front, rear);
    if (!isEmpty()) for (int i=front;i<=rear;++i) printf(" %d",data[i]);
    puts("");
}
int main(void) {
    int x;
    trace("start");
    assert(enqueue(10));
    trace("enqueue 10");
    assert(enqueue(20));
    trace("enqueue 20");
    assert(enqueue(30));
    trace("enqueue 30");
    assert(peek(&x) && x==10);
    trace("peek returns 10");
    assert(dequeue(&x) && x==10);
    trace("dequeue 10");
    assert(dequeue(&x) && x==20);
    trace("dequeue 20");
    assert(enqueue(40));
    trace("enqueue 40");
    assert(enqueue(50));
    trace("enqueue 50");
    assert(!enqueue(60));
    trace("enqueue 60 fails");
    while(dequeue(&x)) trace("dequeue");
    assert(front==-1 && rear==-1 && !peek(&x));
    assert(enqueue(60));
    trace("enqueue 60 works");
}
